set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_login_user_flow partition(mth)
select
id,
ip,
page_uri,
uid,
terminal,
business_sys,
source,
create_time,
update_time,
apply,
dt mth
from ods_ods.ods_ods_ishare_tb_login_user_flow;