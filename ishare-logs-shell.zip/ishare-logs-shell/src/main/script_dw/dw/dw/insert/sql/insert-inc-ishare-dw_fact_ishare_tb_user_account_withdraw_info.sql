set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_user_account_withdraw_info partition(dt)
select
id,
code,
seller_user_id,
seller_user_type,
seller_user_name,
seller_pretax_price,
withholding_tax_price,
transfer_tax,
cast(from_unixtime(cast((cast(create_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) create_time,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
withdraw_status,
audit_no_pass_reason,
final_with_price,
invoice_pic_url,
invoice_type,
creator_name,
creator_id,
modifier_name,
modifier_id,
enable,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyyMM') as string) dt
from ods_ods.ods_ods_ishare_tb_user_account_withdraw_info;