set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_tb_audit_people_record
select
id,
fileId,
fileName,
format,
sensitiveKeywords,
userId,
userName,
fileSourceChannel,
cast(from_unixtime(cast((cast(uploadTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) uploadTime,
status,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updateTime
from ods_ods.ods_ods_ishare_tb_audit_people_record;