set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_file_price_revision partition(mth)
select
id,
fid,
uid,
batchId,
orgPrice,
price,
orgVolume,
volume,
status,
cast(from_unixtime(cast((cast(uploadTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) uploadTime,
orgpermin,
permin,
orgmoneyprice,
moneyprice,
cast(from_unixtime(cast((cast(createtime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createtime,
updatetime,
updateuserId,
updateusername,
type string,
dt mth
from ods_ods.ods_ods_ishare_t_file_price_revision;