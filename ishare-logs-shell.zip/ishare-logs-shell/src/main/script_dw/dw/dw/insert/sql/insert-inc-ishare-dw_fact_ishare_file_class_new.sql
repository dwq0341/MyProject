set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_file_class_new
select
id,
class,
name,
level,
father,
flag,
time,
admid,
if_show,
description,
audit_mode,
priority,
keyword1,
keyword2,
keyword3,
recommend,
old_class_id,
old_class_name,
rank,
channel_type,
channel_status,
specifics_id_list
from ods_ods.ods_ods_ishare_file_class_new;