set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_seo_site_traffic partition(dt)
select
dayno,
vendor,
domain,
site_id,
iface,
item,
pv,
uv,
visit,
new_uv,
ip,
avg_visit_time,
bounce_rate,
id,
sub_item,
action,
category,
replace(substr(dayno,0,7),'-','') dt
from ods_ods.ods_ods_ishare_t_seo_site_traffic;