#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "社交二期统计报表完成"
