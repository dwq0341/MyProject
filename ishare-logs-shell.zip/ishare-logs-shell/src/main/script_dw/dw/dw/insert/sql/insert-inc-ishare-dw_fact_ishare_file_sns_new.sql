set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_file_sns_new partition(mth)
select
id,
class,
uid,
fileid,
downnum,
readnum,
starpeoplenum,
starscore,
commentnum,
praisenum,
treadnum,
collectnum,
updatetime,
startindex,
virtualreadnum,
virtualpraisenum,
virtualcollectnum,
dt mth
from ods_ods.ods_ods_ishare_file_sns_new;