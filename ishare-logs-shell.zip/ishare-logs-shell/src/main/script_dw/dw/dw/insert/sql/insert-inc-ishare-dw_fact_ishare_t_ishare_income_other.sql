set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_ishare_income_other partition(dt)
select
index,
dayno,
terminal,
income,
replace(substr(dayno,0,7),'-','') dt
from ods_ods.ods_ods_ishare_t_ishare_income_other;