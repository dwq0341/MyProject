-- set hive.execution.engine=spark;
-- select
-- b.visit_id,
-- count(1) num
-- from (
-- select buyer_user_id
-- from dw_fact.dw_fact_ishare_t_order_info
-- where substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
-- and channel_source in ('5','0','6','7','8','9') and goods_type in ('1','2','4','8','12','13')
-- and order_status = '2' group by buyer_user_id) a
-- inner join
-- (
-- select user_id,visit_id from dw_fact.dw_fact_ishare_session_event
-- where dt='${date_day}' and visit_id <> '900501616412997322'
-- and visit_id is not null and user_id is not null
-- group by user_id,visit_id) b on a.buyer_user_id = b.user_id
-- group by b.visit_id
-- order by num desc

-- 上面可以看出基本不会出现一个visit_id对应

insert overwrite table dw_fact.dw_fact_ishare_visit_event_sem partition(dt='${date_day}')
select
session_id,               --会话id
event_id,                 --事件id
event_name,               --事件名称
event_type,               --事件类型
event_time,                   --事件时间
nginx_date,   --服务器上传时间
terminal_type,            --终端类型
login_status,             --登录状态
a.visit_id,                 --访客ID
d.buyer_user_id user_id,                  --用户ID
ip,                       --ip地址
page_id,                  --当前页面编号
page_name,                --当前页面的名称
page_url,                 --当前页面URL
FIRST_VALUE(page_url) over(partition by a.visit_id order by a.nginx_date desc)   land_url, 	            --落地页url
exit_url,        --退出页url
domain ,           --域名
dom_id,                   --当前触发DOM的编号
dom_name,                 --当前触发DOM的名称
session_position,
session_event_duration,
session_start_time,    --每一个session开始时间
session_end_time,      --每一个session结束时间
session_duration,      --每一个session持续的时间
distinct_pv_count,                                   --访问深度
is_single_pv_session,   --是否单PV会话
session_pv_count,                                               --访问页数
var                                                                                                                                                                --业务json数据
from (
select *
from dw_fact.dw_fact_ishare_session_event where dt = '${date_day}'
) a
inner join (
select distinct buyer_user_id,b.visit_id,c.order_time
from (
select
*
from(
select *
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and channel_source in ('5','0','6','7','8','9')
--and goods_type in ('1','2','4','8','12','13')
) order_info
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on order_info.goods_type=g.goods_types
where g.goods_types is not null
) c
left join (   --看看这里需不需要修改  把user_id max一下
select *
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
) b on c.buyer_user_id = b.user_id
and order_status = '2'
) d on a.visit_id = d.visit_id
where a.nginx_date <= d.order_time
and page_url regexp('.*utm_source.*')
and page_url regexp('.*utm_medium.*')
and page_url regexp('.*utm_campaign.*')
and page_url regexp('.*utm_term.*')

-- select
-- session_id,               --会话id
-- event_id,                 --事件id
-- event_name,               --事件名称
-- event_type,               --事件类型
-- event_time,                   --事件时间
-- nginx_date,   --服务器上传时间
-- terminal_type,            --终端类型
-- login_status,             --登录状态
-- a.visit_id,                 --访客ID
-- d.buyer_user_id user_id,                  --用户ID
-- ip,                       --ip地址
-- page_id,                  --当前页面编号
-- page_name,                --当前页面的名称
-- page_url,                 --当前页面URL
-- FIRST_VALUE(page_url) over(partition by a.visit_id order by a.nginx_date desc)   land_url, 	            --落地页url
-- exit_url,        --退出页url
-- domain ,           --域名
-- dom_id,                   --当前触发DOM的编号
-- dom_name,                 --当前触发DOM的名称
-- session_position,
-- session_event_duration,
-- session_start_time,    --每一个session开始时间
-- session_end_time,      --每一个session结束时间
-- session_duration,      --每一个session持续的时间
-- distinct_pv_count,                                   --访问深度
-- is_single_pv_session,   --是否单PV会话
-- session_pv_count,                                               --访问页数
-- var                                                                                                                                                                --业务json数据
-- from dw_fact.dw_fact_ishare_session_event a
-- inner join (
-- select distinct buyer_user_id,b.visit_id,c.order_time
-- from (
-- select *
-- from dw_fact.dw_fact_ishare_t_order_info
-- where substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
-- and channel_source in ('5','0','6','7','8','9') and goods_type in ('1','2','4','8','12','13')
-- ) c
-- left join (   --看看这里需不需要修改  把user_id max一下
-- select *
-- from dw_fact.dw_fact_ishare_session_event
-- where dt='${date_day}'
-- ) b on c.buyer_user_id = b.user_id
-- and order_status = '2'
-- ) d
-- on a.visit_id = d.visit_id
-- where a.nginx_date <= d.order_time
-- and page_url regexp('.*utm_source.*')
-- and page_url regexp('.*utm_medium.*')
-- and page_url regexp('.*utm_campaign.*')
-- and page_url regexp('.*utm_term.*')
-- and a.dt = '${date_day}' ;

--如果用page_url会出现当某个用户在访问中途登录这样根据他的visit_id算-->land_url是渠道投放出来的
--之前用page_url去匹配是以为可以减少数据量。但是如果这样的话，上面那种中途登录的情况
--就会出现page_url可以匹配的上，但是user_id为空的情况，这样就不会匹配到真实的user_id
