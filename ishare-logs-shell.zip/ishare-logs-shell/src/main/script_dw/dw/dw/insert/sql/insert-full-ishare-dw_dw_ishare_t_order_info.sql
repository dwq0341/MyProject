set mapred.child.java.opts=-Xmx1024m;
set mapreduce.map.java.opts=-Xmx1310m;
set yarn.app.mapreduce.am.command-opts=-Xmx2457m;
set mapreduce.reduce.java.opts=-Xmx2620m;
set mapreduce.map.memory.mb=4096;
insert overwrite table  dw_dim.dw_dim_ishare_t_order_info partition(dt='${date_day}')
select
id,
buyerUserId	,
buyerUserName	,
sellerMoneyShare	,
goodsType	,
goodsName	,
goodsId	,
voluNum	,
payPrice	,
platformPrice	,
orderStatus	,
from_unixtime(unix_timestamp (split(orderTime,'\\.')[0],'yyyyMMddHHmmss')+28800,'yyyy-MM-dd HH:mm:ss')orderTime	,
userOpt	,
refundStatus	,
withdrawStatus	,
payType	,
from_unixtime(unix_timestamp (split(payTime,'\\.')[0],'yyyyMMddHHmmss')+28800,'yyyy-MM-dd HH:mm:ss') payTime	,
sourceMode	,
billStatus	,
billRemark	,
from_unixtime(unix_timestamp (split(cancelTime,'\\.')[0],'yyyyMMddHHmmss')+28800,'yyyy-MM-dd HH:mm:ss') cancelTime
from ods_ods.ods_ods_ishare_t_order_info w where w.dt='${date_day}';
ALTER TABLE dw_dim.dw_dim_ishare_t_order_info DROP IF EXISTS PARTITION (dt='${two_day_ago}');