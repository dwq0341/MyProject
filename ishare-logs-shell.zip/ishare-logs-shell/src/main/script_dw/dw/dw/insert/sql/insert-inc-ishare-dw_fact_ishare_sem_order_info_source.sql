insert overwrite table dw_fact.dw_fact_ishare_sem_order_info_source partition(dt = '${date_day}')
select
case d.source when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' when 'baidu4' then '爱问科技04' when 'baidu5' then '爱问科技05'   when 'baidu6' then '爱问科技06' when 'baidu07' then '爱问科技07' when 'baidu12' then '爱问科技12' when 'baidu22' then '爱问科技22'  when 'baidu21' then '爱问科技21'  when 'baiducq1' then '爱问众创-01' when 'baiducq02' then '爱问众创-02'  when 'baidu14' then '爱问科技14'  when 'baiduzc4' then '爱问众创04'  when 'baiduzc2' then '爱问众创02' when 'baidu19' then '爱问科技19'   when 'baidu14' then '爱问科技14' when 'baidu15' then '爱问科技15' when 'baidu8' then '爱问科技08' when 'baiduzc' then '爱问众创' when 'baiduzc1' then '爱问众创01' when 'baiduth1' then '爱问办公1' else null end as account,
d.source,
sum(pay_price) total_pay_price,
count(distinct pay_user) total_pay_user,
sum(pay_price)/count(distinct pay_user) unit_order_price,
sum(case when goods_type = '2' or goods_type = '8' then pay_price else 0 end) vip_pay_amount,
count(distinct (case when goods_type = '2' or goods_type = '8' then pay_user else null end)) vip_succ_pay_uv,
sum(case when goods_type = '1' or goods_type = '5' then pay_price else 0 end) file_succ_pay_amount,
count(distinct (case when goods_type = '1' or goods_type = '5' then pay_user else null end)) file_succ_pay_uv,
sum(case when goods_type = '3' or goods_type = '7' then pay_price else 0 end) download_privilege_pay_amount,
count(distinct (case when goods_type = '3' or goods_type = '7' then pay_user else null end)) download_privilege_succ_uv
from (
select
case parse_url(b.land_url,'QUERY','utm_source') when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' else null end as account,
parse_url(b.land_url,'QUERY','utm_source') source,
a.pay_price/100 pay_price,
a.buyer_user_id pay_user,
a.goods_type
from dw_fact.dw_fact_ishare_t_order_info a
left join (
select distinct user_id,FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
from dw_fact.dw_fact_ishare_visit_event_sem where dt = '${date_day}' and parse_url(land_url,'QUERY','utm_source') like '%baidu%'
) b on a.buyer_user_id = b.user_id
left join (
select max(plan_name) plan_name,max(unit_name) unit_name,max(keyword_name) keyword_name,concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term')) pc_des_url
from ods_ods.ods_ods_ishare_baidu_tongji_keyword_mapping
group by concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term'))
) c on concat(split(b.land_url,'utm_term=')[0],'utm_term=',parse_url(b.land_url,'QUERY','utm_term')) = c.pc_des_url
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on a.goods_type=g.goods_types
where substr(a.order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and g.goods_types is not null
and a.order_status = '2'
and a.channel_source in ('5','0','6','7','8','9')
--and a.goods_type in ('1','2','4','8','12','13')
and b.user_id is not null
) d group by d.source

union all
select
'全部' account,
'百度' source,
sum(pay_price) total_pay_price,
count(distinct pay_user) total_pay_user,
sum(pay_price)/count(distinct pay_user) unit_order_price,
sum(case when goods_type = '2' or goods_type = '8' then pay_price else 0 end) vip_pay_amount,
count(distinct (case when goods_type = '2' or goods_type = '8' then pay_user else null end)) vip_succ_pay_uv,
sum(case when goods_type = '1' or goods_type = '5' then pay_price else 0 end) file_succ_pay_amount,
count(distinct (case when goods_type = '1' or goods_type = '5' then pay_user else null end)) file_succ_pay_uv,
sum(case when goods_type = '3' or goods_type = '7' then pay_price else 0 end) download_privilege_pay_amount,
count(distinct (case when goods_type = '3' or goods_type = '7' then pay_user else null end)) download_privilege_succ_uv
from (
select
a.pay_price/100 pay_price,
a.buyer_user_id pay_user,
a.goods_type
from dw_fact.dw_fact_ishare_t_order_info a
left join (
select distinct user_id,FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
from dw_fact.dw_fact_ishare_visit_event_sem
where dt = '${date_day}' and parse_url(land_url,'QUERY','utm_source') like '%baidu%'
) b on a.buyer_user_id = b.user_id
left join (
select max(plan_name) plan_name,max(unit_name) unit_name,max(keyword_name) keyword_name,concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term')) pc_des_url
from ods_ods.ods_ods_ishare_baidu_tongji_keyword_mapping
group by concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term'))
) c on concat(split(b.land_url,'utm_term=')[0],'utm_term=',parse_url(b.land_url,'QUERY','utm_term')) = c.pc_des_url
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on a.goods_type=g.goods_types
where substr(a.order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and g.goods_types is not null
and a.order_status = '2'
and a.channel_source in ('5','0','6','7','8','9')
--and a.goods_type in ('1','2','4','8','12','13')
and b.user_id is not null
) d ;