set mapred.child.java.opts=-Xmx1024m;
set mapreduce.map.java.opts=-Xmx1310m;
set yarn.app.mapreduce.am.command-opts=-Xmx2457m;
set mapreduce.reduce.java.opts=-Xmx2620m;
insert overwrite table dw_dw_ishare_log_coo_index partition(dt='${date_day}')
select
 md5(concat_ws(',',s.event_time,s.event_id,s.event_type,s.report_time,s.visit_id,session_id,page_id)) as pk,
s. event_time,
s.terminal_type,
s.session_id,
s.page_id ,
s.page_url ,
s.get_json_object(var,'$.filePayType') file_pay_type,
s.event_id ,
s.visit_id ,
s.ip  ,
s.etl_date
from  (select event_time,
                terminal_type,
                session_id,
                page_id ,
                page_url ,
                get_json_object(var,'$.filePayType') file_pay_type,
                event_id ,
                visit_id ,
                ip  ,
                event_time,
                event_type,
                report_time,
                etl_date
      from ods_ods.ods_ods_ishare_log_new  where event_id='NE002' and dt='${date_day}') s
and  substr(s.page_url,1,15)=='http://url.html'
and substr(reverse(s.page_url),1,12)=='xobeno063&DI'

--and substr(nginx_date,1,8)>= ${start_date} and substr(nginx_date,1,8)<${end_date};