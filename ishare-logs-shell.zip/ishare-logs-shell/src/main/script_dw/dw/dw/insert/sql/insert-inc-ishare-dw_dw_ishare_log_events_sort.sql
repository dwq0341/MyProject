insert overwrite table dw_fact.dw_fact_ishare_log_events_sort
select
    event_table.visit_id,
    event_table.user_id,
    event_table.event_id,
    event_table.nginx_date,
    event_table.row_visit_id
from(
select
    visit_id,
    user_id,
    event_id,
    nginx_date,
    row_number() over(partition by visit_id order by nginx_date) row_visit_id
from dw_fact.dw_fact_ishare_log_events
where visit_id != ''
and visit_id is not null
) event_table
where event_table.row_visit_id=1