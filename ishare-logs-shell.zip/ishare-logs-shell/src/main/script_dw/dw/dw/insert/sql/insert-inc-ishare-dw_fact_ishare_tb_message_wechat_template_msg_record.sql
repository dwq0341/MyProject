set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_message_wechat_template_msg_record partition(dt)
select
id,
userId,
msgId,
templateType,
appId,
openid,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
enable,
status,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updateTime,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM') as string) dt
from ods_ods.ods_ods_ishare_tb_message_wechat_template_msg_record;