insert overwrite table dw_fact.dw_fact_ishare_sem_bury_point_keyword partition(dt='${date_day}')
select
case parse_url(c.land_url,'QUERY','utm_source') when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' when 'baidu4' then '爱问科技04' when 'baidu5' then '爱问科技05' when 'baidu6' then '爱问科技06' when 'baidu07' then '爱问科技07' when 'baidu12' then '爱问科技12' when 'baidu22' then '爱问科技22'  when 'baidu21' then '爱问科技21'  when 'baiducq1' then '爱问众创-01' when 'baiducq02' then '爱问众创-02'  when 'baidu14' then '爱问科技14'  when 'baiduzc4' then '爱问众创04'  when 'baiduzc2' then '爱问众创02' when 'baidu19' then '爱问科技19'   when 'baidu14' then '爱问科技14' when 'baidu15' then '爱问科技15' when 'baidu8' then '爱问科技08' when 'baiduzc' then '爱问众创' when 'baiduzc1' then '爱问众创01' when 'baiduth1' then '爱问办公1' else null end as account,
parse_url(c.land_url,'QUERY','utm_source') source,
plan_name,
unit_name,
keyword_name,
count(case when (event_id = 'NE001') then page_url else null end) pv_num,
count(distinct (case when (visit_id <> '' and visit_id is not null and event_id = 'NE001') then visit_id else null end)) uv_num,
count(1)/count(distinct session_id) avg_visit_page,
sum(case when page_start_time = session_start_time and page_url = land_url then session_duration else 0 end)/count(distinct session_id) avg_visit_duration,
count(case when (page_url = land_url and event_id = 'NE001') then page_url else null end) land_url_pv,
count(distinct ( case when (page_url = land_url and visit_id <> '' and visit_id is not null and event_id = 'NE001') then visit_id else null end)) land_url_uv,
sum(case when (is_single_land = 1 and event_id = 'NE001') then 1 else 0 end) single_land_num,
COALESCE(sum(case when (is_land_url = 1 and event_id = 'NE001' and is_single_land <> 0) then (unix_timestamp(page_end_time, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(page_start_time, 'yyyy-MM-dd HH:mm:ss')) when (is_land_url = 1 and event_id = 'NE001' and is_single_land = 1) then (unix_timestamp(session_end_time, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(page_start_time, 'yyyy-MM-dd HH:mm:ss'))  else 0 end),0)/count(case when (page_url = land_url and event_id = 'NE001') then page_url else null end) land_url_time,
count(case when event_id = 'SE002' then 1 else null end) detail_page_pv,
count(distinct (case when event_id = 'SE003' then visit_id else null end)) detail_page_download_uv,
count(distinct (case when (event_id = 'SE001' and get_json_object(var,'$.loginResult') = '1') then visit_id else null end)) login_succ_uv,
-- count(distinct (case when (page_id like '%PAY-VIP-L%' ) then visit_id else null end)) vip_menu_page_uv,
count(distinct (case when (event_id = 'NE006' and module_id = 'vipPayCon' ) then visit_id else null end)) vip_menu_page_uv,
count(distinct (case when (event_id = 'SE010') then visit_id else null end)) vip_immediate_pay_click_uv,
count(distinct (case when (page_id like '%PAY-VIP-QR%' ) then visit_id else null end)) vip_pay_page_uv,
count(distinct (case when (event_id = 'SE011' and get_json_object(var,'$.payResult') = '1' ) then visit_id else null end)) vip_succ_pay_uv,
sum((case when (event_id = 'SE011' and get_json_object(var,'$.payResult') = '1' ) then cast(get_json_object(var,'$.orderPayPrice') as double)/100 else 0 end)) vip_pay_amount,
count(distinct (case when (event_id = 'SE012') then visit_id else null end)) download_privilege_click_uv,
sum((case when (event_id = 'SE013' and get_json_object(var,'$.payResult') = '1') then cast(get_json_object(var,'$.orderPayPrice') as double)/100 else 0 end)) download_privilege_pay_amount,
count(distinct (case when (event_id = 'SE013' and get_json_object(var,'$.payResult') = '1') then visit_id else null end)) download_privilege_succ_uv,
count(distinct (case when (event_id = 'SE008') then visit_id else null end)) file_immediate_pay_click_uv,
count(distinct (case when (event_id = 'SE009' and get_json_object(var,'$.payResult') = '1') then visit_id else null end))  file_succ_pay_uv,
sum((case when (event_id = 'SE009' and get_json_object(var,'$.payResult') = '1') then cast(get_json_object(var,'$.orderPayPrice') as double)/100 else 0 end)) file_succ_pay_amount
from (
select
b.plan_name,
b.unit_name,
b.keyword_name,
a.session_id,
a.land_url,
a.visit_id,
a.page_url,
a.exit_url,
a.event_id,
a.page_id,
a.module_id,
a.var,
a.session_start_time,
nginx_date page_start_time,
lead(nginx_date,1,0) over(partition by session_id,land_url order by nginx_date) page_end_time,
session_end_time,
a.session_duration,
count(case when event_id = 'NE001' then 1 else null end) over(partition by session_id,land_url)  is_single_land,
case when a.page_url = a.land_url then 1 else 0 end as is_land_url,
unix_timestamp(nginx_date, 'yyyy-MM-dd HH:mm:ss')
from dw_fact.dw_fact_ishare_visit_event a
left join (select concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term')) pc_des_url,max(plan_name) plan_name,max(unit_name) unit_name,max(keyword_name) keyword_name from ods_ods.ods_ods_ishare_baidu_tongji_keyword_mapping group by concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term'))) b
on (b.pc_des_url = concat(split(land_url,'utm_term=')[0],'utm_term=',parse_url(land_url,'QUERY','utm_term')))
where dt='${date_day}'
and land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*')
and land_url not regexp('.*360.*')
and b.keyword_name is not null and b.plan_name is not null and b.unit_name is not null and b.pc_des_url is not null
) c
group by c.plan_name,c.unit_name,c.keyword_name,parse_url(c.land_url,'QUERY','utm_source')
union all
select
'全部' account,
'百度' source,
plan_name,
unit_name,
keyword_name,
count(case when (event_id = 'NE001') then page_url else null end) pv_num,
count(distinct (case when (visit_id <> '' and visit_id is not null and event_id = 'NE001') then visit_id else null end)) uv_num,
count(1)/count(distinct session_id) avg_visit_page,
sum(case when page_start_time = session_start_time and page_url = land_url then session_duration else 0 end)/count(distinct session_id) avg_visit_duration,
count(case when (page_url = land_url and event_id = 'NE001') then page_url else null end) land_url_pv,
count(distinct ( case when (page_url = land_url and visit_id <> '' and visit_id is not null and event_id = 'NE001') then visit_id else null end)) land_url_uv,
sum(case when (is_single_land = 1 and event_id = 'NE001') then 1 else 0 end) single_land_num,
COALESCE(sum(case when (is_land_url = 1 and event_id = 'NE001' and is_single_land <> 0) then (unix_timestamp(page_end_time, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(page_start_time, 'yyyy-MM-dd HH:mm:ss')) when (is_land_url = 1 and event_id = 'NE001' and is_single_land = 1) then (unix_timestamp(session_end_time, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(page_start_time, 'yyyy-MM-dd HH:mm:ss'))  else 0 end),0)/count(case when (page_url = land_url and event_id = 'NE001') then page_url else null end) land_url_time,
count(case when event_id = 'SE002' then 1 else null end) detail_page_pv,
count(distinct (case when event_id = 'SE002' then visit_id else null end)) detail_page_download_uv,
count(distinct (case when (event_id = 'SE001' and get_json_object(var,'$.loginResult') = '1') then visit_id else null end)) login_succ_uv,
-- count(distinct (case when (page_id like '%PAY-VIP-L%' ) then visit_id else null end)) vip_menu_page_uv,
count(distinct (case when (event_id = 'NE006' and module_id = 'vipPayCon' ) then visit_id else null end)) vip_menu_page_uv,
count(distinct (case when (event_id = 'SE010') then visit_id else null end)) vip_immediate_pay_click_uv,
count(distinct (case when (page_id like '%PAY-VIP-QR%' ) then visit_id else null end)) vip_pay_page_uv,
count(distinct (case when (event_id = 'SE011' and get_json_object(var,'$.payResult') = '1' ) then visit_id else null end)) vip_succ_pay_uv,
sum((case when (event_id = 'SE011' and get_json_object(var,'$.payResult') = '1' ) then cast(get_json_object(var,'$.orderPayPrice') as double)/100 else 0 end)) vip_pay_amount,
count(distinct (case when (event_id = 'SE012') then visit_id else null end)) download_privilege_click_uv,
sum((case when (event_id = 'SE013' and get_json_object(var,'$.payResult') = '1') then cast(get_json_object(var,'$.orderPayPrice') as double)/100 else 0 end)) download_privilege_pay_amount,
count(distinct (case when (event_id = 'SE013' and get_json_object(var,'$.payResult') = '1') then visit_id else null end)) download_privilege_succ_uv,
count(distinct (case when (event_id = 'SE008') then visit_id else null end)) file_immediate_pay_click_uv,
count(distinct (case when (event_id = 'SE009' and get_json_object(var,'$.payResult') = '1') then visit_id else null end))  file_succ_pay_uv,
sum((case when (event_id = 'SE009' and get_json_object(var,'$.payResult') = '1') then cast(get_json_object(var,'$.orderPayPrice') as double)/100 else 0 end)) file_succ_pay_amount
from (
select
b.plan_name,
b.unit_name,
b.keyword_name,
a.session_id,
a.land_url,
a.visit_id,
a.page_url,
a.exit_url,
a.event_id,
a.page_id,
a.var,
a.session_start_time,
a.module_id,
nginx_date page_start_time,
lead(nginx_date,1,0) over(partition by session_id,land_url order by nginx_date) page_end_time,
session_end_time,
a.session_duration,
count(case when event_id = 'NE001' then 1 else null end) over(partition by session_id,land_url)  is_single_land,
case when a.page_url = a.land_url then 1 else 0 end as is_land_url,
unix_timestamp(nginx_date, 'yyyy-MM-dd HH:mm:ss')
from dw_fact.dw_fact_ishare_visit_event a
left join (select concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term')) pc_des_url,max(plan_name) plan_name,max(unit_name) unit_name,max(keyword_name) keyword_name from ods_ods.ods_ods_ishare_baidu_tongji_keyword_mapping group by concat(split(pc_des_url,'utm_term=')[0],'utm_term=',parse_url(pc_des_url,'QUERY','utm_term'))) b
on (b.pc_des_url = concat(split(land_url,'utm_term=')[0],'utm_term=',parse_url(land_url,'QUERY','utm_term')))
where dt='${date_day}'
and land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*')
and land_url not regexp('.*360.*')
and b.keyword_name is not null and b.plan_name is not null and b.unit_name is not null and b.pc_des_url is not null
) c
group by c.plan_name,c.unit_name,c.keyword_name;