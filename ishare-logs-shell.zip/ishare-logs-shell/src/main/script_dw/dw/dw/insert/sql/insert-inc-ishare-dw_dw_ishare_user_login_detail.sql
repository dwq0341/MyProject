insert overwrite table dw_fact.dw_fact_ishare_user_login_detail partition(dt='${date_day}')
select
a.user_id,
a.visit_id,
a.session_id,
a.login_type,
a.event_time login_time,
min(a.event_time) over(partition by a.user_id) first_login_time,
a.ip,
a.pre_page_id login_page,
a.terminal_type,
a.site_type,
c.traffic_source,
c.2th_traffic_source,
b.file_id,
b.file_pay_type
from dw_fact.dw_fact_ishare_log_events a
left join (select max(file_id) file_id,max(file_pay_type) file_pay_type,user_id,page_url,session_id from dw_fact.dw_fact_ishare_log_event_se002 where dt = '${date_day}' group by user_id,page_url,session_id) b
on a.user_id = b.user_id and a.pre_page_url = b.page_url and a.session_id = b.session_id
left join (select session_id,traffic_source,'' 2th_traffic_source from dw_fact.dw_fact_ishare_session_info  where dt = '${date_day}') c on a.session_id = c.session_id
where a.event_id = 'SE001' and a.dt = '${date_day}' and a.user_id <> '' and a.user_id is not null ;