set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_tb_settlement_audit_settle
select
id,
seller_id,
seller_nickname,
batch_no,
cast(from_unixtime(cast((cast(settle_start_date as bigint))/1000 as bigint), 'yyyy-MM-dd') as string) settle_start_date,
cast(from_unixtime(cast((cast(settle_end_date as bigint))/1000 as bigint), 'yyyy-MM-dd') as string) settle_end_date,
seller_type,
total_transaction_amount,
total_refund_amount,
seller_total_revenue,
status,
creator_id,
creator_name,
modifier_id,
modifier_name,
cast(from_unixtime(cast((cast(create_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) create_time,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
enable
from ods_ods.ods_ods_ishare_tb_settlement_audit_settle;