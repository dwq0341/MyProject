insert overwrite table dw_dw.dw_dw_ishare_log_sem_plan partition(dt = '${date_day}')
select
	a.user_name,
    a.fc_plan_id,
    a.fc_plan_name,
    a.display_num,
    a.click_num,
    a.cash,
    a.click_rate,
    a.avg_click_price,
    b.pv_num,
    b.uv_num,
    b.avg_visit_page,
    b.avg_visit_duration,
    b.land_url_pv,
    b.land_url_uv,
	b.land_url_uv/a.click_num page_transform,
	b.single_land_num/b.uv_num jump_rate,
    b.land_url_time,
    b.detail_page_pv,
    b.detail_page_download_uv,
	b.detail_page_download_uv/b.land_url_uv,
    b.login_succ_uv,
	b.login_succ_uv/b.land_url_uv,
	c.total_pay_price,
	c.total_pay_user,
	c.unit_order_price,
	c.total_pay_price/a.cash,
	'${date_day}' dt_time,
	b.vip_menu_page_uv,
	b.vip_menu_page_uv/b.land_url_uv vip_menu_page_uv_transform_rate,
	b.vip_immediate_pay_click_uv,
	b.vip_immediate_pay_click_uv/b.land_url_uv vip_immediate_pay_click_uv_transform_rate,
	b.vip_pay_page_uv,
	b.vip_pay_page_uv/b.land_url_uv vip_pay_page_uv_transform_rate,
	c.vip_succ_pay_uv,
	c.vip_succ_pay_uv/b.land_url_uv vip_succ_pay_uv_transform_rate,
	c.vip_pay_amount,
	c.vip_pay_amount/c.vip_succ_pay_uv unit_vip_pay_amount,
	c.vip_pay_amount/a.cash vip_pay_amount_roi,
	b.download_privilege_click_uv,
	c.download_privilege_pay_amount,
	c.download_privilege_succ_uv,
	c.download_privilege_pay_amount/c.download_privilege_succ_uv unit_download_privilege_pay_amount,
	c.download_privilege_pay_amount/a.cash download_privilege_pay_roi,
	b.file_immediate_pay_click_uv,
	c.file_succ_pay_uv,
	c.file_succ_pay_uv/b.land_url_uv file_succ_pay_uv_transform_rate,
	c.file_succ_pay_amount,
	c.file_succ_pay_amount/c.file_succ_pay_uv unit_file_succ_pay_amount,
	c.file_succ_pay_amount/a.cash file_succ_pay_roi,
	cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_plan a
left join (select * from dw_fact.dw_fact_ishare_sem_bury_point_plan where dt = '${date_day}') b
on  a.user_name = b.account
and a.fc_plan_name = b.plan_name
left join
(select * from dw_fact.dw_fact_ishare_sem_order_info_plan where dt = '${date_day}') c
on a.user_name = c.account
and a.fc_plan_name = c.plan_name
where a.dt = '${date_day}';