set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_bl_cnzz_app_operate_info partition(dt)
select
id,
dayno,
siteId,
siteName,
newUserCount,
activeUserCount,
startTimes,
nextRemainRate,
avgUseTime,
weekAvgUseTime,
weekActiveUserRate,
newUserRetention,
activeUserRetention,
weekActiveUserCount,
replace(substr(dayno,0,7),'-','') dt
from ods_ods.ods_ods_ishare_bl_cnzz_app_operate_info;