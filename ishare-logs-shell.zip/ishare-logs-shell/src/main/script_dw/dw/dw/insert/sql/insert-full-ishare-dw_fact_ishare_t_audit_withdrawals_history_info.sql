insert overwrite table dw_fact.dw_fact_ishare_t_audit_withdrawals_history_info
select
id,
withdrawId,
auditUserId,
auditUserName,
workFlowFlag,
cast(from_unixtime(cast((cast(auditTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) auditTime,
auditStatus,
remark,
auditWorkFlowNo
from ods_ods.ods_ods_ishare_t_audit_withdrawals_history_info;