with user_info as(
select c.union_id,c.open_id,c.app_id,d.name from dw_Fact.dw_fact_tb_message_wechat_public_user c
left join dw_Fact.dw_fact_tb_message_wechat_info d on c.app_id = d.app_id
)

insert overwrite table dw_Fact.dw_Fact_ishare_social_pub_account_stat
select
concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)) stat_date,
COALESCE(info.name,fans.name) pub_account,
COALESCE(info.incr_concern_user,0) incr_concern_user,
COALESCE(info.cancel_concern_user,0) cancel_concern_user,
COALESCE(info.net_concern_user,0) net_concern_user,
COALESCE(info.acc_concern_user,0) acc_concern_user,
COALESCE(fans.connect_user,0) connect_user,
COALESCE(fans.connect_user_seven,0) connect_user_seven,
COALESCE(fans.connect_user_month,0) connect_user_month,
COALESCE(info.int_page_read_user,0) int_page_read_user,
COALESCE(info.int_page_read_count,0) int_page_read_count,
COALESCE(info.add_to_fav_user,0) add_to_fav_user,
COALESCE(info.add_to_fav_count,0) add_to_fav_count,
COALESCE(info.share_user,0) share_user,
COALESCE(info.share_count,0) share_count,
COALESCE(info.share_rate,0) share_rate,
COALESCE(info.add_to_fav_rate,0) add_to_fav_rate,
COALESCE(info.avg_read_count,0) avg_read_count,
COALESCE(info.friend_share_read,0) friend_share_read,
COALESCE(info.wechat_moments_share_count,0) wechat_moments_share_count,
COALESCE(info.share_read_rate,0) share_read_rate
from (
select
COALESCE(name,'') name,
count(distinct (case when e.create_time = concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)) then e.open_id else null end)) connect_user,
count(distinct (case when e.create_time <= concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)) and e.create_time >= date_sub(concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)),7)  then e.open_id else null end)) connect_user_seven,
count(distinct (case when e.create_time <= concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)) and e.create_time >= date_sub(concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)),30) then e.open_id else null end)) connect_user_month
from (select
union_id,open_id,event_id,substr(create_time,0,10) create_time
from dw_Fact.dw_fact_tb_message_wechat_report_data where dt in ('202103','202104') and event_id in ('FE001','FE003') 
group by union_id,open_id,event_id,substr(create_time,0,10)) e 
left join user_info f on e.open_id = f.open_id
where f.open_id is not null
group by COALESCE(name,'')) fans
full join
(
select
d.name,
b.new_user incr_concern_user,
b.cancel_user cancel_concern_user,
b.new_user-b.cancel_user net_concern_user,
a.cumulate_user acc_concern_user,
coalesce(c.int_page_read_user,0) int_page_read_user,
coalesce(c.int_page_read_count,0) int_page_read_count,
coalesce(c.add_to_fav_user,0) add_to_fav_user,
coalesce(c.add_to_fav_count,0) add_to_fav_count,
coalesce(c.share_user,0) share_user,
coalesce(c.share_count,0) share_count,
coalesce(share_user/int_page_read_user,0) share_rate,   --分享率
coalesce(add_to_fav_user/int_page_read_user,0) add_to_fav_rate,  --收藏率
coalesce(int_page_read_user/int_page_read_count,0) avg_read_count,  --人均阅读次数
0 friend_share_read,
0 wechat_moments_share_count,
0 share_read_rate
from ods_ods.ods_ods_ishare_db_mongo_tb_message_wechat_mp_user_cumulate a 
left join (select app_id,sum(new_user) new_user,sum(cancel_user) cancel_user from ods_ods.ods_ods_ishare_db_mongo_tb_message_wechat_mp_user_summary where ref_date = concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)) group by app_id ) b on a.app_id = b.app_id
left join (select app_id,sum(int_page_read_user) int_page_read_user,sum(int_page_read_count) int_page_read_count,sum(add_to_fav_user) add_to_fav_user,sum(add_to_fav_count) add_to_fav_count,sum(share_user) share_user,sum(share_count) share_count from ods_ods.ods_ods_ishare_db_mongo_tb_message_wechat_mp_article_summary where ref_date = concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2)) group by app_id) c on b.app_id = c.app_id
left join dw_Fact.dw_fact_tb_message_wechat_info d on a.app_id = d.app_id
where a.ref_date = concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2))) info on fans.name = info.name
and fans.name is not null and fans.name <> '' and info.name is not null and info.name <> ''
union all
select
stat_date,
pub_account,
incr_concern_user,
cancel_concern_user,
net_concern_user,
acc_concern_user,
connect_user,
connect_user_seven,
connect_user_month,
int_page_read_user,
int_page_read_count,
add_to_fav_user,
add_to_fav_count,
share_user,
share_count,
share_rate,
add_to_fav_rate,
avg_read_count,
friend_share_read,
wechat_moments_share_count,
share_read_rate
from dw_Fact.dw_Fact_ishare_social_pub_account_stat where stat_date <> concat_ws('-',substr('${date_day}',0,4),substr('${date_day}',5,2),substr('${date_day}',7,2));
