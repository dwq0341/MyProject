#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3


#two_day_ago= `date -d "${date_day} -1day" +%Y%m%d`
two_day_ago=`date -d "2 days ago" +%Y%m%d`
beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  --hivevar two_day_ago=${two_day_ago} --hivevar date_day=${date_day} --hivevar start_date=${start_date} --hivevar end_date=${end_date}  -f ../sql/insert-inc-ishare-dw_fact_ishare_sem_bury_point_unit.sql
