insert overwrite table dw_fact.dw_fact_ishare_session_info_user_mapping partition(dt='${date_day}')
select session_id,users.* from dw_fact.dw_fact_ishare_session_info a
lateral view explode(split(a.user_id,',')) users as user_id
where a.dt ='${date_day}' and a.user_id <> '' and a.user_id is not null;