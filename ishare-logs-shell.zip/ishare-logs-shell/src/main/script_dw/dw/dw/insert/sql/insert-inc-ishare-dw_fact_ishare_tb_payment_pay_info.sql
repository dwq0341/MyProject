insert overwrite table dw_fact.dw_fact_ishare_tb_payment_pay_info
select
id,
order_no,
pay_no,
out_pay_no,
status,
type,
creator_id,
creator_name,
modifier_id,
modifier_name,
cast(from_unixtime(cast((cast(create_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) create_time,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
product_code,
enable,
price,
out_status,
out_price,
cast(from_unixtime(cast((cast(pay_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) pay_time
from ods_ods.ods_ods_ishare_tb_payment_pay_info;