set hive.execution.engine=spark;
set hive.auto.convert.join=true;
set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_order_info_facts partition(mth)
select
id,
order_time,
order_status,
goods_id,
goods_name,
goods_type,
buyer_user_id,
b.uuid,
b.session_id,
c.traffic_source,
c.utm_source,
c.utm_content,
c.utm_medium,
c.utm_term,
c.utm_campaign,
pay_price,
platform_price,
seller_price,
channel_source,
source_mode,
c.land_url,
replace(substr(order_time,0,7),'-','') mth
from dw_fact.dw_fact_ishare_t_order_info a

left join(
select
    uuid,
    session_id,
    get_json_object(var,'$.orderID') order_id
from ods_ods.ods_ods_ishare_log
where event_id='SE033'
) b on a.id=b.order_id

left join(
select
session_id,
traffic_source,
utm_source,
utm_content,
utm_medium,
utm_term,
utm_campaign,
land_url
from dw_fact.dw_fact_ishare_session_info
) c on b.session_id=c.session_id