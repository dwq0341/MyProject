set mapreduce.map.memory.mb=8192;
set hive.exec.reducers.bytes.per.reducer=1000000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
set hive.exec.dynamic.partition=true;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_visit_event partition(dt='${date_day}')
select
session_id,               --会话id
event_id,                 --事件id
event_name,               --事件名称
event_type,               --事件类型
event_time,                   --事件时间
nginx_date,   --服务器上传时间
terminal_type,            --终端类型
login_status,             --登录状态
visit_id,                 --访客ID
user_id,                  --用户ID
ip,                       --ip地址
page_id,                  --当前页面编号
page_name,                --当前页面的名称
page_url,                 --当前页面URL
-- max(case when page_url regexp('.*utm_source.*') and page_url regexp('.*utm_medium.*') and page_url regexp('.*utm_campaign.*') and page_url regexp('.*utm_term.*') and page_url not regexp('.*360.*') and parse_url(page_url,'QUERY','utm_source') like '%baidu%' then page_url else null end ) over(partition by visit_id,dt)   land_url,
first_value(case when (parse_url(page_url,'QUERY','utm_source') like '%360%' or parse_url(page_url,'QUERY','utm_source') like '%sougou%' or parse_url(page_url,'QUERY','utm_source') like '%baidu%') then page_url else null end ) over(partition by visit_id ORDER by nginx_date)   land_url,            --落地页url
exit_url,        --退出页url
domain ,           --域名
dom_id,                   --当前触发DOM的编号
dom_name,                 --当前触发DOM的名称
session_position,
session_event_duration,
session_start_time,    --每一个session开始时间
session_end_time,      --每一个session结束时间
session_duration,      --每一个session持续的时间
distinct_pv_count,                                   --访问深度
is_single_pv_session,   --是否单PV会话
session_pv_count,                                               --访问页数
var,                                                                                                                                                                --业务json数据
get_json_object(var,'$.moduleID') module_id,
get_json_object(var,'$.moduleName') module_name
from dw_fact.dw_fact_ishare_session_event where dt='${date_day}';