set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_iask_t_date_iask_total partition(dt)
select
dayno,
pv_cnzz,
uv_cnzz,
ip_cnzz,
new_uv_cnzz,
visitor_cnzz,
avg_pv_cnzz,
avg_depth_cnzz,
avg_visit_time_cnzz,
bounce_rate_cnzz,
terminal,
site,
view,
click,
total_income,
remarks,
ad_operations_income,
baidu_exclusive_income,
campaign_income,
ad_sale_income,
ad_view,
ssp_ad_income,
pv,
uv,
ip,
new_uv,
visits,
avg_pv,
avg_depth,
avg_visit_time,
bounce_rate,
replace(substr(dayno,0,7),'-','') dt
from ods_ods.ods_ods_iask_t_date_iask_total;