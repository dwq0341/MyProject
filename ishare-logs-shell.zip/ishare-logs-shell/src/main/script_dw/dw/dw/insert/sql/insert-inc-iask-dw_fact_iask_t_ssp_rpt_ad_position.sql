set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_iask_t_ssp_rpt_ad_position partition(dt)
select
time,
click,
income,
view,
site,
page_group,
ad_name,
substr(time,0,6) dt
from ods_ods.ods_ods_iask_t_ssp_rpt_ad_position;