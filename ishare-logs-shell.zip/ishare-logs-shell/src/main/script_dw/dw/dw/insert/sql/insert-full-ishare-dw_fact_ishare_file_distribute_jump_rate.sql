set hive.groupby.skewindata=true;
set hive.exec.reducers.bytes.per.reducer=500000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
insert overwrite table dw_fact.dw_fact_ishare_file_distribute_jump_rate
select
    max(visit_id) visit_id,
    file_id
from(
select
visit_id,
event_id,
nginx_date,
get_json_object(var,'$.fileID') file_id,
row_number() over(partition by session_id order by nginx_date desc,event_id asc) session_event
from ods_ods.ods_ods_ishare_log
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and get_json_object(var,'$.fileID') is not null
and get_json_object(var,'$.fileID') <> ''
) log
where log.session_event=1
and log.event_id='SE002'
group by
log.file_id