insert overwrite table dw_fact.dw_fact_ishare_user_member
select
id,                                                                                 --id
userId,                                                                             --用户id
orderId,                                                                            --对应的订单id
status,                                                                             --1.未使用，2使用中 3已	过期 4已退款 5冻结，6后台扣除
scope,                                                                              --使用范围
platformEnums ,                                                                     --适用平台
from_unixtime(cast(beginDate/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') begin_date,    --开始有效时间
from_unixtime(cast(endDate/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') end_date,        --结束有效时间
memberIds,                                                                          --汇总的权益点id集合
vipId,                                                                              --购买的vipId
vipName	,                                                                           --购买的名称
memberPackId,                                                                       --购买的权益包id
userMemberType,                                                                     --权益类型 1vip 2下载特权
from_unixtime(cast(createTime/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') create_time,  --创建时间
enable,                                                                             --enable
class,                                                                              --class
from_unixtime(cast(updateTime/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') update_time   --更新时间
from ods_ods.ods_ods_ishare_user_member;