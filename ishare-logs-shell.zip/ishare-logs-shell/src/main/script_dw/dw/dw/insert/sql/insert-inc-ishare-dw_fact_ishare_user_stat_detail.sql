set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_user_stat_detail partition(is_vip)
select
a.id,
a.userTypeId,
coalesce(b.vip_name,'no_vip') vip_name,
h.downvounousenum,
h.downvouusednum,
c.consume_coupon,
c.own_coupon,
f.pay_price,
g.seller_price,
d.download_file_num,
d.download_free_file_num,
d.download_pay_file_num,
e.upload_vip_file_num,
e.upload_free_file_num,
e.upload_pay_file_num,
case when b.vip_name is not null then 'vip' else 'no_vip' end as is_vip
from
(
select
id,
userTypeId from
(
select
id,
userTypeId,
row_number() over(partition by id order by updatetime desc) sort_num
from
ods_ods.ods_ods_ishare_users_new
where states = '0' ) t where sort_num = 1) a
--此处需要看一下一个用户会不会拥有两个用户身份
left join
--查询用户会员类型
(
select
user_id,
id,
max(vip_id) vip_id,
max(vip_name) vip_name
from dw_fact.dw_fact_ishare_user_member
where user_member_type = 'VIP'
and end_date >= from_unixtime(unix_timestamp() ,'yyyy-MM-dd HH:mm:ss')
and status = '2'
group by user_id,id) b on a.id = b.user_id
left join
--可用下载特权
(
select
uid,
name,
userMemberId,
downvoutotalnum,
downvounousenum,
downvouusednum
from
(
select
uid,
name,
userMemberId,
downvoutotalnum,
downvounousenum,
downvouusednum,
row_number() over(partition by uid,name,userMemberId order by updatetime desc) sort_num
from ods_ods.ods_ods_ishare_t_user_downvolu_record
where from_unixtime(cast(effectiveenddate/1000 as bigint) ,'yyyy-MM-dd HH:mm:ss') >= from_unixtime(unix_timestamp() ,'yyyy-MM-dd HH:mm:ss')) a where sort_num = 1) h
on b.user_id = h.uid and b.id = userMemberId

--优惠券

left join (
select
userId,
count(case when status = '2' then userId else null end) consume_coupon,
count(case when status = '1' and (from_unixtime(cast(endDate/1000 as bigint) ,'yyyy-MM-dd HH:mm:ss') >= from_unixtime(unix_timestamp() ,'yyyy-MM-dd HH:mm:ss')) then userId else null end) own_coupon
from ods_ods.ods_ods_ishare_sale_vouchers_user_new where vStatus = '1'
group by userId
) c on c.userId = b.user_id

--资料分类型
left join(
select
downloader,
count(fileid) download_file_num,
count(case when b.productType = '1' then fileid else null end) download_free_file_num,
count(case when b.productType <> '1' then fileid else null end) download_pay_file_num
from ods_ods.ods_ods_ishare_download_record_new a
left join (select id,max(productType) productType from ods_ods.ods_ods_ishare_file_info_public_new group by id) b on a.fileid = b.id
group by downloader
) d on b.user_id  = d.downloader
left join(
select
uid owner,
count(case when productType = '4' then id else null end) upload_vip_file_num,
count(case when productType = '1' then id else null end) upload_free_file_num,
count(case when productType = '5' then id else null end) upload_pay_file_num
from ods_ods.ods_ods_ishare_file_info_public_new group by uid
) e on b.user_id  = e.owner

--订单金额

left join(
select
buyer_user_id,
sum(pay_price/100) pay_price
from dw_fact.dw_fact_ishare_t_order_info
where order_status = '2'
group by buyer_user_id
) f on b.user_id  = f.buyer_user_id
left join(
select
seller_user_id,
sum(seller_price/100) seller_price
from dw_fact.dw_fact_ishare_t_order_info
where order_status = '2'
group by seller_user_id
) g on b.user_id  = g.seller_user_id
