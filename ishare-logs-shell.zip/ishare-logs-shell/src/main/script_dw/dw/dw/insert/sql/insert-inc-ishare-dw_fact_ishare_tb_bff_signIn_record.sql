set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_bff_signIn_record partition(dt)
select
id,
userId,
cast(from_unixtime(cast((cast(signDate as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) signDate,
signDay,
continueDay,
realContinueDay,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
enable,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM') as string) dt
from ods_ods.ods_ods_ishare_tb_bff_signIn_record;