insert overwrite table dw_fact.dw_fact_ishare_cost_baidu_search_promotion_source partition(dt = '${date_day}')
select
user_name,
sum(display_num) display_num,
sum(click_num) click_num,
round(sum(cash),2) cash,
round(sum(click_num)/sum(display_num),4) click_rate,
round(sum(cash)/sum(click_num),2) avg_click_price
from ods_ods.ods_ods_ishare_cost_baidu_search_promotion_plan
where dt = '${date_day}' and fc_plan_id <> '全部'
group by user_name
