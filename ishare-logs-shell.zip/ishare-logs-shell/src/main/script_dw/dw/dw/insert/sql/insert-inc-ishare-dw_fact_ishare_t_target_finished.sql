set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_target_finished partition(dt)
select
month,
project,
source,
target,
finished,
remark,
month dt
from ods_ods.ods_ods_ishare_t_target_finished;