#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行文件管理小程序页面使用路径数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/social/ishare_app_file_manager_usepath_sync_mth.sh
echo "执行文件管理小程序页面使用路径数据导入sh结束标志"

echo "执行模板类型小程序页面使用路径数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/social/ishare_app_model_type_usepath_sync_mth.sh
echo "执行模板类型小程序页面使用路径数据导入sh结束标志"