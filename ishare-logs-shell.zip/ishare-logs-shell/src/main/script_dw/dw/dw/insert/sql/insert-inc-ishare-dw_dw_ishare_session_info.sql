set hive.exec.reducers.bytes.per.reducer = 1000000000;
set hive.optimize.skewjoin = true;
set mapred.max.split.size=1024000000;
set mapred.min.split.size= 256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
insert overwrite table dw_fact.dw_fact_ishare_session_info partition(dt='${date_day}')
select
session_id,
terminal_type,
site_type,
domain,
device_id,
visit_id,
user_id,
login_status,
browser,
browser_ver,
pre_page_domain land_pre_page_domain,
land_pre_page_url,
land_url,
exit_url,
session_start_time,
session_end_time,
session_duration,
traffic_source,
utm_source,
utm_medium,
utm_campaign,
utm_content,
utm_term,
search_engine,
is_single_pv_session,
visit_deep,
visit_page_count,
order_id,
pay_price,
nginx_date_timestamp
from
(
select
a.session_id,
visit_id,
d.user_id,
d.pay_price,
land_url,
exit_url,
device_id,
domain,
browser,
browser_ver,
pre_page_domain,
site_type,
terminal_type,
max(login_status) over(partition by a.session_id) login_status,
case when land_url not regexp('.*utm_source.*') and (pre_page_url is null or pre_page_url = '') then '直接访问'
when land_url not regexp('.*utm_source.*') and pre_page_url is not null and (pre_page_url like '%so.com%' or pre_page_url like '%baidu.com%' or pre_page_url like '%sogou.com%' or pre_page_url like '%google.com%' or pre_page_url like '%sm.cn%') then '自然搜索'
when land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*') then '渠道投放'
else '其他' end as traffic_source,
case when (count(case when a.event_id = 'NE001' then a.event_id else null end) over(partition by a.session_id)) > 1 then 'N' else 'Y' end as is_single_pv_session,
count((case when event_id = 'NE001' then page_url else null end)) over(partition by a.session_id,a.page_url) visit_deep,
count((case when event_id = 'NE001' then 1 else null end)) over(partition by a.session_id) visit_page_count,
session_start_time session_start_time,
session_end_time session_end_time,
session_duration session_duration,
ROW_NUMBER() over(partition by a.session_id order by a.nginx_date) sort_num,
d.order_id,
case when  parse_url(pre_page_url,'HOST') like '%baidu.com%' then 'baidu'
when parse_url(pre_page_url,'HOST') like '%so.com%' then '360'
when parse_url(pre_page_url,'HOST') like '%google.com%' then 'google'
when parse_url(pre_page_url,'HOST') like '%sogou.com%' then 'sougou'
when parse_url(pre_page_url,'HOST') like '%wenku.so.com%' then '360wenku'
when parse_url(pre_page_url,'HOST') like '%m.baidu.com%' then 'alading'
when parse_url(pre_page_url,'HOST') like '%sm.cn%' then 'sm' else '其他' end as search_engine,
case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end as utm_source,
case when land_url regexp('.*utm_medium.*') then substring(split(land_url,'utm_medium=')[1],0,case when INSTR(split(land_url,'utm_medium=')[1],'&') = 0 then (length(split(land_url,'utm_medium=')[1])) else (INSTR(split(land_url,'utm_medium=')[1],'&') - 1) end) else null end as utm_medium,
case when land_url regexp('.*utm_content.*') then substring(split(land_url,'utm_content=')[1],0,case when INSTR(split(land_url,'utm_content=')[1],'&') = 0 then (length(split(land_url,'utm_content=')[1])) else (INSTR(split(land_url,'utm_content=')[1],'&') - 1) end) end as utm_content,
case when land_url regexp('.*utm_campaign.*') then substring(split(land_url,'utm_campaign=')[1],0,case when INSTR(split(land_url,'utm_campaign=')[1],'&') = 0 then (length(split(land_url,'utm_campaign=')[1])) else (INSTR(split(land_url,'utm_campaign=')[1],'&') - 1) end) end as utm_campaign,
case when land_url regexp('.*utm_term.*') then substring(split(land_url,'utm_term=')[1],0,case when INSTR(split(land_url,'utm_term=')[1],'&') = 0 then (length(split(land_url,'utm_term=')[1])) else (INSTR(split(land_url,'utm_term=')[1],'&') - 1) end) end as utm_term,
land_pre_page_url,
nginx_date_timestamp,
dt
from dw_fact.dw_fact_ishare_session_event a
left join (
select
session_id,
concat_ws(',',collect_set(concat(user_id))) user_id,
concat_ws(',',collect_set(concat(order_id))) order_id,
COALESCE(sum(pay_price),0)/100 pay_price
from (
select
session_id,
user_id,
f.order_id,
max(pay_price) pay_price
from (
select
session_id,
user_id,
event_id,
var,
case when event_id = 'SE034' and g.goods_types is not null and get_json_object(var,'$.result') = '1' then get_json_object(var,'$.orderID') else null end as order_id
from dw_fact.dw_fact_ishare_session_event h
left join
dw_dim.dw_dim_ishare_goods_type_table g on get_json_object(var,'$.goodsType')=g.goods_types
where dt = '${date_day}' and
session_id is not null and session_id <> '' and session_id <> '--'
and user_id <> '' and user_id is not null) f
left join (
select
id,
pay_price
from dw_Fact.dw_fact_ishare_t_order_info
where mth = substr('${date_day}',0,6)
and substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status = '2'
) e on f.order_id = e.id
group by session_id,f.order_id,user_id) c
group by session_id
) d on a.session_id = d.session_id
where dt = '${date_day}') b where sort_num = 1;