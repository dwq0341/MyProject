set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_user_downvolu_record partition(mth)
select
id,
class,
uid,
name,
orderno,
voluchannel,
effectivestartdate,
effectiveenddate,
downvoutotalnum,
downvounoUsenum,
downvouusednum,
status,
type,
scope,
platformEnums,
usermemberid,
createtime,
updatetime,
enable,
dt mth
from(
select
*,
Row_Number() OVER (partition by id order by substr(updatetime,0,10) desc) rank
from ods_ods.ods_ods_ishare_t_user_downvolu_record
) a
where a.rank=1