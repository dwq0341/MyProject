insert overwrite table dw_fact.dw_fact_tb_message_wechat_info
  select
  id,
  name,
  ghz_id,
  describes,
  app_id,
  app_secret,
  site_code,
  wechat_type,
  medium,
  from_unixtime(cast((cast(create_time as bigint))/1000 as bigint)) create_time,
  creator_name,
  creator_id,
  modifier_id,
  modifier_name,
  from_unixtime(cast((cast(update_time as bigint))/1000 as bigint)) update_time,
  enable,
  class
  from ods_ods.ods_ods_tb_message_wechat_info;