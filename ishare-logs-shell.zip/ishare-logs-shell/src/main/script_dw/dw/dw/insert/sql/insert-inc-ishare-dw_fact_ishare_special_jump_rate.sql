set hive.exec.reducers.bytes.per.reducer=500000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
insert overwrite table dw_fact.dw_fact_ishare_special_jump_rate
select
    a.visit_id,
    a.event_id,
    a.file_id
from(
select
    visit_id,
    event_id,
    file_id,
    ztID,
    session_event
from(
select
    visit_id,
    event_id,
    nginx_date,
    get_json_object(var,'$.fileID') file_id,
    case when event_id='SE002' and pre_page_url like '%/s/%' then get_url(pre_page_url) else pre_page_url end ztID,
    row_number() over(partition by session_id order by nginx_date desc, event_id asc) session_event
from ods_ods.ods_ods_ishare_log
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) log
where log.event_id='SE002'
and log.session_event=1
and log.ztID is not null
and log.ztID <> ''
) a
left join(
select
    id,
    topic_name
from dw_fact.dw_fact_ishare_tb_special_topic_info
) b on a.ztID=b.id
where b.id is not null