insert overwrite table dw_fact.dw_fact_ishare_tb_content_category
select
id,
class,
name,
father,
creatorId,
creatorName,
createTime,
modifierId,
modifierName,
updateTime
from ods_ods.ods_ods_ishare_tb_content_category;