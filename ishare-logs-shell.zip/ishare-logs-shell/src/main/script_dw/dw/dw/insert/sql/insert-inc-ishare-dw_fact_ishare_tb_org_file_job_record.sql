set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_org_file_job_record partition(mth)
select
id,
job_id,
fid,
title,
format,
page,
status,
remark,
repeat_id,
create_time,
dt mth
from ods_ods.ods_ods_ishare_tb_org_file_job_record;