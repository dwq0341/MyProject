set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_t_user_auth_apply_info_new
select
id,
class,
userid,
nickname,
realname,
authtype,
idcardno,
idcardfrontpic,
idcardbackpic,
handfrontidcardpic,
credentialspic,
authappellation,
workunit,
personprofile,
personweibo,
phonenumber,
qqnumber,
cast(from_unixtime(cast((cast(createtime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createtime,
auditstatus,
iasknick,
auditnopassreason,
cast(from_unixtime(cast((cast(audittime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) audittime,
audituserid,
audituser
from ods_ods.ods_ods_ishare_t_user_auth_apply_info_new;