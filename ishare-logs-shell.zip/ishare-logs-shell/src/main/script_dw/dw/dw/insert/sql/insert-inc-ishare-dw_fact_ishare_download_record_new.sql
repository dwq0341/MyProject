set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_download_record_new partition(mth)
select
id,
class,
type,
fileid,
owner,
downloader,
updatetime,
ip,
showflag,
source,
fileType,
downLoadGoodsType,
site,
dt mth
from(
select
*,
Row_Number() OVER (partition by id order by substr(updatetime,0,10) desc) rank
from ods_ods.ods_ods_ishare_download_record_new
) a
where a.rank=1