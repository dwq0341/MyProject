set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_login_user partition(mth)
select
id,
code,
mobile,
nick_name,
user_name,
headimg_url,
cast(from_unixtime(cast((cast(create_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) create_time,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
nation_code,
cast(from_unixtime(cast((cast(last_login_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) lastLogin_time,
password,
ip,
terminal,
status,
brock_at,
cast(from_unixtime(cast((cast(brock_times as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) brock_times,
is_hint_bind,
enable,
mth
from ods_ods.ods_ods_ishare_tb_login_user;