insert overwrite table dw_fact.dw_fact_ishare_t_organize_auth_apply_info_new
select
id,
userId,
nickName,
organizeIndustryType,
organizeName,
organizeWebsite,
organizeProfile,
organizeAddress,
logoPic string,
businessLicensePic,
contactNumber,
qqNumber,
email,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
auditStatus,
iaskNick,
auditNoPassReason,
cast(from_unixtime(cast((cast(auditTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) auditTime,
auditUserId,
auditUser
from ods_ods.ods_ods_ishare_t_organize_auth_apply_info_new;