set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_file_info_convert_info partition(mth)
select
id,
class,
fileId,
fileName,
extension,
isDelOldConvert,
convertPngMd5,
pngInf,
convertHtmlMd5,
htmlInf,
pageCount,
fileStatus,
convertStatus,
uploadStatus,
createtime,
fileSize,
filePngSize,
fileHtmlSize,
convertFailCount,
uploadFailCount,
fileSmallPics,
dt mth
from ods_ods.ods_ods_ishare_file_info_convert_info;