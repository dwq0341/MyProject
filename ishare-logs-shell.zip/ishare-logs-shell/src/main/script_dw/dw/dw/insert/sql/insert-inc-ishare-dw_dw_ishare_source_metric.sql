set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_source_metric partition(dt='${date_day}')
select
concat(substr(m.counttime,1,4),'-',substr(m.counttime,5,2),'-',substr(m.counttime,7,2)) count_time,
m.1th_traffic_source,
m.2th_traffic_source,
m.site_type,
m.terminal_type,
m.pv,
m.uv,
s.down_success_num,
s.order_num,
s.pay_cus_num,
s.income
 from
(
select
a.dt counttime,
b.1th_traffic_source,
b.2th_traffic_source,
COALESCE(a.site_type,'') site_type,
COALESCE(a.terminal_type,'') terminal_type,
count(a.visit_id) pv,
count(distinct a.visit_id) uv
from dw_fact.dw_fact_ishare_log_event_ne001 a
left join (select COALESCE(1th_traffic_source,'') 1th_traffic_source,COALESCE(2th_traffic_source,'') 2th_traffic_source,session_id from dw_fact.dw_fact_ishare_session_info where dt in (from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${date_day}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-mm-dd'),'yyyyMMdd'),'${date_day}') ) b on a.session_id = b.session_id
where a.dt in (from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${date_day}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-mm-dd'),'yyyyMMdd'),'${date_day}')
group by
b.1th_traffic_source,
b.2th_traffic_source,
COALESCE(a.site_type,''),
COALESCE(a.terminal_type,''),
a.dt) m
left join (
select
a.dt counttime,
c.1th_traffic_source,
c.2th_traffic_source,
COALESCE(a.site_type,'') site_type,
COALESCE(a.terminal_type,'') terminal_type,
count(case when a.down_result = '1' and a.event_id = 'SE014' then a.down_result else null end) as down_success_num,
count(distinct case when a.pay_result = '1' and a.event_id = 'SE009' then a.order_id else null end ) as order_num,
count(distinct case when a.pay_result = '1' and a.event_id = 'SE009' then a.visit_id else null end ) as pay_cus_num,
sum(case when b.orderstatus = '2' and a.event_id = 'SE009' then b.payprice else 0 end ) income
from dw_fact.dw_fact_ishare_log_events a  -- 同一个event事件上报多次问题
left join ods_ods.ods_ods_ishare_t_order_info b on a.order_id = b.id   -- 订单出现两次了怎么办
left join (select COALESCE(1th_traffic_source,'') 1th_traffic_source,COALESCE(2th_traffic_source,'') 2th_traffic_source,session_id from dw_fact.dw_fact_ishare_session_info where dt in (from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${date_day}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-mm-dd'),'yyyyMMdd'),'${date_day}') ) c on a.session_id = c.session_id
where a.dt in (from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${date_day}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-mm-dd'),'yyyyMMdd'),'${date_day}')
group by
c.1th_traffic_source,
c.2th_traffic_source,
COALESCE(a.site_type,''),
COALESCE(a.terminal_type,''),
a.dt
) s on m.1th_traffic_source = s.1th_traffic_source and m.2th_traffic_source = s.2th_traffic_source and m.site_type = s.site_type and m.terminal_type = s.terminal_type and m.counttime = s.counttime;