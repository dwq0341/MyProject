set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_tb_special_topic_content
select
id,
specialTopicId,
contentId,
contentName,
cast(from_unixtime(cast((cast(contentCreateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) contentCreateTime,
stickStatus,
sort,
dimensionId,
propertyIdList,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
creatorName,
creatorId,
enable,
modifierId,
modifierName,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updateTime,
contentProductType
from ods_ods.ods_ods_ishare_tb_special_topic_content;