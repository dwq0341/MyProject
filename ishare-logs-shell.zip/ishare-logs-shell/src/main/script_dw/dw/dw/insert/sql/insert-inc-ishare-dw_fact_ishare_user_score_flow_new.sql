set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_user_score_flow_new partition(mth)
select
id,
class,
userid,
reason,
score,
cscore,
expval,
cexpval,
fileid,
createtime,
enable,
dt mth
from ods_ods.ods_ods_ishare_user_score_flow_new;