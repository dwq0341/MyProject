set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_tb_special_topic_info
select
id,
topicName,
topicDescription,
templateCode,
createType,
dimensionStatus,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
creatorName,
creatorId,
modifierId,
modifierName,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updateTime,
enable
from ods_ods.ods_ods_ishare_tb_special_topic_info;