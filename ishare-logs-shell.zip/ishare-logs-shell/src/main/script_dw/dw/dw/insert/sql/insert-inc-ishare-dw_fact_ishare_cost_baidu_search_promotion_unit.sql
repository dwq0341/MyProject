insert overwrite table dw_fact.dw_fact_ishare_cost_baidu_search_promotion_unit partition(dt = '${date_day}')
select
user_name,
fc_plan_name,
fc_plan_id,
fc_unit_name,
fc_unit_id,
sum(display_num) display_num,
sum(click_num) click_num,
round(sum(cash),2) cash,
round(sum(click_num)/sum(display_num),4) click_rate,
round(sum(cash)/sum(click_num),2) avg_click_price
from ods_ods.ods_ods_ishare_cost_baidu_search_promotion_unit
where dt = '${date_day}' and user_name <> '全部'
group by fc_plan_name,fc_unit_name,user_name,fc_plan_id,fc_unit_id
union all
select
user_name,
fc_plan_name,
'全部' fc_plan_id,
fc_unit_name,
'全部' fc_unit_id,
sum(display_num) display_num,
sum(click_num) click_num,
round(sum(cash),2) cash,
round(sum(click_num)/sum(display_num),4) click_rate,
round(sum(cash)/sum(click_num),2) avg_click_price
from ods_ods.ods_ods_ishare_cost_baidu_search_promotion_unit
where dt = '${date_day}' and user_name = '全部'
group by fc_plan_name,fc_unit_name,user_name;

--并入爱问科技02权限账户单元数据
insert overwrite table dw_fact.dw_fact_ishare_cost_baidu_search_promotion_unit partition(dt = '${date_day}')
select
user_name,
fc_plan_name,
fc_plan_id,
fc_unit_name,
fc_unit_id,
sum(display_num) display_num,
sum(click_num) click_num,
round(sum(cash),2) cash,
round(sum(click_num)/sum(display_num),4) click_rate,
round(sum(cash)/sum(click_num),2) avg_click_price
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_unit
where dt='${date_day}' and user_name <> '全部'
group by fc_plan_name,fc_unit_name,user_name,fc_plan_id,fc_unit_id

union all
select
'全部' user_name,
fc_plan_name,
'全部' fc_plan_id,
fc_unit_name,
'全部' fc_unit_id,
sum(display_num) display_num,
sum(click_num) click_num,
round(sum(cash),2) cash,
round(sum(click_num)/sum(display_num),4) click_rate,
round(sum(cash)/sum(click_num),2) avg_click_price
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_unit
where dt = '${date_day}'
and (user_name = '全部' or user_name in('爱问办公1','爱问科技06','爱问科技15'))
and fc_plan_name <> '全部'
group by fc_plan_name,fc_unit_name

--单独算全部总数
union all
select
    a.user_name,
    a.fc_plan_name,
    '全部' fc_plan_id,
    a.fc_unit_name,
    '全部' fc_unit_id,
    sum(a.display_num + b.display_num) display_num,
    sum(a.click_num + b.click_num) click_num,
    sum(a.cash + b.cash) cash,
    round(sum(a.click_num + b.click_num) / sum(a.display_num + b.display_num),4) click_rate,
    round(sum(a.cash + b.cash) / sum(a.click_num + b.click_num),2) avg_click_price
from(
select
user_name,
fc_plan_name,
'全部' fc_plan_id,
fc_unit_name,
'全部' fc_unit_id,
display_num,
click_num,
cash,
click_rate,
avg_click_price
from ods_ods.ods_ods_ishare_cost_baidu_search_promotion_unit
where dt = '${date_day}'
and user_name = '全部'
and fc_plan_name='全部'
) a

left join(
select
'全部' user_name,
fc_plan_name,
'全部' fc_plan_id,
fc_unit_name,
'全部' fc_unit_id,
sum(display_num) display_num,
sum(click_num) click_num,
round(sum(cash),2) cash,
round(sum(click_num)/sum(display_num),4) click_rate,
round(sum(cash)/sum(click_num),2) avg_click_price
from ods_ods.ods_ods_ishare_cost_baidu_search_promotion_unit
where dt = '${date_day}'
and user_name in('爱问办公1','爱问科技06','爱问科技15')
and fc_plan_name = '全部'
group by fc_plan_name,fc_unit_name
) b on a.user_name = b.user_name
group by a.user_name, a.fc_unit_name, a.fc_plan_name