set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_tb_message_wechat_report_data partition(dt)
select
  id,
  create_time,
  get_json_object(report_data,'$.eventID') event_id,
  get_json_object(report_data,'$.eventName') event_name,
  get_json_object(report_data,'$.userID') user_id,
  get_json_object(report_data,'$.subscribe') subscribe,
  get_json_object(report_data,'$.openid') open_id,
  get_json_object(report_data,'$.nickname') nick_name,
  get_json_object(report_data,'$.sex') sex,
  get_json_object(report_data,'$.city') city,
  get_json_object(report_data,'$.country') country,
  get_json_object(report_data,'$.province') province,
  get_json_object(report_data,'$.language') language,
  get_json_object(report_data,'$.headimgurl') headimg_url,
  get_json_object(report_data,'$.subscribe_time') subscribe_time,
  get_json_object(report_data,'$.unionid') union_id,
  get_json_object(report_data,'$.remark') remark,
  get_json_object(report_data,'$.groupid') group_id,
  get_json_object(report_data,'$.tagid_list') tagid_list,
  get_json_object(report_data,'$.subscribe_scene') subscribe_scene,
  get_json_object(report_data,'$.qr_scene') qr_scene,
  get_json_object(report_data,'$.qr_scene_str') qr_scene_str,
  class,
  dt
  from ods_ods.ods_ods_tb_message_wechat_report_data where dt = substr('${date_day}',0,6);