set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_t_bdmini partition(dt)
select
id,
dayno,
site_id,
domain,
visit,
uv,
old_user,
new_user,
pv,
average_use_time,
act_retention_two,
inc_retention_two,
substr(dayno,0,6) dt
from ods_ods.ods_ods_ishare_t_bdmini;