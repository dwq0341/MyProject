set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_t_user_finance_info_new
select
id,
uid,
bankAccountName,
bankAccountNo,
provinceName,
cityName,
bankName,
bankBranchName,
invoice,
taxId,
taxFee,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updateTime,
status
from ods_ods.ods_ods_ishare_t_user_finance_info_new;