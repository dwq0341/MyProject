set hive.execution.engine=spark;
insert overwrite table dw_fact.dw_fact_ishare_file_info_dimension_sort
select
    dime.uid,
    dime.create_time
from(
select
    uid,
    create_time,
    row_number() over(partition by uid order by create_time) row_num
from dw_dim.dw_dim_ishare_file_info_dimension
) dime
where dime.row_num=1