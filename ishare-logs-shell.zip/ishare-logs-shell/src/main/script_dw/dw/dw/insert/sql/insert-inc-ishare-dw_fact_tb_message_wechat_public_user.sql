insert overwrite table dw_fact.dw_fact_tb_message_wechat_public_user
  select
  id,
  app_id,
  open_id,
  nick_name,
  sex,
  city,
  country,
  province,
  from_unixtime(cast((cast(subscribe_time as bigint))/1000 as bigint)) subscribe_time,
  union_id,
  subscribe_status,
  from_unixtime(cast((cast(create_time as bigint))/1000 as bigint)) create_time,
  enable,
  class,
  from_unixtime(cast((cast(update_time as bigint))/1000 as bigint)) update_time
  from ods_ods.ods_ods_tb_message_wechat_public_user;