insert overwrite table dw_fact.dw_fact_ishare_t_user_level_new
select
id,
name,
level,
userTypeId,
empiricalDown,
empiricalUp,
moneyShare,
status,
operationName,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
operatorId,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updateTime
from ods_ods.ods_ods_ishare_t_user_level_new;