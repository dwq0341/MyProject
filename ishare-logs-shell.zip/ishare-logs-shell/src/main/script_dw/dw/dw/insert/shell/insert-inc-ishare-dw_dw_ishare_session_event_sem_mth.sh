#!/bin/bash

source ../../../../common/env/hive_env.sh
excute_day_event=`date -d "yesterday ${today}" +%Y%m%d`

beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  --hivevar stat_day_now_event=${excute_day_event} -f ../sql/insert-inc-ishare-dw_dw_ishare_session_event_sem_mth.sql
