set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_sale_vouchers_user_new
select
id,
class,
userId,
vouchersId,
status,
vStatus,
cast(from_unixtime(cast((cast(reciveDate as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) reciveDate,
cast(from_unixtime(cast((cast(beginDate as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) beginDate,
cast(from_unixtime(cast((cast(endDate as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) endDate,
source,
enable,
orderId
from ods_ods.ods_ods_ishare_sale_vouchers_user_new;