set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_user_file_sns partition(mth)
select
id,
class,
uid,
downSum,
uploadSum,
readSum,
starPeopleSum,
starScoreSum,
collectSum,
scoreSum,
medownSum,
expVal,
volume,
privilege,
balance,
aibeans,
browseSum,
updatetime,
startIndex,
dt mth
from ods_ods.ods_ods_ishare_user_file_sns;