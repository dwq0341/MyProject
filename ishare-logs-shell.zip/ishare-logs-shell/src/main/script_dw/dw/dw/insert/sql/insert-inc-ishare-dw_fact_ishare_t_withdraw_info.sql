set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_t_withdraw_info
select
id,
sellerUserId,
sellerUserTypeId,
sellerUserName,
sellerUserTypeName,
orderTotalPrice,
platformPretaxTotalPrice,
sellerPretaxTotalPrice,
iosPretaxTotalPrice,
withholdingTaxPrice,
withdrawTotalPrice,
withdrawApplyTime,
withdrawStatus,
auditWorkFlowNo,
workFlowFlag,
auditUserId,
auditUserName,
userOpt,
platUpdateAfterWithdPrice,
transferTax,
finalWithPrice,
updateTime,
withdrawRespCode,
withdrawTime
from ods_ods.ods_ods_ishare_t_withdraw_info;