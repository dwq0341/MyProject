set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_content_folder_file partition(mth)
select
id,
class,
fileId,
type,
fileName,
folderId,
uid,
source,
size,
stickStatus,
desktopStatus,
terminal,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updatetime,
enable,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyyMM') as string) mth
from ods_ods.ods_ods_ishare_tb_content_folder_file;