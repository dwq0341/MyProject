set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_market_front_node partition(dt)
select
id,
name,
node_code,
content_type,
type,
status,
sort,
father_code,
root_code,
url,
creator_id,
creator_name,
cast(from_unixtime(cast((cast(create_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) create_time,
modifier_id,
modifier_name,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
enable,
cast(from_unixtime(cast((cast(update_time as bigint))/1000 as bigint), 'yyyyMM') as string) dt
from ods_ods.ods_ods_ishare_tb_market_front_node;