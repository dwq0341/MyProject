set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_fact.dw_fact_ishare_tb_goods_info partition(dt)
select
id,
name,
type,
typeId,
site,
status,
saleType,
price,
classId,
sellerUserId,
cast(from_unixtime(cast((cast(createTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) createTime,
creatorName,
creatorId,
modifierId,
modifierName,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as string) updatetime,
enable,
attributes,
cast(from_unixtime(cast((cast(updateTime as bigint))/1000 as bigint), 'yyyyMM') as string) dt
from ods_ods.ods_ods_ishare_tb_goods_info;