
#!/bin/bash
source ../../../../common/env/hive_env.sh


beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  -f ../sql/create-full-ishare-dw_dw_ishare_t_order_info.sql