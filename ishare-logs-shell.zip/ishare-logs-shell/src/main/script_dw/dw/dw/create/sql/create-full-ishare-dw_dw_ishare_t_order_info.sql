drop table if exists dw_dim.dw_dim_ishare_t_order_info;
create table if not exists dw_dim.dw_dim_ishare_t_order_info(
id string,
buyerUserId	string ,
buyerUserName	string ,
sellerMoneyShare	string,
goodsType	string ,
goodsName	string ,
goodsId	string ,
voluNum	string ,
payPrice	string ,
platformPrice	string ,
orderStatus	string ,
orderTime	string ,
userOpt string,
refundStatus	string ,
withdrawStatus	string ,
payType	string ,
payTime	string ,
sourceMode	string ,
billStatus	string ,
billRemark	string ,
cannelTime string

)
partitioned by (dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
COLLECTION ITEMS TERMINATED BY ','
map keys terminated by ':'
STORED AS parquet  tblproperties ("orc.compress"="SNAPPY");