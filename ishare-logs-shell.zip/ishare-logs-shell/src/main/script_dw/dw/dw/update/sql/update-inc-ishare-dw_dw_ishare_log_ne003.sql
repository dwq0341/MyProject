set mapred.child.java.opts=-Xmx1024m;
set mapreduce.map.java.opts=-Xmx1310m;
set yarn.app.mapreduce.am.command-opts=-Xmx2457m;
set mapreduce.reduce.java.opts=-Xmx2620m;
insert overwrite table dw_dw.dw_dw_ishare_log_ne003 partition(dt='${date_day}')
select
cip,
module_id,
module_name,
event_type,
event_id,
event_time,
event_name,
report_time,
sdk_version,
terminal_type,
login_status,
visit_id,
user_id,
session_id,
product_name,
product_code,
product_ver,
app_channel,
pre_page_id,
pre_page_name,
pre_page_url,
page_id,
page_name,
page_url,
dom_id,
dom_name,
dom_url,
ip,
location,
device_id,
device_brand,
device_model,
device_language,
mac,
os_type,
os_ver,
network_type,
network_provider,
resolution,
browser_ver,
get_json_object(var,'$.fileID') file_id,
get_json_object(var,'$.fileName') file_name,
nginx_date,
etl_date,
concat(split(page_url,'.com.cn')[0],'.com.cn') domain
from ods_ods.ods_ods_ishare_log_new  where event_id='NE003' and event_type is not null
and event_id is not null and event_name is not null and event_time is not null and report_time is not null and terminal_type is not null
and product_name is not null and product_code is not null and product_ver is not null
and dt='${date_day}'
--and substr(nginx_date,1,8)>= ${start_date} and substr(nginx_date,1,8)<${end_date};