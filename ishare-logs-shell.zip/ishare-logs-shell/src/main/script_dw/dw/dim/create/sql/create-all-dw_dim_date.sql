drop table if exists  dw_dim.dw_dim_date;
create table dw_dim.dw_dim_date (
  date_code string,
  week_code string,
  mouth_code string,
  year_code string,
  weekday_code string,
  defined_week string,
  quarter_code string,
  ym string,
  week_id string,
  day_id string,
  text_date string,
  defined_month string,
  service_ym string,
  week_id4 string
 )
 ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS textfile ;