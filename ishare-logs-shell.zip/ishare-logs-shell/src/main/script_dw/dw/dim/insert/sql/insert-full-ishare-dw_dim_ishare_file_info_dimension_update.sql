set mapreduce.map.memory.mb=8192;
set hive.auto.convert.join=true;
set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_dim.dw_dim_ishare_file_info_dimension partition(category_id)
select
    w.id,
    w.title,
    w.format,
    w.fist_id,
    w.sec_id,
    w.third_id,
    w.first_name,
    w.sec_name,
    w.third_name,
    w.product_type,
    w.product_price,
    w.uid,
    w.site,
    w.wenwo_audit,
    w.is_excellent,
    w.third_id category_id
from dw_dim.dw_dim_ishare_file_info_dimension dim
left join(
--中间层
select
    n.third_id,
    n.third_name,
    n.sec_id,
    n.sec_name,
    n.fist_id,
    n.first_name,
    a.id,
    a.uid,
    a.title,
    a.format,
    a.product_type,
    a.product_price,
    a.site,
    a.wenwo_audit,
    a.is_excellent
from(
select
    f.class_id,
    f.id,
    f.uid,
    f.title,
    f.format,
    f.product_type,
    f.product_price,
    f.site,
    f.wenwo_audit,
    f.is_excellent,
    row_number() over(partition by id order by update_time desc) num
from dw_fact.dw_fact_ishare_file_info_public_new f
where mth='${date_day}'
) a
left join(
select
    a.id third_id,
    a.name third_name,
    b.id sec_id,
    b.name sec_name,
    c.id fist_id ,
    c.name first_name
from dw_fact.dw_fact_ishare_tb_content_category a
join dw_fact.dw_fact_ishare_tb_content_category b on (a.father=b.id)
join dw_fact.dw_fact_ishare_tb_content_category c on (b.father=c.id)
where exists(select 1 from dw_fact.dw_fact_ishare_file_info_public_new f where (f.class_id=a.id and mth='${date_day}'))
) n on a.class_id=n.third_id
where a.num=1

union
select
    n.third_id,
    n.third_name,
    n.sec_id,
    n.sec_name,
    n.fist_id,
    n.first_name,
    a.id,
    a.uid,
    a.title,
    a.format,
    a.product_type,
    a.product_price,
    a.site,
    a.wenwo_audit,
    a.is_excellent
from(
select
    a.id third_id,
    a.name third_name,
    b.id sec_id,
    b.name sec_name,
    c.id fist_id ,
    c.name first_name
from(
select
id,
father,
name
from dw_fact.dw_fact_ishare_tb_content_category
where substr(update_time,0,10)='${date_day}'
) a
join(
select
id,
father,
name
from dw_fact.dw_fact_ishare_tb_content_category
where substr(update_time,0,10)='${date_day}'
) b on (a.father=b.id)
join(
select
id,
name
from dw_fact.dw_fact_ishare_tb_content_category
where substr(update_time,0,10)='${date_day}'
) c on (b.father=c.id)
where exists(select 1 from dw_fact.dw_fact_ishare_file_info_public_new f where (f.class_id=a.id))
) n
left join(
select
    f.class_id,
    f.id,
    f.uid,
    f.title,
    f.format,
    f.product_type,
    f.product_price,
    f.site,
    f.wenwo_audit,
    f.is_excellent,
    row_number() over(partition by id order by update_time desc) num
from dw_fact.dw_fact_ishare_file_info_public_new f
) a on a.class_id=n.third_id
where a.num=1
) w on dim.third_id=w.third_id
and w.third_id is null


union all

--中间层
select
	a.id,
	a.title,
	a.format,
	n.fist_id,
	n.sec_id,
	n.third_id,
	n.first_name,
	n.sec_name,
    n.third_name,
    a.product_type,
    a.product_price,
    a.uid,
    a.site,
    a.wenwo_audit,
    a.is_excellent,
    n.third_id category_id
from(
select
    f.class_id,
    f.id,
    f.uid,
    f.title,
    f.format,
    f.product_type,
    f.product_price,
    f.site,
    f.wenwo_audit,
    f.is_excellent,
    row_number() over(partition by id order by update_time desc) num
from dw_fact.dw_fact_ishare_file_info_public_new f
where mth='${date_day}'
) a
left join(
select
    a.id third_id,
    a.name third_name,
    b.id sec_id,
    b.name sec_name,
    c.id fist_id ,
    c.name first_name
from dw_fact.dw_fact_ishare_tb_content_category a
join dw_fact.dw_fact_ishare_tb_content_category b on (a.father=b.id)
join dw_fact.dw_fact_ishare_tb_content_category c on (b.father=c.id)
where exists(select 1 from dw_fact.dw_fact_ishare_file_info_public_new f where (f.class_id=a.id and mth='${date_day}'))
) n on a.class_id=n.third_id
where a.num=1

union
select
	a.id,
	a.title,
	a.format,
	n.fist_id,
	n.sec_id,
	n.third_id,
	n.first_name,
	n.sec_name,
    n.third_name,
    a.product_type,
    a.product_price,
    a.uid,
    a.site,
    a.wenwo_audit,
    a.is_excellent,
    n.third_id category_id
from(
select
    a.id third_id,
    a.name third_name,
    b.id sec_id,
    b.name sec_name,
    c.id fist_id ,
    c.name first_name
from(
select
id,
father,
name
from dw_fact.dw_fact_ishare_tb_content_category
where substr(update_time,0,10)='${date_day}'
) a
join(
select
id,
father,
name
from dw_fact.dw_fact_ishare_tb_content_category
where substr(update_time,0,10)='${date_day}'
) b on (a.father=b.id)
join(
select
id,
name
from dw_fact.dw_fact_ishare_tb_content_category
where substr(update_time,0,10)='${date_day}'
) c on (b.father=c.id)
where exists(select 1 from dw_fact.dw_fact_ishare_file_info_public_new f where (f.class_id=a.id))
) n
left join(
select
    f.class_id,
    f.id,
    f.uid,
    f.title,
    f.format,
    f.product_type,
    f.product_price,
    f.site,
    f.wenwo_audit,
    f.is_excellent,
    row_number() over(partition by id order by update_time desc) num
from dw_fact.dw_fact_ishare_file_info_public_new f
) a on a.class_id=n.third_id

