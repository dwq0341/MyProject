insert overwrite table dw_dim.dw_dim_ishare_file_info_public_redim partition(dt='${date_day}')
select
id file_id,                                 -- 资料ID
title file_name,                            -- 资料名称
classid class_id,                           -- 文件分类
permin ,                                    -- 1:公开、2:私人 3:付费
volume,                                     -- 下载券
vipFreeFlag vip_free_flag,                  -- 是否VIP免费
isDownload is_download,                     -- 是否屏蔽下载
format file_format,                         -- 资料格式
uid uploader_user_id,                       -- 上传者id
filesourcechannel uploader_channel,         -- 上传渠道
createtime create_time,                     -- 创建时间
updatetime update_time,                     -- 更新时间
isexcellent file_quality,                   -- 资料质量
pricebak org_price,                         -- 原始价格
price lastest_price,                        -- 最新价格
volumebak org_volume,                       -- 原始所需下载券
size                                        -- 资料size
from ods_ods.ods_ods_ishare_file_info_public where dt ='${date_day}';