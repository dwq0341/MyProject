-- 1、drop表
drop table if exists dw_dim.dw_dim_ishare_file_info_public_redim;
-- 2、创建表
create table if not exists dw_dim.dw_dim_ishare_file_info_public_redim(
file_id                string comment'资料ID',
file_name              string comment'资料名称',
class_id               string comment'文件分类',
permin                 string comment'1:公开、2:私人 3:付费',
volume                 string comment'下载券',
vip_free_flag          string comment'是否VIP免费',
is_download            string comment'是否屏蔽下载',
file_format            string comment'资料格式',
uploader_user_id       string comment'上传者id',
uploader_channel       string comment'上传渠道',
create_time            string comment'创建时间',
update_time            string comment'更新时间',
file_quality           string comment'资料质量',
org_price              string comment'原始价格',
lastest_price          string comment'最新价格',
org_volume             string comment'原始所需下载券',
size                   string comment'资料size'
)
partitioned by (dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS parquet tblproperties("orc.compress"="SNAPPY");
-- 3、全量导入数据
insert overwrite table dw_dim.dw_dim_ishare_file_info_public_redim partition(dt='${date_day}')
select
id file_id,                                 -- 资料ID
title file_name,                            -- 资料名称
classid class_id,                           -- 文件分类
permin ,                                    -- 1:公开、2:私人 3:付费
volume,                                     -- 下载券
vipFreeFlag vip_free_flag,                  -- 是否VIP免费
isDownload is_download,                     -- 是否屏蔽下载
format file_format,                         -- 资料格式
uid uploader_user_id,                       -- 上传者id
filesourcechannel uploader_channel,         -- 上传渠道
createtime create_time,                     -- 创建时间
updatetime update_time,                     -- 更新时间
isexcellent file_quality,                   -- 资料质量
pricebak org_price,                         -- 原始价格
price lastest_price,                        -- 最新价格
volumebak org_volume,                       -- 原始所需下载券
size                                        -- 资料size
from ods_ods.ods_ods_ishare_file_info_public where dt ='${date_day}';
