-- 3、全量导入数据
insert overwrite table dw_dim.dw_dim_ishare_file_info partition(dt='${date_day}')
select
p.file_id,
p.file_name,
cl.first_class_id first_class_id,
cl.sec_class_id sec_class_id,
cl.third_class_id third_class_id,
cl.first_class_name first_class_name,
cl.sec_class_name sec_class_name,
cl.third_class_name third_class_name,
case when (p.permin = 1 and p.volume = 0 and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '免费' when (p.permin = 1 and p.volume >= 1 and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '下载券'
when (p.permin = 3 and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '现金' when (p.is_download = 'n' and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '仅在线'
when (p.vip_free_flag =1 or p.vip_free_flag=2) then 'vip' else null end as file_pay_type,
p.file_format,
p.uploader_user_id,
u.usertypeid uploader_user_type,
u.nickname uploader_name,
p.uploader_channel,
p.create_time,
p.update_time,
p.file_quality,
p.org_price,
p.lastest_price,
'' org_volume,
'' latest_volume,
sns.starscore score_num,
sns.collectnum collect_num,
'' complaint_num,
sns.downnum down_num,
sns.readnum pv_num
from dw_dim.dw_dim_ishare_file_info_public_redim p
left join
dw_dim.dw_dim_ishare_file_class_info cl on p.class_id = cl.third_class_id
left join ods_ods.ods_ods_ishare_users u on p.uploader_user_id = u.id
left join ods_ods.ods_ods_ishare_file_sns sns on p.file_id = sns.fileid where p.dt = '${date_day}';