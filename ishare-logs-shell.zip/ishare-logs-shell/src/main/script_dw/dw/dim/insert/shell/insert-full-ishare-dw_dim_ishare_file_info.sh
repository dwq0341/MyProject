#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

WEEK_DAY=$(date -d +%w)
if [ $WEEK_DAY = 0 ]; then
echo '今天是周日，资料信息全量同步'
beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD} --hivevar date_day=${date_day} --hivevar start_date=${start_date} --hivevar end_date=${end_date}  -f ../sql/insert-full-ishare-dw_dim_ishare_file_info.sql
else
echo '今天非周日,星期$WEEK_DAY，同步前一天的数据，资料信息增量同步'
beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD} --hivevar date_day=${date_day} --hivevar start_date=${start_date} --hivevar end_date=${end_date}  -f ../sql/insert-inc-ishare-dw_dim_ishare_file_info.sql
fi