set hive.jobname.length=120;
set hive.auto.convert.join=true;
set hive.groupby.skewindata=true;
set hive.optimize.skewjoin=true;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=10000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;

with category as(
select
    a.id third_id,
    a.name third_name,
    b.id sec_id,
    b.name sec_name,
    c.id fist_id ,
    c.name fist_name
from dw_fact.dw_fact_ishare_tb_content_category a
join dw_fact.dw_fact_ishare_tb_content_category b on (a.father=b.id)
join dw_fact.dw_fact_ishare_tb_content_category c on (b.father=c.id)
where exists(select 1 from dw_fact.dw_fact_ishare_file_info_public_new f where (f.class_id=a.id))
)

insert overwrite table dw_dim.dw_dim_ishare_file_info_dimension
--文件维度表: 初始化全量匹配
-- c.id一级、b.id二级、a.id三级
select
    a.id,
    a.title,
    a.format,
    a.keywords,
    a.name,
    n.fist_id,
    n.sec_id,
    n.third_id,
    n.fist_name,
    n.sec_name,
    n.third_name,
    a.product_type,
    a.product_price,
    a.uid,
    a.showflag,
    a.site,
    a.is_excellent,
    a.open_user_id,
    a.user_nick,
    a.create_time,
    a.audit_date,
    case when a.file_source_channel like '%editor%' then 'edit'
    when r.file_id is not null and r.file_id <> '' then 'manual' else 'auto' end audit_way,
    a.update_time,
    a.trans_form_txt,
    a.file_source_channel,
    a.user_file_type,
    a.user_file_price
    -- n.third_id category_id    --三级分类id作为分区
from(
select
    f.class_id,
    f.uid,
    f.id,
    f.title,
    f.format,
    f.product_type,
    f.product_price,
    f.site,
    f.is_excellent,
    f.keywords,
    f.name,
    f.open_user_id,
    f.user_nick,
    f.create_time,
    f.audit_date,
    f.showflag,
    f.update_time,
    f.trans_form_txt,
    f.file_source_channel,
    f.user_file_type,
    f.user_file_price,
    row_number() over(partition by id order by update_time desc) num
from dw_fact.dw_fact_ishare_file_info_public_new f
) a
left join(
select
    file_id,
    file_source_channel
from dw_fact.dw_fact_ishare_tb_audit_people_record
) r on a.id=r.file_id

left join category n on a.class_id=n.third_id
where a.num=1