insert overwrite table dw_dim.dw_dim_ishare_user_info
select
id                    id,                  --用户id
mobiledata            mobile_account,      --手机登录账号
openuid               open_uid,            --开放用户id
nickname              nick_name,           --用户昵称
updatetime            update_time,         --更新时间
score                 score,               --积分
scorebackup           score_back_up,       --积分备份(调整之前的备份)
costscore             cost_score,          --贡献分
gender                gender,              --性别(M:男, F:女)
aibeans               aibeans,             --爱问豆余额
uploads               uploads,             --上传数
priuploads            priuploads,          --私有文件数
states                states,              --状态(0:正常/-1:临时屏蔽/-2:永久屏蔽/-3:注销)
createtime            create_time,         --注册日期
birthmonthday         birth_month_day,     --生日(月-日)， 完整格式，如 01-03 , MM-dd
province              prov,                --省
city                  city,                --城市
source                source,              --用户来源
isauth                is_auth,             --是否已认证 0-未认证,1-已认证
isvip                 is_vip,              --0不是 1是 2冻结
usertypeid            user_type_id,        --用户类型 1普通，2个人，3机构
userlevelid           user_level_id,       --用户等级ID 数据初始化
ishintbind            is_hint_bind,        --是否设置了密码 1 设置 0 未设置
class                 class                --是否提示绑定 0-未提示 1-已提示
from ods_ods.ods_ods_ishare_users;