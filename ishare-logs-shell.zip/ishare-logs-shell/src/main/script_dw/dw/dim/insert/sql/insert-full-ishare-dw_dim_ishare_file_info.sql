-- 1、drop表
drop table if exists dw_dim.dw_dim_ishare_file_info;
-- 2、创建表
create table if not exists dw_dim.dw_dim_ishare_file_info(
file_id               string comment'资料ID',
file_name             string comment'资料名称',
first_class_id        string comment'一级分类ID',
sec_class_id          string comment'二级分类ID',
third_class_id        string comment'三级分类ID',
first_class_name      string comment'一级分类名称',
sec_class_name        string comment'二级分类名称',
third_class_name      string comment'三级分类名称',
file_pay_type         string comment'资料付费类型',
file_format           string comment'资料格式',
uploader_user_id      string comment'上传用户ID',
uploader_user_type    string comment'上传用户分类',
uploader_name         string comment'上传用户姓名',
uploader_channel      string comment'上传渠道',
create_time           string comment'资料创建时间',
update_time           string comment'资料更新时间',
file_quality          string comment'资料质量',
org_price             string comment'改价前价格',
lastest_price         string comment'最新价格',
org_volume            string comment'改价前下载券个数',
latest_volume         string comment'最新下载券个数',
score_num             string comment'资料评分平均分值',
collect_num           string comment'资料收藏人数',
complaint_num         string comment'资料投诉次数',
down_num              string comment'资料下载量',
pv_num                string comment'资料浏览量'
)
partitioned by (dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS parquet;
-- 3、全量导入数据
insert overwrite table dw_dim.dw_dim_ishare_file_info partition(dt='${date_day}')
select
p.file_id,
p.file_name,
cl.first_class_id first_class_id,
cl.sec_class_id sec_class_id,
cl.third_class_id third_class_id,
cl.first_class_name first_class_name,
cl.sec_class_name sec_class_name,
cl.third_class_name third_class_name,
case when (p.permin = 1 and p.volume = 0 and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '免费' when (p.permin = 1 and p.volume >= 1 and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '下载券'
when (p.permin = 3 and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '现金' when (p.is_download = 'n' and p.vip_free_flag <> 1 and p.vip_free_flag <> 2) then '仅在线'
when (p.vip_free_flag =1 or p.vip_free_flag=2) then 'vip' else null end as file_pay_type,
p.file_format,
p.uploader_user_id,
u.usertypeid uploader_user_type,
u.nickname uploader_name,
p.uploader_channel,
p.create_time,
p.update_time,
p.file_quality,
p.org_price,
p.lastest_price,
'' org_volume,
'' latest_volume,
sns.starscore score_num,
sns.collectnum collect_num,
'' complaint_num,
sns.downnum down_num,
sns.readnum pv_num
from dw_dim.dw_dim_ishare_file_info_public_redim p
left join
dw_dim.dw_dim_ishare_file_class_info cl on p.class_id = cl.third_class_id
left join ods_ods.ods_ods_ishare_users u on p.uploader_user_id = u.id
left join ods_ods.ods_ods_ishare_file_sns sns on p.file_id = sns.fileid where p.dt = '${date_day}';