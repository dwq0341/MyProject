insert overwrite table dw_dim.dw_dim_date
(

)