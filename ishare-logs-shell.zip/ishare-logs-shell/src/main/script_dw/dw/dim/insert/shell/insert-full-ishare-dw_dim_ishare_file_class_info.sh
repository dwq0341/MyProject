#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh

beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD} -f ../sql/insert-full-ishare-dw_dim_ishare_file_class_info.sql

