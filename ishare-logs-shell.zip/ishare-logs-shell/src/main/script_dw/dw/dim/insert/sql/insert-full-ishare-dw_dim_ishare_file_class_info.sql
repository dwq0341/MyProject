insert overwrite table dw_dim.dw_dim_ishare_file_class_info
SELECT
f2.fist_id                first_class_id,               --第一级类目id
f2.first_name             first_class_name,             --第一级类目名字
s2.sec_id                 sec_class_id,                 --第二级类目id
s2.sec_name               sec_class_name,               --第二级类目名字
t2.third_id               third_class_id,               --第三级类目id
t2.third_name             third_class_name,             --第三级类目名字
d2.forth_id               four_class_id,                --第四级类目id
d2.forth_name             four_class_name               --第四级类目名字
FROM
(SELECT
    f1.id AS fist_id,
    f1.name AS first_name
FROM ods_ods.ods_ods_ishare_file_class f1 WHERE f1.level = '1') f2
LEFT JOIN
(SELECT
    s1.id AS sec_id,
    s1.name AS sec_name,
    s1.father
FROM ods_ods.ods_ods_ishare_file_class s1 WHERE s1.level = '2') s2 ON s2.father = f2.fist_id
LEFT JOIN
(SELECT
    t1.id AS third_id,
    t1.name AS third_name,
    t1.father
FROM ods_ods.ods_ods_ishare_file_class t1 WHERE t1.level = '3') t2 ON t2.father = s2.sec_id
LEFT JOIN
(SELECT
    d1.id AS forth_id,
    d1.name AS forth_name,
    d1.father
FROM ods_ods.ods_ods_ishare_file_class d1 WHERE d1.level = '4') d2 ON d2.father = t2.third_id;



