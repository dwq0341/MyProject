#!/bin/bash
echo 'flow start dim ...'
