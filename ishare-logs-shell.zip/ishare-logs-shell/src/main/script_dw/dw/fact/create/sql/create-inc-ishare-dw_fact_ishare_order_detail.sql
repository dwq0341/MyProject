drop table if exists dw_dim.dw_dim_ishare_t_order_info;
create table if not exists dw_dim.dw_dim_ishare_order_detail(
order_no string comment '订单号',
order_time	string comment '订单时间',
terminal_type string comment '软件终端类型',
1th_traffic_source string comment '一级流量来源',
2th_traffic_source string comment '二级流量来源',
state_type string  comment '站点类型',
order_source string  comment '订单来源页'

)
partitioned by (dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
COLLECTION ITEMS TERMINATED BY ','
map keys terminated by ':'
STORED AS parquet  tblproperties ("orc.compress"="SNAPPY");