#!/bin/bash
source ../../../../common/env/hive_env.sh


beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  -f ../sql/create-inc-ishare-dm_dm_ishare_log_360onebox_file_basic_index.sql
