drop table if exists  dm_dm.dm_dm_ishare_360onebox_file_down_index;
create table dm_dm.dm_dm_ishare_360onebox_file_down_index (
event_time string comment '日期',
file_pay_type string comment '资料付费类型',
land_url_channel string comment '360onebox为合作渠道',
terminal_type string comment '软件终端类型',
site_type string comment '站点类型',
keyword_id string comment '360onebox后面的34956为投放关键字ID',
download_success_sum int comment 'SE014事件求和'

 )
partitioned  by (dt string)
STORED AS textfile;