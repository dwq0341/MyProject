drop table if exists  dm_dm.dm_dm_ishare_360onebox_file_basic_index;
create table dm_dm.dm_dm_ishare_360onebox_file_basic_index (
event_time string comment '日期',
file_pay_type string comment '资料付费类型',
land_url_channel string comment '360onebox为合作渠道',
terminal_type string comment '软件终端类型',
site_type string comment '站点类型',
keyword_id string comment '360onebox后面的34956为投放关键字ID',
pv int comment 'NE002事件求和，为pv',
uv int comment 'NE002事件对visitID去重求和，即为uv',
ip_count int comment 'NE002对ip字段去重求和即为ip'
 )
partitioned  by (dt string)
STORED AS textfile;