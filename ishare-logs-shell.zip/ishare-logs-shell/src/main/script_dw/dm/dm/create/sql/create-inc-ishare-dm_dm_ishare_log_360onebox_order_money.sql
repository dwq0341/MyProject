drop table if exists  dm_dm.dm_dm_ishare_360onebox_order_money;
create table dm_dm.dm_dm_ishare_360onebox_order_money (
event_time string comment '日期',
land_url_channel string comment '360onebox为合作渠道',
terminal_type string comment '软件终端类型',
site_type string comment '站点类型',
keyword_id string comment '360onebox后面的34956为投放关键字ID',
buy_content string comment '购买内容',
pay_money double comment 'SE009、SE011、se013事件的orderID关联业务库的t_orderInfo表，t_orderInfo的payPrice求和即为购买金额。'
 )
partitioned  by (dt string)
STORED AS textfile;