set hive.vectorized.execution.enabled = false;
set hive.groupby.skewindata=false;
set hive.execution.engine=mr;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_wechat_flow_condition_month partition(dt)
select
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') stat_period,                                     --时间周期
    e.terminal_type,                                                                                                    --终端类型
    count(case when e.event_id = 'NE001' then e.visit_id else null end) as flow_pv,                                     --流量pv
    count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) flow_uv,       --流量uv
    count(case when (a.visit_id is not null or a.visit_id != '') then e.visit_id else null end) new_visit_pv,           --新访客用户pv
    count(distinct(case when (a.visit_id is not null or a.visit_id != '') then e.visit_id else null end)) new_visit_uv, --新访客用户uv
    count(distinct(case when e.event_id='NE001' and e.source='1007' then e.visit_id else null end)) wechat_friend_uv,   --微信好友及群回流UV
    count(distinct(case when e.event_id='NE001' and e.source='1008' then e.visit_id else null end)) wechat_uv,          --微信朋友圈回流UV
    count(distinct(case when e.event_id='NE001' and (e.source='1007' or e.source='1008') then e.visit_id else null end)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) share_flow_rate,   --分享回流流量占比
    count(distinct(case when e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_status_users,                   --登录状态用户
    count(distinct(case when e.event_id='SE001' and e.login_result = '1' then e.visit_id else null end)) login_succ_count,                  --登录成功用户数
    count(distinct users.id) user_cnt,                                                                                                      --新注册用户数
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,                                                     --更新时间
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
    user_id,
    event_id,
    visit_id,
    get_json_object(var,'$.source') source,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type='1' and browser='微信' then 'M端-微信浏览器'
    when terminal_type='8-1' then '微信小程序_爱问办公模板'
    when terminal_type='8-2' then '微信小程序_爱问文件管理'
    when terminal_type='8-3' then '微信小程序_爱问模板'
    when terminal_type='8-4' then '微信小程序_爱问福利社' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) e

left join(
select
id
from dw_dim.dw_dim_ishare_users
where create_time < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and create_time >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
) users on e.user_id = users.id

left join(
select
    visit_id
from dw_fact.dw_fact_ishare_log_events_sort
where substr(nginx_date,0,10) < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyy-MM-dd')
and substr(nginx_date,0,10) >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyy-MM-dd')
) a on e.visit_id=a.visit_id
where e.terminal_type is not null
group by
e.terminal_type

--小程序-全部
union all
select
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') stat_period,                                     --时间周期
    e.terminal_type,                                                                                                    --终端类型
    count(case when e.event_id = 'NE001' then e.visit_id else null end) as flow_pv,                                     --流量pv
    count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) flow_uv,       --流量uv
    count(case when (a.visit_id is not null or a.visit_id != '') then e.visit_id else null end) new_visit_pv,           --新访客用户pv
    count(distinct(case when (a.visit_id is not null or a.visit_id != '') then e.visit_id else null end)) new_visit_uv, --新访客用户uv
    count(distinct(case when e.event_id='NE001' and e.source='1007' then e.visit_id else null end)) wechat_friend_uv,   --微信好友及群回流UV
    count(distinct(case when e.event_id='NE001' and e.source='1008' then e.visit_id else null end)) wechat_uv,          --微信朋友圈回流UV
    count(distinct(case when e.event_id='NE001' and (e.source='1007' or e.source='1008') then e.visit_id else null end)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) share_flow_rate,   --分享回流流量占比
    count(distinct(case when e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_status_users,    --登录状态用户
    count(distinct(case when e.event_id='SE001' and e.login_result = '1' then e.visit_id else null end)) login_succ_count,   --登录成功用户数
    count(distinct users.id) user_cnt,                                                                                       --新注册用户数
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,                                      --更新时间
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
    user_id,
    event_id,
    visit_id,
    get_json_object(var,'$.source') source,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type like '%8%' then '小程序-全部' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) e

left join(
select
id
from dw_dim.dw_dim_ishare_users
where create_time < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and create_time >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
) users on e.user_id = users.id

left join(
select
    visit_id
from dw_fact.dw_fact_ishare_log_events_sort
where substr(nginx_date,0,10) < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyy-MM-dd')
and substr(nginx_date,0,10) >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyy-MM-dd')
) a on e.visit_id=a.visit_id
where e.terminal_type is not null
group by
e.terminal_type

--全部
union all
select
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') stat_period,                                     --时间周期
    e.terminal_type,                                                                                                    --终端类型
    count(case when e.event_id = 'NE001' then e.visit_id else null end) as flow_pv,                                     --流量pv
    count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) flow_uv,       --流量uv
    count(case when (a.visit_id is not null or a.visit_id != '') then e.visit_id else null end) new_visit_pv,           --新访客用户pv
    count(distinct(case when (a.visit_id is not null or a.visit_id != '') then e.visit_id else null end)) new_visit_uv, --新访客用户uv
    count(distinct(case when e.event_id='NE001' and e.source='1007' then e.visit_id else null end)) wechat_friend_uv,   --微信好友及群回流UV
    count(distinct(case when e.event_id='NE001' and e.source='1008' then e.visit_id else null end)) wechat_uv,          --微信朋友圈回流UV
    count(distinct(case when e.event_id='NE001' and (e.source='1007' or e.source='1008') then e.visit_id else null end)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) share_flow_rate,   --分享回流流量占比
    count(distinct(case when e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_status_users,   --登录状态用户
    count(distinct(case when e.event_id='SE001' and e.login_result = '1' then e.visit_id else null end)) login_succ_count,  --登录成功用户数
    count(distinct users.id) user_cnt,                                                                                      --新注册用户数
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,                                     --更新时间
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
    user_id,
    event_id,
    visit_id,
    get_json_object(var,'$.source') source,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type like '%8%' or (terminal_type='1' and browser='微信') then '全部' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) e

left join(
select
id
from dw_dim.dw_dim_ishare_users
where create_time < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and create_time >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
) users on e.user_id = users.id

left join(
select
    visit_id
from dw_fact.dw_fact_ishare_log_events_sort
where substr(nginx_date,0,10) < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyy-MM-dd')
and substr(nginx_date,0,10) >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyy-MM-dd')
) a on e.visit_id=a.visit_id
where e.terminal_type is not null
group by
e.terminal_type