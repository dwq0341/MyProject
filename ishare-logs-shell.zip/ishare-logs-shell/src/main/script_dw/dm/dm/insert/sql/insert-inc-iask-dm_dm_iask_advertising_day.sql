set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_advertising_day partition(dt)
select
    dayno,
    site,
    sum(pv) pv,
    sum(uv) uv,
    sum(ssp_ad_income) ssp_ad_income,	    --百度联盟收入
    sum(ad_view) view,				        --展现量
    sum(click) click,				        --点击量
    sum(ad_view)/sum(pv) view_per_pv,			--PV代码量
    sum(click)/sum(ad_view) view_per_click,	    --展现点击率
    sum(click)/sum(pv) click_rate,			    --pv点击率
    sum(ssp_ad_income)/sum(click) click_income,	--点击价格
    round(sum(ad_operations_income)/sum(pv) * 1000, 2) as ECPM,
    round(sum(ad_operations_income)/sum(uv) * 1000, 2) as UECPM,
    sum(ad_operations_income-ssp_ad_income) other_income,    --其他收入
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,     --更新时间
    '${date_day}' dt
from dw_fact.dw_fact_iask_t_date_iask_total
where site in ("M版-Ishare" ,"PC版-Ishare" )
and dayno=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
group by dayno, site