set mapred.child.java.opts=-Xmx1024m;
set mapreduce.map.java.opts=-Xmx1310m;
set yarn.app.mapreduce.am.command-opts=-Xmx2457m;
set mapreduce.reduce.java.opts=-Xmx2620m;
set mapreduce.map.memory.mb=4096;
insert overwrite table dm_dm.dm_dm_ishare_360onebox_basic_index partition(dt='${date_day}')
  select
  j.event_time,
  j.land_url_channel,
  j.terminal_type,
  j.site_type,
  j.keyword_id,
  sum(case when j.event_id='NE001' then 1 else 0 end )   pv,
  count(distinct j.visit_id ) uv,
  count(distinct j.ip ) ip_count
  from (
  select
     w.event_id,
      split(w.event_time,' ')[0] event_time,
      '360onebox' land_url_channel,
      case when w.terminal_type='0' then 'PC' when w.terminal_type='1' then 'M'  else '' end terminal_type ,
      case when split(page_id, '-')[1] = 'M' then '主站' when split(w.page_id, '-')[1] = 'O' then '办公频道' else '' end site_type,
      split(w.land_url,'360onebox')[1] keyword_id,
      w.visit_id,
      w.ip
      from (
            select s.event_id,s.event_time,s.land_url,s.terminal_type,s.page_url ,s.visit_id,s.ip,s.page_id from dw_fact.dw_fact_ishare_session_event  s
            where  s.event_id='NE001' and  s.land_url  regexp('.*360onebox.*')  and s.dt='${date_day}'
            ) w ) j  group by j.event_time,j.land_url_channel,j.terminal_type, j.site_type,j.keyword_id

