#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行insert-inc-ishare-dm_dm_ishare_website_search_keyword_to_mysql_day 网站搜索词频率报表 导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/ishare_website_search_keyword_sync_day.sh ${date_day}  ${end_date}
echo "执行insert-inc-ishare-dm_dm_ishare_website_search_keyword_to_mysql_day 网站搜索词频率报表 导入sh结束标志"