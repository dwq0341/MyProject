#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行insert-inc-ishare-dm_dm_ishare_path_analysis_day 路径分析 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/ishare_path_analysis_sync_day.sh ${date_day}
echo "执行insert-inc-ishare-dm_dm_ishare_path_analysis_day 路径分析 数据导入sh结束标志"