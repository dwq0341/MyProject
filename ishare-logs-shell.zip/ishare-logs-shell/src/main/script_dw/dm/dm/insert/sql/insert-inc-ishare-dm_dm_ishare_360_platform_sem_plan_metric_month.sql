set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_360_platform_sem_plan_metric_month partition(dt)
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
aaa.user_name,
aaa.domain,
aaa.open_time,
aaa.growth_stage,
aaa.account_type,
--消费
aaa.cash,
--实际消费
aaa.actual_cash,
--总订单支付金额
ddd.total_pay_price,
--总订单成功人数
ddd.total_pay_user,
--客单价:总订单支付金额/总订单成功人数
ddd.total_pay_price / ddd.total_pay_user guest_price,
--总订单ROI:总订单支付金额/消费
ddd.total_pay_price / aaa.cash total_order_roi,
--总订单返点ROI:总订单支付金额/实际消费
ddd.total_pay_price / aaa.actual_cash total_order_rebate_roi,
--利润:总订单支付金额-实际消费
ddd.total_pay_price - aaa.actual_cash profit,
--利润率:利润/实际消费
(ddd.total_pay_price - aaa.actual_cash) / aaa.actual_cash profit_rate,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
a.user_name,
name_info.domain,
name_info.open_time,
name_info.growth_stage,
name_info.account_type,
a.cash,
a.cash / name_info.return_value actual_cash
from(
select
    user_name,
    sum(total_price) cash
from ods_ods.ods_ods_ishare_cost_360_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
group by user_name
) a

left join(
select
    account,
    domain,
    open_time,
    growth_stage,
    account_type,
    return_value
from ods_ods.ods_ods_ishare_360_sem_user_name_info
) name_info on a.user_name=name_info.account
) aaa

left join(
select
    case parse_url(c.land_url,'QUERY','utm_source') when '360bg' then '爱问办公01'
    when '360bg02' then '爱问办公02' when '360bg03' then '爱问办公03' when '360bg04' then '爱问办公04'
    when '360zc01' then '合同协议01' when '360bg06' then '爱问办公06' when '360fl' then '爱问办公07' else null end as account,
    sum(order_info.pay_price/100) total_pay_price,
    count(distinct order_info.buyer_user_id) total_pay_user
from dw_fact.dw_fact_ishare_t_order_info order_info

left join(
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and (parse_url(land_url,'QUERY','utm_source') like '%360bg%' or parse_url(land_url,'QUERY','utm_source') like '%360fl%' or parse_url(land_url,'QUERY','utm_source') like '%360zc%')
) c on order_info.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on order_info.goods_type=g.goods_types
where substr(order_info.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(order_info.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and order_info.order_status = '2'
and order_info.channel_source in ('5','0','6','7','8','9')
--and order_info.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
group by parse_url(c.land_url,'QUERY','utm_source')
) ddd on aaa.user_name = ddd.account