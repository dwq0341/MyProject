set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_platform_sem_plan_metric_month partition(dt)
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
a.user_name,
a.cash cash,
e.pay_price total_pay_price,
e.pay_user total_pay_user,
'${date_day}' update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from (
select
     round(sum(cash),2) cash,
    'baidu' user_name
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and fc_plan_name <> '全部'
and user_name <> '全部'
and user_name not like '%爱问众创%'
) a
left join
(
select
'baidu' account,
sum(a.pay_price) pay_price,
sum(a.pay_user) pay_user
from(
select
    case parse_url(c.land_url,'QUERY','utm_source') when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' when 'baidu4' then
      '爱问科技04' when 'baidu5' then '爱问科技05' when 'baidu6' then '爱问科技06' when 'baidu07' then '爱问科技07' when 'baidu12' then '爱问科技12' when 'baidu22' then '爱问科技22'  when 'baidu21' then '爱问科技21'  when 'baiducq1' then '爱问众创-01' when 'baiducq02' then '爱问众创-02'  when 'baidu14' then '爱问科技14'  when 'baiduzc4' then '爱问众创04'  when 'baiduzc2' then '爱问众创02' when 'baidu19' then '爱问科技19'   when 'baidu14' then '爱问科技14' when 'baidu15' then '爱问科技15' when 'baidu8' then '爱问科技08' when 'baiduzc' then '爱问众创' when 'baiduzc1' then '爱问众创01' when 'baiduth1' then '爱问办公1'  else null end as account,
    sum(b.pay_price/100) pay_price,
    count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and parse_url(land_url,'QUERY','utm_source') like '%baidu%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
group by parse_url(c.land_url,'QUERY','utm_source')
) a
where a.account not like '%爱问众创%'
) e on a.user_name = e.account

union all
--百度众创
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
a.user_name,
a.cash cash,
e.pay_price total_pay_price,
e.pay_user total_pay_user,
'${date_day}' update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from (
select
     round(sum(cash),2) cash,
    'baiduzc' user_name
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and fc_plan_name <> '全部'
and user_name like '%爱问众创%'
) a
left join
(
select
'baiduzc' account,
sum(a.pay_price) pay_price,
sum(a.pay_user) pay_user
from(
select
    case parse_url(c.land_url,'QUERY','utm_source') when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' when 'baidu4' then
      '爱问科技04' when 'baidu5' then '爱问科技05' when 'baidu6' then '爱问科技06' when 'baidu07' then '爱问科技07' when 'baidu12' then '爱问科技12' when 'baidu22' then '爱问科技22'  when 'baidu21' then '爱问科技21'  when 'baiducq1' then '爱问众创-01' when 'baiducq02' then '爱问众创-02'  when 'baidu14' then '爱问科技14'  when 'baiduzc4' then '爱问众创04'  when 'baiduzc2' then '爱问众创02' when 'baidu19' then '爱问科技19'   when 'baidu14' then '爱问科技14' when 'baidu15' then '爱问科技15' when 'baidu8' then '爱问科技08' when 'baiduzc' then '爱问众创' when 'baiduzc1' then '爱问众创01' when 'baiduth1' then '爱问办公1'  else null end as account,
    sum(b.pay_price/100) pay_price,
    count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and parse_url(land_url,'QUERY','utm_source') like '%baidu%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
group by parse_url(c.land_url,'QUERY','utm_source')
) a
where a.account like '%爱问众创%'
) e on a.user_name = e.account

union all
--百度品牌专区
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
a.user_name,
a.cash cash,
e.pay_price total_pay_price,
e.pay_user total_pay_user,
'${date_day}' update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
    'baidupz' user_name,
     max(0) cash
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) a
left join(
select
'baidupz' account,
sum(a.pay_price) pay_price,
sum(a.pay_user) pay_user
from(
select
    'baidupz' account,
    sum(b.pay_price/100) pay_price,
    count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join(
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and parse_url(land_url,'QUERY','utm_source') like '%baidupz%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
) a
) e on a.user_name = e.account

union all
--360
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
a.user_name,
a.cash cash,
e.pay_price total_pay_price,
e.pay_user total_pay_user,
'${date_day}' update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from (
select
    round(sum(total_price), 2) cash,
    '360' user_name
from ods_ods.ods_ods_ishare_cost_360_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
group by '全部'
) a
left join
(
select
'360' account,
sum(b.pay_price/100) pay_price,
count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
select
distinct user_id,
    FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
from dw_fact.dw_fact_ishare_visit_event_sem
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and (parse_url(land_url,'QUERY','utm_source') like '%360bg%' or parse_url(land_url,'QUERY','utm_source') like '%360fl%' or parse_url(land_url,'QUERY','utm_source') like '%360zc%')
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
) e on a.user_name = e.account

union all
--sogou
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
a.user_name,
a.cash cash,
e.pay_price total_pay_price,
e.pay_user total_pay_user,
'${date_day}' update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from (
select
    round(sum(total_price), 2) cash,
    'sogou' user_name
from ods_ods.ods_ods_ishare_cost_sogou_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
group by '全部'
) a
left join
(
select
'sogou' account,
sum(b.pay_price/100) pay_price,
count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
select
distinct user_id,
    FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
from dw_fact.dw_fact_ishare_visit_event_sem
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and parse_url(land_url,'QUERY','utm_source') like '%sougou%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
) e on a.user_name = e.account

union all
--全部
select
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') account_period,
max(t.user_name) user_name,
sum(t.cash) cash,
max(e.pay_price) total_pay_price,
max(e.pay_user) total_pay_user,
'${date_day}' update_time,
from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
     round(sum(cash),2) cash,
    '全部' user_name
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_plan b_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and fc_plan_name <> '全部'
and user_name <> '全部'

union all
select
    round(sum(total_price), 2) cash,
    '全部' user_name
from ods_ods.ods_ods_ishare_cost_360_search_promotion_plan 360_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')

union all
select
    round(sum(total_price), 2) cash,
    '全部' user_name
from ods_ods.ods_ods_ishare_cost_sogou_search_promotion_plan sogou_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')

union all
--百度品牌专区
select
     max(0) cash,
     '全部' user_name
from dw_fact.dw_fact_ishare_cost_baidu_search_promotion_plan
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) t

left join(
select
'全部' account,
round(sum(pay_price),2) pay_price,
sum(pay_user) pay_user
from(
select
'baidu' account,
sum(a.pay_price) pay_price,
sum(a.pay_user) pay_user
from(
select
    case parse_url(c.land_url,'QUERY','utm_source') when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' when 'baidu4' then
      '爱问科技04' when 'baidu5' then '爱问科技05' when 'baidu6' then '爱问科技06' when 'baidu07' then '爱问科技07' when 'baidu12' then '爱问科技12' when 'baidu22' then '爱问科技22'  when 'baidu21' then '爱问科技21'  when 'baiducq1' then '爱问众创-01' when 'baiducq02' then '爱问众创-02'  when 'baidu14' then '爱问科技14'  when 'baiduzc4' then '爱问众创04'  when 'baiduzc2' then '爱问众创02' when 'baidu19' then '爱问科技19'   when 'baidu14' then '爱问科技14' when 'baidu15' then '爱问科技15' when 'baidu8' then '爱问科技08' when 'baiduzc' then '爱问众创' when 'baiduzc1' then '爱问众创01' when 'baiduth1' then '爱问办公1'  else null end as account,
    sum(b.pay_price/100) pay_price,
    count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and parse_url(land_url,'QUERY','utm_source') like '%baidu%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
group by parse_url(c.land_url,'QUERY','utm_source')
) a
where a.account not like '%爱问众创%'

union all
select
'baiduzc' account,
sum(a.pay_price) pay_price,
sum(a.pay_user) pay_user
from(
select
    case parse_url(c.land_url,'QUERY','utm_source') when 'baidu2' then '爱问科技02' when 'baidu1' then '爱问科技01' when 'baidu3' then '爱问科技03' when 'baidu' then '爱问2019' when 'baidu4' then
      '爱问科技04' when 'baidu5' then '爱问科技05' when 'baidu6' then '爱问科技06' when 'baidu07' then '爱问科技07' when 'baidu12' then '爱问科技12' when 'baidu22' then '爱问科技22'  when 'baidu21' then '爱问科技21'  when 'baiducq1' then '爱问众创-01' when 'baiducq02' then '爱问众创-02'  when 'baidu14' then '爱问科技14'  when 'baiduzc4' then '爱问众创04'  when 'baiduzc2' then '爱问众创02' when 'baidu19' then '爱问科技19'   when 'baidu14' then '爱问科技14' when 'baidu15' then '爱问科技15' when 'baidu8' then '爱问科技08' when 'baiduzc' then '爱问众创' when 'baiduzc1' then '爱问众创01' when 'baiduth1' then '爱问办公1'  else null end as account,
    sum(b.pay_price/100) pay_price,
    count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and parse_url(land_url,'QUERY','utm_source') like '%baidu%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
group by parse_url(c.land_url,'QUERY','utm_source')
) a
where a.account like '%爱问众创%'

union all
select
'360' account,
sum(b.pay_price/100) pay_price,
count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
select
distinct user_id,
    FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
from dw_fact.dw_fact_ishare_visit_event_sem
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and (parse_url(land_url,'QUERY','utm_source') like '%360bg%' or parse_url(land_url,'QUERY','utm_source') like '%360fl%' or parse_url(land_url,'QUERY','utm_source') like '%360zc%')
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null

union all
select
'sogou' account,
sum(b.pay_price/100) pay_price,
count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join (
select
distinct user_id,
    FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
from dw_fact.dw_fact_ishare_visit_event_sem
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and parse_url(land_url,'QUERY','utm_source') like '%sougou%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8','9')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null

union all
--百度品牌专区
select
    'baidupz' account,
    sum(b.pay_price/100) pay_price,
    count(distinct b.buyer_user_id) pay_user
from dw_fact.dw_fact_ishare_t_order_info b
left join(
    select
        distinct user_id,
        FIRST_VALUE(land_url) over(partition by user_id order by nginx_date desc) land_url
    from dw_fact.dw_fact_ishare_visit_event_sem
    where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
    and parse_url(land_url,'QUERY','utm_source') like '%baidupz%'
) c on b.buyer_user_id = c.user_id
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on b.goods_type=g.goods_types
where substr(b.order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(b.order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and g.goods_types is not null
and b.order_status = '2'
and b.channel_source in ('5','0','6','7','8')
--and b.goods_type in ('1','2','4','8','12','13')
and c.user_id is not null
) a
) e on t.user_name = e.account;