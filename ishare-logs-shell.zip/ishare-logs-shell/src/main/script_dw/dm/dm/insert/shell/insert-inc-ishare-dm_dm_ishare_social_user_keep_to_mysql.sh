#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行社交公众号留存 统计表数据导入 sh"
sh /usr/local/datax/job/mysqlTable/result/social/ishare_social_user_keep-to_mysql.sh
echo "执行社交公众号留存 统计表数据导入 sh结束标志"