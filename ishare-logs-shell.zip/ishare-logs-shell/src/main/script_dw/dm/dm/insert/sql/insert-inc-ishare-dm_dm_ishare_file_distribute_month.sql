set hive.optimize.skewjoin=true;
set hive.auto.convert.join=true;
set hive.exec.reducers.bytes.per.reducer=300000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_file_distribute_month partition(dt)
select
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') stat_period,   --时间周期
    bb.channel_source,           --站点类型
    bb.source_mode,              --终端类型
    bb.file_source_channel,      --资料生产渠道
    bb.format,                   --资料格式
    bb.third_name,               --资料三级分类名
    bb.product_type,             --资料商品类型
    bb.file_detail_pv,           --资料详情页PV
    bb.file_detail_uv,           --资料详情页UV
    bb.down_button_pv,           --立即下载按钮点击pv
    bb.down_button_uv,           --立即下载按钮点击uv
    bb.file_down_dist_num,       --立即下载按钮点击资料量
    bb.file_down_rate,           --资料下载率: 立即下载按钮点击uv/资料详情页UV
    bb.file_jump_rate,           --资料跳出率
    a.file_buy_succ_money,       --资料订单成功金额
    a.file_buy_succ_person,      --资料订单成功人数
    a.file_buy_succ_person / bb.file_detail_uv file_buy_succ_rate,    --资料订单成功率: 资料订单成功人数/资料详情页UV
    bb.browse_not_buy_num,       --浏览无购买资料量
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,     --更新时间
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt  --按月分区
from(
select
    a.source_mode,
    a.channel_source,
    b.file_source_channel,
    b.format,
    b.third_name,
    b.product_type,
    count(case when b.id is not null and a.event_id='SE002' then a.visit_id else null end) file_detail_pv,              --资料详情页pv
    count(distinct(case when b.id is not null and a.event_id='SE002' then a.visit_id else null end)) file_detail_uv,    --资料详情页uv
    count(case when b.id is not null and a.event_id='SE003' then a.visit_id else null end) down_button_pv,              --立即下载按钮点击pv
    count(distinct(case when b.id is not null and a.event_id='SE003' then a.visit_id else null end)) down_button_uv,    --立即下载按钮点击uv
    count(distinct(case when b.id is not null and a.event_id='SE003' then a.file_id else null end)) file_down_dist_num, --立即下载按钮点击资料量
    count(distinct(case when b.id is not null and a.event_id='SE003' then a.visit_id else null end)) / count(distinct(case when b.id is not null and a.event_id='SE002' then a.visit_id else null end)) file_down_rate,     --资料下载率: 立即下载按钮点击UV/资料详情页UV
    count(distinct c.visit_id) / count(distinct(case when b.id is not null and a.event_id='SE002' then a.visit_id else null end)) file_jump_rate,    --资料跳出率
    --浏览无购买资料数量
    count(distinct(case when a.event_id='SE002' and b.id is not null and d.goods_id is not null and d.order_status in(0,1,3,4,5) then a.file_id else null end)) browse_not_buy_num
from(
select
visit_id,
event_id,
get_json_object(var,'$.fileID') file_id,
case when substring(terminal_type,0,1)='0' then 'pc'
when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
when substring(terminal_type,0,1)='2' then '快应用'
when substring(terminal_type,0,1)='3' then 'android'
when substring(terminal_type,0,1)='4' then 'ios'
when substring(terminal_type,0,1)='6' then '今日头条小程序'
when substring(terminal_type,0,1)='7' then '百度小程序'
when substring(terminal_type,0,1)='8' then '微信小程序' end as source_mode,

case when site_type='ishare' then '主站' when site_type='office' then '办公' when site_type='edu' then '教育'
when site_type='archi' then '建筑' when site_type='supperVip' then '超级会员' when site_type='supperContract' then '超级合同'
when site_type='supperPPT' then '超级PPT' when site_type='wcMinioffice' then '爱问办公模板' when site_type='wcMiniDocument' then '爱问文件管理'
when site_type='wcMiniishare' then '爱问模板' when site_type='wcMiniSign' then '爱问福利社' when site_type='tyContract' then '合同通'
when site_type='iLawService' then '爱问法律顾问' when site_type='loveConteact' then '爱合同' when site_type='tyContract02' then '合同通02'
else site_type end channel_source,

row_number() over(partition by session_id,get_json_object(var,'$.fileID') order by nginx_date) num
from ods_ods.ods_ods_ishare_log
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and event_id in('SE002','SE003')
) a

left join(
select
id,
file_source_channel,
format,
third_name,
product_type
from dw_dim.dw_dim_ishare_file_info_dimension
) b on a.file_id=b.id

left join(
select
    goods_id,
    buyer_user_id,
    order_status
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and goods_type=1
) d on a.file_id=d.goods_id

--进入资料详情页后没有任何操作
left join dw_fact.dw_fact_ishare_file_distribute_jump_rate c on a.file_id=c.file_id
where a.num=1
and a.source_mode is not null
and a.channel_source is not null
and b.third_name is not null
and (b.file_source_channel <> '' and b.file_source_channel is not null)
and (b.format <> '' and b.format is not null)
and b.product_type is not null
group by
a.source_mode,
a.channel_source,
b.file_source_channel,
b.format,
b.third_name,
b.product_type
) bb


--订单
left join(
select
    b.channel_source,
    b.source_mode,
    dim.file_source_channel,
    dim.format,
    dim.third_name,
    dim.product_type,
    sum(b.pay_price) file_buy_succ_money,
    count(distinct b.buyer_user_id) file_buy_succ_person
from(
select
    id,
    file_source_channel,
    format,
    third_name,
    product_type
from dw_dim.dw_dim_ishare_file_info_dimension
) dim

left join(
select
    buyer_user_id,
    pay_price/100 pay_price,
    order_status,
    goods_type,
    goods_id,
    case when channel_source=0 then '办公' when channel_source=4 then '主站' when channel_source=1 then '教育'
    when channel_source=2 then '建筑' when channel_source=5 then '超级合同' when channel_source=6 then '超级PPT'
    when channel_source=7 then '合同通' when channel_source=8 then '爱问法律顾问' else channel_source end channel_source,

    case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios'
    when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' end as source_mode
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) < trunc(add_months(CURRENT_TIMESTAMP,0),'MM')
and substr(order_time,0,10) >= trunc(add_months(CURRENT_TIMESTAMP,-1),'MM')
and goods_type=1
and order_status = '2'
) b on b.goods_id=dim.id
group by
b.channel_source,
b.source_mode,
dim.file_source_channel,
dim.format,
dim.third_name,
dim.product_type
) a on a.source_mode = bb.source_mode
and a.channel_source = bb.channel_source
and a.file_source_channel=bb.file_source_channel
and a.format=bb.format
and a.third_name=bb.third_name
and a.product_type=bb.product_type