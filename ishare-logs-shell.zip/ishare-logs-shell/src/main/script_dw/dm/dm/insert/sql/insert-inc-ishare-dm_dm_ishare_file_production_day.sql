set hive.groupby.skewindata=false;
set hive.exec.reducers.bytes.per.reducer=1000000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_file_production_day partition(dt)
select
    '${date_day}' stat_period,              --时间周期:资料上传时间
    site,                                   --站点类型
    file_source_channel,                    --资料生产渠道
    format,                                 --资料格式
    coalesce(third_name,'') third_name,     --资料三级分类名
    product_type,                           --资料商品类型
    count(distinct id) file_upload_num,     --资料上传量
    count(distinct(case when showflag='y' and substr(audit_date,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd') then id else null end)) file_release_num,     --资料发布量
    count(distinct(case when showflag='y' and substr(audit_date,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd') then id else null end)) / count(distinct id) file_release_rate,   --资料发布率: 资料发布量/资料上传量
    count(distinct uid) user_cnt,                                                           --上传用户数
    count(distinct(case when showflag='y' then uid else null end)) valid_upload_user_num,   --有效上传用户量
    count(distinct id) / count(distinct uid) per_avg_upload_num,                            --人均上传量: 资料上传量/上传用户数
    count(distinct(case when showflag='y' and substr(audit_date,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd') then id else null end)) / count(distinct(case when showflag='y' then uid else null end)) per_avg_release_rate,    --人均发布量: 资料发布量/有效上传用户量
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,     --更新时间
    '${date_day}' dt                                                                        --按天分区
from dw_dim.dw_dim_ishare_file_info_dimension
where substr(create_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and (site is not null and site <> '')
and (file_source_channel is not null and file_source_channel <> '')
and (format is not null and format <> '')
and product_type is not null
group by
site,
file_source_channel,
format,
third_name,
product_type