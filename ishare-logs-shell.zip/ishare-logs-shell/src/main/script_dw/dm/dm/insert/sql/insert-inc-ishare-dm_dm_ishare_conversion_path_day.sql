set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_conversion_path_day partition(dt)
select
'${date_day}' stat_period,
a.site_type,
a.terminal_type,
a.visit_uv,
a.category_page_uv,
a.detail_page_pv,
a.detail_page_uv,
-- 详情页到达率: 详情页UV/访客数UV
a.detail_page_uv / a.visit_uv detail_page_arrive_rate,
a.down_button_click_uv,
-- 立即下载按钮点击率:立即下载按钮点击UV/详情页UV
a.down_button_click_uv / a.detail_page_uv down_button_click_rate,
a.login_box_show_pv,
a.login_box_show_uv,
-- 登录框展示率: 登录框展示UV/访客数UV
a.login_box_show_uv / a.visit_uv login_box_show_rate,
a.login_succ_uv,
-- 登录成功率:登录成功uv/登录框展示UV
coalesce(a.login_succ_uv/a.login_box_show_uv, 0) login_succ_rate,
a.vip_pay_arrive_pv,
a.vip_pay_arrive_uv,
a.pay_button_click_pv,
a.pay_button_click_uv,
-- 立即支付按钮点击率:立即支付按钮点击UV/VIP购买页到达UV
coalesce(a.pay_button_click_uv/a.vip_pay_arrive_uv, 0) pay_button_click_rate,
a.order_generate_num,
a.order_generate_uv,
coalesce(b.pay_succ_num, 0) pay_succ_num,
coalesce(b.pay_succ_uv, 0) pay_succ_uv,
-- 支付成功率:支付成功UV/订单生成UV
coalesce(b.pay_succ_uv/a.order_generate_uv, 0) pay_succ_rate,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
terminal_type,
site_type,
-- 访客数UV
count(distinct(case when event_id='NE001' then visit_id else null end)) visit_uv,
-- 分类页UV
count(distinct(case when event_id='NE030' and page_id_var='CL' then visit_id else null end)) category_page_uv,
-- 详情页PV
count(case when event_id='SE002' then visit_id else null end) detail_page_pv,
-- 详情页UV
count(distinct(case when event_id='SE002' then visit_id else null end)) detail_page_uv,
-- 立即下载按钮点击UV
count(distinct(case when event_id='SE003' then visit_id else null end)) down_button_click_uv,
-- 登录框展示PV
count(case when event_id='NE006' and module_id_var='login' then visit_id else null end) login_box_show_pv,
-- 登录框展示UV
count(distinct(case when event_id='NE006' and module_id_var='login' then visit_id else null end)) login_box_show_uv,
-- 登录成功UV
count(distinct(case when event_id='SE001' and get_json_object(var,'$.loginResult')='1' then user_id else null end)) login_succ_uv,
-- VIP购买页到达PV
count(case when event_id='NE006' and module_id_var='vipPayCon' then visit_id else null end) vip_pay_arrive_pv,
-- VIP购买页到达UV
count(distinct(case when event_id='NE006' and module_id_var='vipPayCon' then visit_id else null end)) vip_pay_arrive_uv,
-- 立即支付按钮点击PV
count(case when event_id='SE010' then visit_id else null end) pay_button_click_pv,
-- 立即支付按钮点击UV
count(distinct(case when event_id='SE010' then visit_id else null end)) pay_button_click_uv,
-- 订单生成笔数
count(distinct(case when event_id='SE033' then get_json_object(var,'$.orderID') else null end)) order_generate_num,
-- 订单生成UV
count(distinct(case when event_id='SE033' then visit_id else null end)) order_generate_uv
from(
select
-- 终端类型
case when substring(terminal_type,0,1)='0' then 'pc'
when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
when substring(terminal_type,0,1)='2' then '快应用'
when substring(terminal_type,0,1)='3' then 'android'
when substring(terminal_type,0,1)='4' then 'ios'
when substring(terminal_type,0,1)='6' then '今日头条小程序'
when substring(terminal_type,0,1)='7' then '百度小程序'
when substring(terminal_type,0,1)='8' then '微信小程序' else '' end as terminal_type,
-- 站点
case when site_type='office' then '办公' when site_type='supperContract' then '超级合同' when site_type='tyContract' then '合同通'
when site_type='tyContract02' then '合同通02' when site_type='htzj' then '合同之家' else site_type end site_type,
event_id,
visit_id,
page_id_var,
module_id_var,
user_id,
var
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and site_type in ('office','supperContract','tyContract','tyContract02','htzj')
) session_event
group by terminal_type,site_type
) a

left join(
select
    order_info.source_mode,
    order_info.channel_source,
    -- 支付成功笔数
    count(order_info.id) pay_succ_num,
    -- 支付成功uv
    count(distinct order_info.buyer_user_id) pay_succ_uv
from(
select
distinct
get_json_object(var, '$.orderID') order_id
from dw_fact.dw_fact_ishare_session_event
where dt='20210506'
and site_type in ('office','supperContract','tyContract','tyContract02', 'htzj')
and event_id='SE034'
and get_json_object(var, '$.orderID') is not null
) session_event

left join(
select
-- 终端
case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' else '' end as source_mode,
-- 站点
case when channel_source=0 then '办公'
when channel_source=5 then '超级合同'
when channel_source=7 then '合同通'
when channel_source=9 then '合同之家' else channel_source end channel_source,
id,
buyer_user_id
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status=2
and goods_type in (1,2,4,8,12,13,14)
and channel_source in (0,5,7,9)
) order_info on session_event.order_id = order_info.id
where order_info.id is not null
group by order_info.source_mode, order_info.channel_source
) b on a.terminal_type = b.source_mode and a.site_type = b.channel_source
where a.terminal_type <> ''