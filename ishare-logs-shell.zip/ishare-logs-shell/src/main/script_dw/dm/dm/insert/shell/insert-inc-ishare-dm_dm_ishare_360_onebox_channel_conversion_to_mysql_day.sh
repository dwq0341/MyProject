#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "ishare_360_onebox_channel_conversion_to_mysql_day 360noebox渠道转化报表 数据导入 sh开始标志"
sh /usr/local/datax/job/baiduSem/ishare_360_onebox_channel_conversion_sync_day_new.sh ${date_day} ${end_date}
echo "ishare_360_onebox_channel_conversion_to_mysql_day 360noebox渠道转化报表 数据导入 sh结束标志"