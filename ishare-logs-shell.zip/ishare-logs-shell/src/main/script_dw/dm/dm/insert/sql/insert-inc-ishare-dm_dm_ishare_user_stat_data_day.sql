set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_user_stat_data_day partition(dt)
select
--周期
'${date_day}' account_period,
--用户类型
case e.user_type when 1 then '普通' when 2 then '个人' when 3 then '机构' end as user_type,
--会员类型
coalesce(e.vip_name, ' '),
--累计用户量
count(distinct(case when (substr(e.create_time,0,10) <= from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')) then e.code else null end)) total_user_num,
--新增用户量
count(distinct(case when (substr(e.create_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')) then e.code else null end)) new_user_num,
--下载用户量
count(distinct(case when (e.event_id='SE014' and e.down_result='1') then e.user_id else null end)) down_user_num,
--付费资料下载次数
count(case when e.event_id='SE003' and e.file_pay_type='cost' then e.file_id else null end) cost_file_down_cnt,
--免费资料下载次数
count(case when e.event_id='SE003' and e.file_pay_type='free' then e.file_id else null end) free_file_down_cnt,
--资料下载次数
count(case when e.event_id='SE003' then e.file_id else null end) file_down_cnt,
--总消费金额
sum ((case when e.userId=1 and e.buyer_user_id is not null and e.buyer_user_id != '' then e.pay_price else 0 end)) total_cash_price,
--分成收入金额
sum ((case when e.userId=1 and e.buyer_user_id is not null and e.buyer_user_id != '' then e.seller_price else 0 end)) divided_price,
--update_time
'${date_day}' update_time,
--dt
'${date_day}' dt
from(
select
    a.visit_id,
    a.user_id,
    b.code,
    b.create_time,
    c.id,
    c.userTypeId,
    d.member_user_id,
    d.vip_name,
    a.event_id,
    a.down_result,
    a.file_pay_type,
    a.file_id,
    info.buyer_user_id,
    info.pay_price,
    info.seller_price,
    row_number() over(partition by user_id) userId,
    case when (a.visit_id is not null and (a.user_id is not null and a.user_id != '')) then userTypeId
    when ((a.visit_id is null or a.visit_id='null' or a.visit_id='') and (a.user_id is not null and a.user_id != '')) then userTypeId else null end as user_type
from(
select
    visit_id,
    user_id,
    event_id,
    down_result,    --下载结果
    file_pay_type,  --付费资料类型
    file_id         --资料id
from dw_fact.dw_fact_ishare_log_events
where dt='${date_day}'
and user_id != ''
and user_id is not null
) a
left join(
select
    code,
    max(create_time) create_time
from ods_ods.ods_ods_ishare_tb_login_user
group by code
) b on a.user_id = b.code
left join(
select
    id,
    max(userTypeId) userTypeId
from ods_ods.ods_ods_ishare_users_new
group by id
) c on b.code = c.id
left join(
select
    user_id as member_user_id,  --用户id
    max(vip_name) vip_name  --购买的vip名称
from dw_fact.dw_fact_ishare_user_member
where user_member_type = 'VIP'
and end_date >= from_unixtime(unix_timestamp() ,'yyyy-MM-dd HH:mm:ss')
and status = '2'
and user_id is not null
and user_id != ''
group by user_id, id
) d on c.id=d.member_user_id
left join(
select
    id,
    buyer_user_id,            --买家用户id
    pay_price/100 pay_price,  --订单金额
    seller_price              --卖家分成金额
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status = 2
) info
on a.user_id = info.buyer_user_id
) e
where e.user_type is not null
group by e.user_type, e.vip_name



--访客
union all
select
--周期
'${date_day}' account_period,
--用户类型
'访客' user_type,
--会员类型
' ' vip_name,
--累计用户量
count(distinct(case when e.visit_id is not null and e.visit_id != '' then e.visit_id else null end)) total_user_num,
--新增用户量
count(distinct(case when s.visit_id is null and s.visit_id = '' then e.visit_id else null end)) new_user_num,
--下载用户量
count(distinct(case when (e.event_id='SE014' and e.down_result='1') then e.visit_id else null end)) down_user_num,
--付费资料下载次数
count(case when e.event_id='SE003' and e.file_pay_type='cost' then e.file_id else null end) cost_file_down_cnt,
--免费资料下载次数
count(case when e.event_id='SE003' and e.file_pay_type='free' then e.file_id else null end) free_file_down_cnt,
--资料下载次数
count(case when e.event_id='SE003' then e.file_id else null end) file_down_cnt,
--总消费金额
sum ((case when e.visitId=1 and e.buyer_user_id is not null and e.buyer_user_id != '' then e.pay_price else 0 end)) total_cash_price,
--分成收入金额
sum ((case when e.visitId=1 and e.buyer_user_id is not null and e.buyer_user_id != '' then e.seller_price else 0 end)) divided_price,
--update_time
'${date_day}' update_time,
--dt
'${date_day}' dt
from(
select
    a.visit_id,
    a.user_id,
    a.event_id,
    a.down_result,
    a.file_pay_type,
    a.file_id,
    a.nginx_date,
    n2.pay_price,
    n2.seller_price,
    n2.buyer_user_id,
    row_number() over(partition by visit_id) visitId,
    case when (a.visit_id is not null and a.visit_id != '' and (a.user_id is null or a.user_id = '')) then 4 else null end as user_type
from(
select
    visit_id,
    user_id,
    event_id,
    down_result,    --下载结果
    file_pay_type,  --付费资料类型
    file_id,        --资料id
    nginx_date      --时间
from dw_fact.dw_fact_ishare_log_events
where dt='${date_day}'
and visit_id != ''
and visit_id is not null
) a
left join(
select
    id,
    buyer_user_id, --买家用户id
    pay_price/100 pay_price,  --订单金额
    seller_price --卖家分成金额
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status = 2
) n2 on a.visit_id = n2.buyer_user_id
) e
left join(
select
    visit_id,
    user_id,
    nginx_date
from dw_fact.dw_fact_ishare_log_events_sort
) s on s.visit_id=e.visit_id and s.nginx_date=e.nginx_date