set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_welfare_use_path partition(dt)
select
'${date_day}' stat_period,
event.signin_button_pv,
event.signin_button_uv,
event.look_button_pv,
event.look_button_uv,
event.home_login_button_pv,
event.home_login_button_uv,
event.open_status_signin_pv,
event.open_status_signin_uv,
event.registered_button_pv,
event.registered_button_uv,
event.members_use_button_pv,
event.members_use_button_uv,
event.android_vip_button_pv,
event.android_vip_button_uv,
event.my_coupon_pv,
event.my_coupon_uv,
event.my_folder_pv,
event.my_folder_uv,
signIn_record.signin_succ_total_user,
split(record.continuous_signin_day,'-')[0] one_day,
split(record.continuous_signin_day,'-')[1] two_day,
split(record.continuous_signin_day,'-')[2] three_day,
split(record.continuous_signin_day,'-')[3] four_day,
split(record.continuous_signin_day,'-')[4] five_day,
split(record.continuous_signin_day,'-')[5] six_day,
split(record.continuous_signin_day,'-')[6] seven_day,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time, --更新时间
'${date_day}' dt    --分区字段
from(
select
--签到按钮点击
sum(case when dom_id_var='sighInButtonClick' then 1 else 0 end) signin_button_pv,
count(distinct(case when dom_id_var='sighInButtonClick' then visit_id else null end)) signin_button_uv,
--查看按钮点击
sum(case when dom_id_var='checkButtonClick' then 1 else 0 end) look_button_pv,
count(distinct(case when dom_id_var='checkButtonClick' then visit_id else null end)) look_button_uv,
--首页-登录按钮点击
sum(case when dom_id_var='userDataLogOutClick' then 1 else 0 end) home_login_button_pv,
count(distinct(case when dom_id_var='userDataLogOutClick' then visit_id else null end)) home_login_button_uv,
--开启状态签到提醒按钮点击
sum(case when dom_id_var='turnOffPushClick' then 1 else 0 end) open_status_signin_pv,
count(distinct(case when dom_id_var='turnOffPushClick' then visit_id else null end)) open_status_signin_uv,
--个人中心-登录/注册按钮点击
sum(case when dom_id_var='userDataNotloginClick' then 1 else 0 end) registered_button_pv,
count(distinct(case when dom_id_var='userDataNotloginClick' then visit_id else null end)) registered_button_uv,
--会员-去使用按钮点击
sum(case when dom_id_var='myVipModuleClick' then 1 else 0 end) members_use_button_pv,
count(distinct(case when dom_id_var='myVipModuleClick' then visit_id else null end)) members_use_button_uv,
--安卓-开通VIP按钮点击
sum(case when dom_id_var='notVipModuleClick' then 1 else 0 end) android_vip_button_pv,
count(distinct(case when dom_id_var='notVipModuleClick' then visit_id else null end)) android_vip_button_uv,
--我的优惠券banner图点击
sum(case when dom_id_var='myCpClick' then 1 else 0 end) my_coupon_pv,
count(distinct(case when dom_id_var='myCpClick' then visit_id else null end)) my_coupon_uv,
--我的文件夹banner图点击
sum(case when dom_id_var='myFilesClick' then 1 else 0 end) my_folder_pv,
count(distinct(case when dom_id_var='myFilesClick' then visit_id else null end)) my_folder_uv
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and event_id='NE002'
and terminal_type='8-4'
) event

left join(
select
    concat_ws('-',
    cast(count(case when real_continue_day=1 then user_id else null end) as string),
    cast(count(case when real_continue_day=2 then user_id else null end) as string),
    cast(count(case when real_continue_day=3 then user_id else null end) as string),
    cast(count(case when real_continue_day=4 then user_id else null end) as string),
    cast(count(case when real_continue_day=5 then user_id else null end) as string),
    cast(count(case when real_continue_day=6 then user_id else null end) as string),
    cast(count(case when real_continue_day=7 then user_id else null end) as string)
    ) continuous_signin_day
from dw_fact.dw_fact_ishare_tb_bff_signIn_record
where substr(create_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) record on 1=1

left join(
select
    count(distinct user_id) signin_succ_total_user
from dw_fact.dw_fact_ishare_tb_bff_signIn_record
where substr(create_time,0,10)<=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) signIn_record on 1=1