--登录明细
set hive.execution.engine=mr;
set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_t_user_login_day_new partition(dt)
-- 全部终端类型/全部登录方式
select
'${date_day}' stat_period,
'全部' terminal,
'全部' source,
count(uid) login_succ_cnt,
count(distinct uid) login_succ_user_cnt,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    uid,
    apply
from ods_ods.ods_ods_ishare_tb_login_user_flow
where substr(update_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) a

--全部终端类型/区分登录方式
union all
select
'${date_day}' stat_period,
'全部' terminal,
source,
count(uid) login_succ_cnt,
count(distinct uid) login_succ_user_cnt,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    uid,
    apply,
    source
from ods_ods.ods_ods_ishare_tb_login_user_flow
where substr(update_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) a
group by a.source

--区分终端类型/区分登录方式
union all
select
'${date_day}' stat_period,
terminal,
source,
count(uid) login_succ_cnt,
count(distinct uid) login_succ_user_cnt,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    uid,
    apply,
    source,
    case when terminal = '7' then apply else terminal end terminal
from ods_ods.ods_ods_ishare_tb_login_user_flow
where substr(update_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) a
group by a.terminal, a.source

--区分终端类型/全部登录方式
union all
select
'${date_day}' stat_period,
terminal,
'全部' source,
count(uid) login_succ_cnt,
count(distinct uid) login_succ_user_cnt,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    uid,
    apply,
    source,
    case when terminal = '7' then apply else terminal end terminal
from ods_ods.ods_ods_ishare_tb_login_user_flow
where substr(update_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) a
group by a.terminal