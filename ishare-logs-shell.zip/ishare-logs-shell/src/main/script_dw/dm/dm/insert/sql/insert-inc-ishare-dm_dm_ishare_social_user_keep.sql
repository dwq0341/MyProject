-- 若干用户在180天之后取消关注
-- count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and ( unix_timestamp(max_create_time) - unix_timestamp(min_create_time) > 180*24*60*60) then e.open_id else null end ) unsubscribe_num_360,
-- 若干用户只要取关但是没有关注事件，所以找不到create_time
-- count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (min_create_time is null or max_create_time is null) then 1 else null end ) unsubscribe_num_other
with openid_action as (
select * from (
select
open_id,
union_id,
event_id,
create_time,
row_number() over(partition by open_id order by create_time desc) sort_num
from dw_Fact.dw_fact_tb_message_wechat_report_data where event_id in ('FE002','FE001')) a where sort_num <= 2)

insert overwrite table dm_dm.dm_dm_ishare_social_user_keep
select
'${date_day}' account_day,
COALESCE(name,'') official_account,
-- 会null的情况是会出现有关注事件但是没有出现数据上报事件
COALESCE(subscribe_scene,'') channel,
count(case when e.event_id = 'FE001' then e.open_id else null end ) subscribe_num,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and replace(substr(h.min_create_time,0,10),'-','') = '${date_day}' then e.open_id else null end ) unsubscribe_num,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (unix_timestamp(max_create_time) - unix_timestamp(min_create_time) <= 24*60*60) then e.open_id else null end ) unsubscribe_num_1,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (24*60*60 < unix_timestamp(max_create_time) - unix_timestamp(min_create_time) and unix_timestamp(max_create_time) - unix_timestamp(min_create_time) <= 48*60*60) then e.open_id else null end ) unsubscribe_num_2,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (48*60*60 < unix_timestamp(max_create_time) - unix_timestamp(min_create_time) and unix_timestamp(max_create_time) - unix_timestamp(min_create_time) <= 72*60*60) then e.open_id else null end ) unsubscribe_num_3,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (72*60*60 < unix_timestamp(max_create_time) - unix_timestamp(min_create_time) and unix_timestamp(max_create_time) - unix_timestamp(min_create_time) <= 7*24*60*60) then e.open_id else null end ) unsubscribe_num_7,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (7*24*60*60 < unix_timestamp(max_create_time) - unix_timestamp(min_create_time) and unix_timestamp(max_create_time) - unix_timestamp(min_create_time) <= 30*24*60*60) then e.open_id else null end ) unsubscribe_num_30,
count(case when e.event_id = 'FE002' and h.subscribe_open_id is not null and (30*24*60*60 < unix_timestamp(max_create_time) - unix_timestamp(min_create_time) and unix_timestamp(max_create_time) - unix_timestamp(min_create_time) <= 180*24*60*60) then e.open_id else null end ) unsubscribe_num_180,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time
from
(
select 
a.event_id,
a.open_id,
max(d.name) name,
max(b.subscribe_scene) subscribe_scene
from
(select
union_id,open_id,event_id
from dw_Fact.dw_fact_tb_message_wechat_report_data where dt = substr('${date_day}',0,6) and event_id in ('FE001','FE002') and replace(substr(create_time,0,10),'-','') = '${date_day}'
group by union_id,open_id,event_id) a 
left join (
select
union_id,open_id,subscribe_scene
from dw_Fact.dw_fact_tb_message_wechat_report_data where event_id = 'FE004'
group by union_id,open_id,subscribe_scene
) b on a.open_id = b.open_id
left join 
(select union_id,open_id,app_id from dw_Fact.dw_fact_tb_message_wechat_public_user) c on a.open_id = c.open_id 
left join dw_Fact.dw_fact_tb_message_wechat_info d on c.app_id = d.app_id 
group by a.open_id,a.event_id) e
left join (
select
COALESCE(f.open_id,g.open_id) open_id,
f.union_id,
g.open_id subscribe_open_id,
f.create_time min_create_time,
g.create_time max_create_time
from (select * from openid_action where event_id = 'FE001') f
-- 这里用full join防止出现只有同一个openId用户FE002有但是FE001没有的情况
full join (select open_id,union_id,event_id,create_time from openid_action where event_id = 'FE002') g on f.open_id = g.open_id 
-- 这里用subscribe_open_id与e表的open_id关联是因为会出现同一个openId用户FE002有但是FE001没有的情况
) h on e.open_id = h.subscribe_open_id
group by COALESCE(name,''),COALESCE(subscribe_scene,'')
union all
select 
account_day,
official_account,
channel,
subscribe_num,
unsubscribe_num,
unsubscribe_num_1,
unsubscribe_num_2,
unsubscribe_num_3,
unsubscribe_num_7,
unsubscribe_num_30,
unsubscribe_num_180,
update_time                 
from dm_dm.dm_dm_ishare_social_user_keep
where account_day <> '${date_day}';