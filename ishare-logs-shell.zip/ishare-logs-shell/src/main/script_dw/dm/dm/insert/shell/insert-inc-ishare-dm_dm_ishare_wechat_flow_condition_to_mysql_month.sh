#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "ishare_wechat_flow_condition_sync_month 微信端流量概况 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/social/ishare_wechat_flow_condition_sync_month.sh ${date_day}
echo "ishare_wechat_flow_condition_sync_month 微信端流量概况 数据导入sh结束标志"