#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行insert-inc-ishare-dm_dm_ishare_global_user_indicators表导入 sh开始标志"
sh /usr/local/datax/job/mysqlTable/result/ishare_global_user_indicators_to_mysql.sh
echo "执行insert-inc-ishare-dm_dm_ishare_global_user_indicators表导入 sh结束标志"