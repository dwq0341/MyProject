#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "ishare_file_production_sync_day 资料生产统计 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/content/ishare_file_production_sync_day.sh ${date_day}
echo "ishare_file_production_sync_day 资料生产统计 数据导入sh结束标志"


echo "ishare_file_distribute_sync_day 资料分发统计 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/content/ishare_file_distribute_sync_day.sh ${date_day}
echo "ishare_file_distribute_sync_day 资料分发统计 数据导入sh结束标志"


echo "ishare_file_production_history_sync_day 资料生产历史统计 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/content/ishare_file_production_history_sync_day.sh ${date_day}
echo "ishare_file_production_history_sync_day 资料生产历史统计 数据导入sh结束标志"


echo "ishare_special_sync_day 专题分析 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/content/ishare_special_sync_day.sh ${date_day}
echo "ishare_special_sync_day 专题分析 数据导入sh结束标志"


echo "ishare_special_file_conversion_sync_day 专题资料转化分析 数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/content/ishare_special_file_conversion_sync_day.sh ${date_day}
echo "ishare_special_file_conversion_sync_day 专题资料转化分析 数据导入sh结束标志"