#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

source ../../../../common/env/hive_env.sh

echo "执行dm_dm_ishare_user_profile_indicators表导入 sh开始标志"
sh /usr/local/datax/job/mysqlTable/result/ishare_user_profile_indicators_to_mysql.sh
echo "执行dm_dm_ishare_user_profile_indicators表导入 sh结束标志"