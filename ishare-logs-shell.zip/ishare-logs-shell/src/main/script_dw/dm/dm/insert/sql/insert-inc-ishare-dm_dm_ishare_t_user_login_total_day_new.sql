--登录汇总: 区分终端类型
set hive.execution.engine=mr;
set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_t_user_login_total_day_new partition(dt)
select
'${date_day}' stat_period,
a.terminal_type,
b.login_succ_cnt,
a.already_login_user,
a.login_pv,
a.login_uv,
b.login_succ_user_cnt,
b.login_succ_user_cnt / a.login_uv login_rate,    --登录成功率
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    terminal_type,
    count(distinct (case when event_id='NE001' and user_id <> '' then user_id else null end)) already_login_user,   --登录状态用户数
    count((case when event_id='NE006' and module_id='login' then visit_id else null end)) login_pv,     --登录框pv
    count(distinct (case when event_id='NE006' and module_id='login' then visit_id else null end)) login_uv      --登录框uv
from(
select
    user_id,
    visit_id,
    page_id,
    event_id,
    get_json_object(var,'$.moduleID') module_id,
    case when terminal_type = '0' then 'pc'
    when terminal_type='1' and browser='微信' then '微信浏览器'
    when terminal_type = '1' then 'm'
    when terminal_type = '2' then '快应用'
    when terminal_type = '3' then '安卓'
    when terminal_type = '4' then '苹果'
    when terminal_type = '6' then '今天头条'
    when terminal_type = '7' then '百度小程序'
    when terminal_type = '8-1' then '微信小程序_爱问办公模板'
    when terminal_type = '8-2' then '微信小程序_爱问文件管理'
    when terminal_type = '8-3' then '微信小程序_爱问模板'
    when terminal_type = '8-4' then '微信小程序_爱问福利社' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
) n
group by n.terminal_type
) a

left join(
select
terminal,                                --终端类型
count(uid) login_succ_cnt,               --登录成功次数
count(distinct uid) login_succ_user_cnt  --登录成功用户数
from(
select
uid,
case terminal when '0' then 'pc' when '1' then 'm' when '2' then '安卓' when '3' then '苹果'
when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器'
when '7' then (case when apply='701' then '微信小程序_爱问办公模板' when apply='702' then '微信小程序_爱问文件管理'
when apply='703' then '微信小程序_爱问模板' when apply='704' then '微信小程序_爱问福利社' else null end) else null end as terminal
from ods_ods.ods_ods_ishare_tb_login_user_flow
where substr(update_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) user_flow
group by user_flow.terminal
) b on a.terminal_type=b.terminal

--全部终端类型
union all
select
'${date_day}' stat_period,
a.terminal_type,
b.login_succ_cnt,
a.already_login_user,
a.login_pv,
a.login_uv,
b.login_succ_user_cnt,
b.login_succ_user_cnt / a.login_uv login_rate,    --登录成功率
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    '全部' terminal_type,
    count(distinct (case when event_id='NE001' and user_id <> '' then user_id else null end)) already_login_user,    --登录状态用户数
    count((case when event_id='NE006' and get_json_object(var,'$.moduleID')='login' then visit_id else null end)) login_pv,     --登录框pv
    count(distinct (case when event_id='NE006' and get_json_object(var,'$.moduleID')='login' then visit_id else null end)) login_uv      --登录框uv
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
) a

left join(
select
'全部' terminal,
count(uid) login_succ_cnt,                        --登录成功次数
count(distinct uid) login_succ_user_cnt           --登录成功用户数
from ods_ods.ods_ods_ishare_tb_login_user_flow
where substr(update_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) b on 1=1