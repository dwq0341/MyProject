set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_channel_transfor partition(dt)
select
terminal_type,
site_type,
search_engine,
login_status,
2th_traffic_source,
3th_traffic_source,
SUBSTRING(COALESCE(reflect('java.net.URLDecoder', 'decode',utm_medium , "UTF-8"),''),0,50)  utm_medium,
SUBSTRING(COALESCE(reflect('java.net.URLDecoder', 'decode',utm_content , "UTF-8"),''),0,50)  utm_content,
SUBSTRING(COALESCE(reflect('java.net.URLDecoder', 'decode',utm_campaign , "UTF-8"),''),0,50)  utm_campaign,
SUBSTRING(COALESCE(reflect('java.net.URLDecoder', 'decode',utm_term , "UTF-8"),''),0,50) utm_term,
SUBSTRING(COALESCE(reflect('java.net.URLDecoder', 'decode',utm_source , "UTF-8"),''),0,50) utm_source,
pv,
uv,
open_vip_num,
register_num,
uv_num_download,
user_num_download,
free_file_download,
pay_file_download,
vip_income,
file_income,
dt,
update_time,
dt
from dm_dm.dm_dm_ishare_channel_transfor
where dt='${date_day}'
