insert overwrite table dm_dm.dm_dm_ishare_user_profile_indicators
-- 是否会员
select 
tag,   
tag_value,
count(1) num,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
'${date_day}' dTime
 from
(
select
id,
max(tag) tag,
max(tag_value) tag_value
from
dm_dm.dm_dm_ishare_user_feature_single
where tag = 'is_vip'
group by id) a
group by tag,tag_value
union all
-- 新老会员
select 
tag,
tag_value,
count(1) num,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
'${date_day}' dTime
from
(
select
id,
max(tag) tag,
max(tag_value) tag_value
from
dm_dm.dm_dm_ishare_user_feature_single
where tag = 'user_fresh'
group by id) a
group by tag,tag_value
union all
-- 会员信息
select 
tag,
split(b.vipname,':')[1] name,
count(1) num,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
'${date_day}' dTime
 from (
select
tag,id,vipinfo.*
from dm_dm.dm_dm_ishare_user_feature_single a
lateral view explode(split(a.tag_value,',')) vipinfo as vipname
where tag = 'vip_info' and id <> '' ) b
group by split(b.vipname,':')[1],tag
union all
-- 注册渠道
select
tag,
COALESCE(tag_value,''),
count(1) num,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
'${date_day}' dTime
from
dm_dm.dm_dm_ishare_user_feature_single
where tag = 'create_source'
group by COALESCE(tag_value,''),tag
union all
-- 最近访问渠道
select
tag,
tag_value,
count(1) num,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
'${date_day}' dTime
from
dm_dm.dm_dm_ishare_user_feature_single
where tag = 'last_visit_source'
group by tag_value,tag
union all
-- 最近购买渠道
select
tag,
tag_value,
count(1) num,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
'${date_day}' dTime
from
dm_dm.dm_dm_ishare_user_feature_single
where tag = 'last_pay_source'
group by tag_value,tag;