set mapred.child.java.opts=-Xmx1024m;
set mapreduce.map.java.opts=-Xmx1310m;
set yarn.app.mapreduce.am.command-opts=-Xmx2457m;
set mapreduce.reduce.java.opts=-Xmx2620m;
set mapreduce.map.memory.mb=4096;
insert overwrite table dm_dm.dm_dm_ishare_360onebox_order_money partition(dt='${date_day}')
            select
            m.event_time ,
          m.land_url_channel ,
          m.terminal_type ,
          m.site_type ,
          m.keyword_id ,
          m.buy_content,
          sum(cast(m.payprice as double)) pay_money
          from (
            select
            j.event_time ,
         '360onebox' land_url_channel ,
          j.terminal_type ,
          j.site_type ,
          j.keyword_id ,
          'file' buy_content,
          k.payprice
            from
            (
             select
             get_json_object(var,'$.orderID') order_id,
            split(s.event_time,' ')[0] event_time,
            case when s.terminal_type='0' then 'PC' when s.terminal_type='1' then 'M'  else '' end terminal_type ,
            case when split(s.page_id, '-')[1] = 'M' then '主站' when split(s.page_id, '-')[1] = 'O' then '办公频道' else '' end site_type,
           split(s.land_url,'360onebox')[1] keyword_id

           from dw_fact.dw_fact_ishare_session_event s   where  s.event_id='SE009' and  s.land_url  regexp('.*360onebox.*')  and s.dt='${date_day}' and  get_json_object(s.var,'$.payResult')='1') j
           left join dw_dim.dw_dim_ishare_t_order_info k on j.order_id=k.id ) m group by  m.event_time,m.land_url_channel,m.terminal_type, m.site_type,m.keyword_id,m.buy_content




           union all


            select
            m.event_time ,
          m.land_url_channel ,
          m.terminal_type ,
          m.site_type ,
          m.keyword_id ,
          m.buy_content,
          sum(cast(m.payprice as double)) pay_money
          from (
            select
            j.event_time ,
         '360onebox' land_url_channel ,
          j.terminal_type ,
          j.site_type ,
          j.keyword_id ,
          'vip' buy_content,
          k.payprice
            from
            (
             select
             get_json_object(var,'$.orderID') order_id,
            split(s.event_time,' ')[0] event_time,
            case when s.terminal_type='0' then 'PC' when s.terminal_type='1' then 'M'  else '' end terminal_type ,
            case when split(s.page_id, '-')[1] = 'M' then '主站' when split(s.page_id, '-')[1] = 'O' then '办公频道' else '' end site_type,
           split(s.land_url,'360onebox')[1] keyword_id

           from dw_fact.dw_fact_ishare_session_event s   where  s.event_id='SE011' and  s.land_url  regexp('.*360onebox.*')  and s.dt='${date_day}' and  get_json_object(s.var,'$.payResult')='1') j
           left join dw_dim.dw_dim_ishare_t_order_info k on j.order_id=k.id ) m group by  m.event_time,m.land_url_channel,m.terminal_type, m.site_type,m.keyword_id,m.buy_content


            union all


            select
            m.event_time ,
          m.land_url_channel ,
          m.terminal_type ,
          m.site_type ,
          m.keyword_id ,
          m.buy_content,
          sum(cast(m.payprice as double)) pay_money
          from (
            select
            j.event_time ,
         '360onebox' land_url_channel ,
          j.terminal_type ,
          j.site_type ,
          j.keyword_id ,
          'pri' buy_content,
          k.payprice
            from
            (
             select
             get_json_object(var,'$.orderID') order_id,
            split(s.event_time,' ')[0] event_time,
            case when s.terminal_type='0' then 'PC' when s.terminal_type='1' then 'M'  else '' end terminal_type ,
            case when split(s.page_id, '-')[1] = 'M' then '主站' when split(s.page_id, '-')[1] = 'O' then '办公频道' else '' end site_type,
           split(s.land_url,'360onebox')[1] keyword_id

           from dw_fact.dw_fact_ishare_session_event s   where  s.event_id='SE013' and  s.land_url  regexp('.*360onebox.*')  and s.dt='${date_day}' and  get_json_object(s.var,'$.payResult')='1') j
           left join dw_dim.dw_dim_ishare_t_order_info k on j.order_id=k.id ) m group by  m.event_time,m.land_url_channel,m.terminal_type, m.site_type,m.keyword_id,m.buy_content







