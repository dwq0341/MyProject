set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_advertising_detail_day partition(dt)
select
	a.dayno, 				    --日期
	a.site,					    --站点
	a.page_group,			    --页面组
	a.ad_name,				    --广告位
	sum(income) income,		    --收入
	sum(view) view, 			--展现量,
	sum(click) click,		    --点击量
	round(sum(click)/sum(pv), 5) click_rate,	--点击率
	round(sum(view)/sum(pv), 5) view_per_pv, 		--PV代码量
	sum(income)/sum(click) clickprice, 		--点击单价
	sum(income)/sum(uv) UECPM,
	cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,     --更新时间
    '${date_day}' dt
from(
select
    from_unixtime(unix_timestamp(time, 'yyyymmdd'),'yyyy-mm-dd') dayno,
	site,
	page_group,
	ad_name,
	income,
	click,
	view
from dw_fact.dw_fact_iask_t_ssp_rpt_ad_position
where time='${date_day}'
) a
join(
select
	dayno,
	site,
	pv,
	uv
from dw_fact.dw_fact_iask_t_date_iask_total a
where dayno=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) b on a.dayno=b.dayno and a.site=b.site
group by a.dayno, a.site, a.page_group, a.ad_name