#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行ishare_platform_sem_plan_metric_day 用户统计表数据导入sh开始"
sh /usr/local/datax/job/mysqlTable/result/ishare_user_stat_data_sync_day.sh ${date_day}  ${end_date}
echo "执行ishare_platform_sem_plan_metric_day 用户统计表数据导入sh结束标志"