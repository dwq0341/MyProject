set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_360_onebox_channel_conversion_day partition(dt)
select
    '${date_day}' stat_period,
    session_event.source_mode,
    session_event.channel_source,
    session_event.utm_source,
    session_event.utm_term,
    session_event.land_url_pv,
    session_event.land_url_uv,
    session_event.land_person_avg_pv,
    --落地页跳出率
    b.visit_id_num / session_event.land_url_uv jump_rate,
    session_event.down_click_pv,
    session_event.down_click_uv,
    session_event.login_pv,
    session_event.login_uv,
    session_event.vip_setmeal_page_pv,
    session_event.vip_setmeal_page_uv,
    session_event.vip_setmeal_perAvg_pv,
    session_event.vip_pay_click_pv,
    session_event.vip_pay_click_uv,

    order_info.vip_pay_succ_orderNum,
    order_info.vip_pay_succ_price,
    order_info.vip_pay_succ_perNum,
    order_info.vip_pay_succ_orderNum / session_event.vip_setmeal_page_uv vip_setmeal_conversion_rate,

    session_event.file_buy_page_pv,
    session_event.file_buy_page_uv,
    session_event.file_buy_perAvg_pv,
    session_event.file_pay_click_pv,
    session_event.file_pay_click_uv,

    order_info.file_pay_succ_orderNum,
    order_info.file_pay_succ_price,
    order_info.file_pay_succ_perNum,
    -- 资料购买转化率：资料支付成功订单数/资料购买页uv
    order_info.file_pay_succ_orderNum/ session_event.file_buy_page_uv file_buy_conversion_rate,
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
    session_event.land_url,
    '${date_day}' dt
from(
select
    a.source_mode,
    a.channel_source,
    a.utm_source,
    a.utm_term,
    a.land_url,
    --落地页pv/uv
    count(case when(a.page_url = a.land_url and a.event_id = 'NE001') then a.page_url else null end) land_url_pv,
    count(distinct(case when (a.page_url = a.land_url and a.visit_id <> '' and a.visit_id is not null and a.event_id = 'NE001') then a.visit_id else null end)) land_url_uv,
    -- 落地页人均pv：落地页pv/落地页uv
    count(case when(a.page_url = a.land_url and a.event_id = 'NE001') then a.page_url else null end) / count(distinct(case when (a.page_url = a.land_url and a.visit_id <> '' and a.visit_id is not null and a.event_id = 'NE001') then a.visit_id else null end)) land_person_avg_pv,
    --立即下载点击
    sum(case when a.event_id='SE003' then 1 else 0 end) down_click_pv,
    count(distinct(case when a.event_id='SE003' then a.visit_id else null end)) down_click_uv,
    --登录框
    sum(case when a.event_id='NE006' and a.module_id_var='login' then 1 else 0 end) login_pv,
    count(distinct(case when a.event_id='NE006' and a.module_id_var='login' then a.visit_id else null end)) login_uv,
    --vip套餐页
    sum(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then 1 else 0 end) vip_setmeal_page_pv,
    count(distinct(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then a.visit_id else null end)) vip_setmeal_page_uv,
    --vip套餐页人均pv：vip套餐页pv/vip套餐页uv
    sum(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then 1 else 0 end) / count(distinct(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then a.visit_id else null end)) vip_setmeal_perAvg_pv,
    -- vip 立即支付点击
    sum(case when a.event_id='SE010' then 1 else 0 end) vip_pay_click_pv,
    count(distinct(case when a.event_id='SE010' then a.visit_id else null end)) vip_pay_click_uv,

    -- 资料购买页pv：NE006，module_id_var=filePayCon
     sum(case when a.event_id='NE006' and a.module_id_var='filePayCon' then 1 else 0 end) file_buy_page_pv,
    count(distinct(case when a.event_id='NE006' and a.module_id_var='filePayCon' then a.visit_id else null end)) file_buy_page_uv,
    -- 资料购买页人均pv：资料购买页pv/资料购买页uv
    sum(case when a.event_id='NE006' and a.module_id_var='filePayCon' then 1 else 0 end) / count(distinct(case when a.event_id='NE006' and a.module_id_var='filePayCon' then a.visit_id else null end)) file_buy_perAvg_pv,
    -- 资料立即支付点击pv：SE008，求和
    sum(case when a.event_id='SE008' then 1 else 0 end) file_pay_click_pv,
    count(distinct(case when a.event_id='SE008' then a.visit_id else null end)) file_pay_click_uv
from(
select
    case when substring(terminal_type,0,1)='0' then 'pc'
    when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
    when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
    when substring(terminal_type,0,1)='2' then '快应用'
    when substring(terminal_type,0,1)='3' then 'android'
    when substring(terminal_type,0,1)='4' then 'ios'
    when substring(terminal_type,0,1)='6' then '今日头条小程序'
    when substring(terminal_type,0,1)='7' then '百度小程序'
    when substring(terminal_type,0,1)='8' then '微信小程序' else null end as source_mode,

    case when site_type='ishare' then '主站' when site_type='office' then '办公' when site_type='edu' then '教育'
    when site_type='archi' then '建筑' when site_type='supperVip' then '超级会员' when site_type='supperContract' then '超级合同'
    when site_type='supperPPT' then '超级PPT' when site_type='tyContract' then '合同通' when site_type='iLawService' then '爱问法律顾问'
    when site_type='loveConteact' then '爱合同' when site_type='tyContract02' then '合同通02'
    when site_type='htzj' then '合同之家' else site_type end channel_source,

    case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end as utm_source,
    case when land_url regexp('.*utm_term.*') then substring(split(land_url,'utm_term=')[1],0,case when INSTR(split(land_url,'utm_term=')[1],'&') = 0 then (length(split(land_url,'utm_term=')[1])) else (INSTR(split(land_url,'utm_term=')[1],'&') - 1) end) else null end as utm_term,
    event_id,
    module_id_var,
    visit_id,
    page_url,
    land_url
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and (case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end)='360onebox'
and (land_url like '%/f/%' or land_url like '%/c/%' or land_url like '%/node/s/%')
) a
group by a.source_mode, a.channel_source, a.utm_source, a.utm_term, a.land_url
) session_event

left join(
select
    count(distinct ss.visit_id) visit_id_num,
    ss.source_mode,
    ss.channel_source,
    ss.utm_source,
    ss.utm_term,
    ss.land_url
from(
select
    jump.source_mode,
    jump.channel_source,
    jump.utm_source,
    jump.utm_term,
    jump.visit_id,
    jump.event_id,
    jump.land_url
from(
select
    case when substring(terminal_type,0,1)='0' then 'pc'
    when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
    when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
    when substring(terminal_type,0,1)='2' then '快应用'
    when substring(terminal_type,0,1)='3' then 'android'
    when substring(terminal_type,0,1)='4' then 'ios'
    when substring(terminal_type,0,1)='6' then '今日头条小程序'
    when substring(terminal_type,0,1)='7' then '百度小程序'
    when substring(terminal_type,0,1)='8' then '微信小程序' else null end as source_mode,

    case when site_type='ishare' then '主站' when site_type='office' then '办公' when site_type='edu' then '教育'
    when site_type='archi' then '建筑' when site_type='supperVip' then '超级会员' when site_type='supperContract' then '超级合同'
    when site_type='supperPPT' then '超级PPT' when site_type='tyContract' then '合同通' when site_type='iLawService' then '爱问法律顾问'
    when site_type='loveConteact' then '爱合同' when site_type='tyContract02' then '合同通02'
    when site_type='htzj' then '合同之家' else site_type end channel_source,

    case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end as utm_source,
    case when land_url regexp('.*utm_term.*') then substring(split(land_url,'utm_term=')[1],0,case when INSTR(split(land_url,'utm_term=')[1],'&') = 0 then (length(split(land_url,'utm_term=')[1])) else (INSTR(split(land_url,'utm_term=')[1],'&') - 1) end) else null end as utm_term,
    visit_id,
    event_id,
    land_url
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and event_id='NE001'
and (case when page_url regexp('.*utm_source.*') then substring(split(page_url,'utm_source=')[1],0,case when INSTR(split(page_url,'utm_source=')[1],'&') = 0 then (length(split(page_url,'utm_source=')[1])) else (INSTR(split(page_url,'utm_source=')[1],'&') - 1) end) else null end)='360onebox'
and (land_url like '%/f/%' or land_url like '%/c/%' or land_url like '%/node/s/%')
) jump
group by source_mode, channel_source, utm_source, utm_term, visit_id, event_id, land_url having count(*)=1
) ss
group by ss.source_mode, ss.channel_source, ss.utm_source, ss.utm_term, ss.land_url
) b on session_event.source_mode=b.source_mode
and session_event.channel_source=b.channel_source
and session_event.utm_source=b.utm_source
and session_event.utm_term=b.utm_term
and session_event.land_url=b.land_url

left join(
select
    case when channel_source=0 then '办公' when channel_source=4 then '主站' when channel_source=1 then '教育'
    when channel_source=2 then '建筑' when channel_source=5 then '超级合同' when channel_source=6 then '超级PPT'
    when channel_source=7 then '合同通' when channel_source=8 then '爱问法律顾问' else channel_source end channel_source,

    case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' when '101' then '马甲站01' else null end as source_mode,
    utm_source,
    utm_term,
    land_url,
    -- vip支付成功订单数：订单表,商品类型为vip，订单状态为成功的订单数
    count(case when goods_type=2 then id else null end) vip_pay_succ_orderNum,
    -- vip支付成功金额：订单表，商品类型为vip，订单状态为成功的金额
    sum(case when goods_type=2 then pay_price/100 else 0 end) vip_pay_succ_price,
    -- vip支付成功人数：订单表,商品类型为vip，订单状态为成功的人数
    count(distinct(case when goods_type=2 then buyer_user_id else null end)) vip_pay_succ_perNum,
    -- 资料支付成功订单数：订单表,商品类型为资料，订单状态为成功的订单数
    count(case when goods_type=1 then id else null end) file_pay_succ_orderNum,
    -- 资料支付成功金额：订单表,商品类型为资料，订单状态为成功的金额
    sum(case when goods_type=1 then pay_price/100 else 0 end) file_pay_succ_price,
    -- 资料支付成功人数：订单表,商品类型为资料，订单状态为成功的人数
    count(distinct(case when goods_type=1 then buyer_user_id else null end)) file_pay_succ_perNum
from dw_fact.dw_fact_ishare_t_order_info_facts
where mth=substr('${date_day}',0,6)
and substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status=2
and utm_source='360onebox'
and (land_url like '%/f/%' or land_url like '%/c/%' or land_url like '%/node/s/%')
group by channel_source, source_mode, utm_source, utm_term, land_url
) order_info on session_event.source_mode=order_info.source_mode
and session_event.channel_source=order_info.channel_source
and session_event.utm_source=order_info.utm_source
and session_event.utm_term=order_info.utm_term
and session_event.land_url=order_info.land_url

where session_event.source_mode is not null
and session_event.channel_source is not null
and (session_event.utm_source is not null and session_event.utm_source <> '')
and (session_event.utm_term is not null and session_event.utm_term <> '')

--全部
union all
select
    '${date_day}' stat_period,
    session_event.source_mode,
    session_event.channel_source,
    session_event.utm_source,
    '全部' utm_term,
    session_event.land_url_pv,
    session_event.land_url_uv,
    session_event.land_person_avg_pv,
    --落地页跳出率
    b.visit_id_num / session_event.land_url_uv jump_rate,
    session_event.down_click_pv,
    session_event.down_click_uv,
    session_event.login_pv,
    session_event.login_uv,
    session_event.vip_setmeal_page_pv,
    session_event.vip_setmeal_page_uv,
    session_event.vip_setmeal_perAvg_pv,
    session_event.vip_pay_click_pv,
    session_event.vip_pay_click_uv,

    order_info.vip_pay_succ_orderNum,
    order_info.vip_pay_succ_price,
    order_info.vip_pay_succ_perNum,
    order_info.vip_pay_succ_orderNum / session_event.vip_setmeal_page_uv vip_setmeal_conversion_rate,

    session_event.file_buy_page_pv,
    session_event.file_buy_page_uv,
    session_event.file_buy_perAvg_pv,
    session_event.file_pay_click_pv,
    session_event.file_pay_click_uv,

    order_info.file_pay_succ_orderNum,
    order_info.file_pay_succ_price,
    order_info.file_pay_succ_perNum,
    -- 资料购买转化率：资料支付成功订单数/资料购买页uv
    order_info.file_pay_succ_orderNum/ session_event.file_buy_page_uv file_buy_conversion_rate,
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
    '全部' land_url,
    '${date_day}' dt
from(
select
    a.source_mode,
    a.channel_source,
    a.utm_source,
    --落地页pv/uv
    count(case when(a.page_url = a.land_url and a.event_id = 'NE001') then a.page_url else null end) land_url_pv,
    count(distinct(case when (a.page_url = a.land_url and a.visit_id <> '' and a.visit_id is not null and a.event_id = 'NE001') then a.visit_id else null end)) land_url_uv,
    -- 落地页人均pv：落地页pv/落地页uv
    count(case when(a.page_url = a.land_url and a.event_id = 'NE001') then a.page_url else null end) / count(distinct(case when (a.page_url = a.land_url and a.visit_id <> '' and a.visit_id is not null and a.event_id = 'NE001') then a.visit_id else null end)) land_person_avg_pv,
    --立即下载点击
    sum(case when a.event_id='SE003' then 1 else 0 end) down_click_pv,
    count(distinct(case when a.event_id='SE003' then a.visit_id else null end)) down_click_uv,
    --登录框
    sum(case when a.event_id='NE006' and a.module_id_var='login' then 1 else 0 end) login_pv,
    count(distinct(case when a.event_id='NE006' and a.module_id_var='login' then a.visit_id else null end)) login_uv,
    --vip套餐页
    sum(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then 1 else 0 end) vip_setmeal_page_pv,
    count(distinct(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then a.visit_id else null end)) vip_setmeal_page_uv,
    --vip套餐页人均pv：vip套餐页pv/vip套餐页uv
    sum(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then 1 else 0 end) / count(distinct(case when a.event_id='NE006' and a.module_id_var='vipPayCon' then a.visit_id else null end)) vip_setmeal_perAvg_pv,
    -- vip 立即支付点击
    sum(case when a.event_id='SE010' then 1 else 0 end) vip_pay_click_pv,
    count(distinct(case when a.event_id='SE010' then a.visit_id else null end)) vip_pay_click_uv,

    -- 资料购买页pv：NE006，module_id_var=filePayCon
    sum(case when a.event_id='NE006' and a.module_id_var='filePayCon' then 1 else 0 end) file_buy_page_pv,
    count(distinct(case when a.event_id='NE006' and a.module_id_var='filePayCon' then a.visit_id else null end)) file_buy_page_uv,
    -- 资料购买页人均pv：资料购买页pv/资料购买页uv
    sum(case when a.event_id='NE006' and a.module_id_var='filePayCon' then 1 else 0 end) / count(distinct(case when a.event_id='NE006' and a.module_id_var='filePayCon' then a.visit_id else null end)) file_buy_perAvg_pv,
    -- 资料立即支付点击pv：SE008，求和
    sum(case when a.event_id='SE008' then 1 else 0 end) file_pay_click_pv,
    count(distinct(case when a.event_id='SE008' then a.visit_id else null end)) file_pay_click_uv
from(
select
    case when substring(terminal_type,0,1)='0' then 'pc'
    when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
    when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
    when substring(terminal_type,0,1)='2' then '快应用'
    when substring(terminal_type,0,1)='3' then 'android'
    when substring(terminal_type,0,1)='4' then 'ios'
    when substring(terminal_type,0,1)='6' then '今日头条小程序'
    when substring(terminal_type,0,1)='7' then '百度小程序'
    when substring(terminal_type,0,1)='8' then '微信小程序' else null end as source_mode,

    case when site_type='ishare' then '主站' when site_type='office' then '办公' when site_type='edu' then '教育'
    when site_type='archi' then '建筑' when site_type='supperVip' then '超级会员' when site_type='supperContract' then '超级合同'
    when site_type='supperPPT' then '超级PPT' when site_type='tyContract' then '合同通' when site_type='iLawService' then '爱问法律顾问'
    when site_type='loveConteact' then '爱合同' when site_type='tyContract02' then '合同通02'
    when site_type='htzj' then '合同之家' else site_type end channel_source,

    case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end as utm_source,
    event_id,
    module_id_var,
    visit_id,
    page_url,
    land_url
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and (case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end)='360onebox'
and (land_url like '%/f/%' or land_url like '%/c/%' or land_url like '%/node/s/%')
) a
group by a.source_mode, a.channel_source, a.utm_source
) session_event

left join(
select
jump_event.source_mode,
jump_event.channel_source,
count(distinct jump_event.visit_id) visit_id_num
from(
select
    jump.source_mode,
    jump.channel_source,
    jump.utm_source,
    jump.visit_id,
    jump.event_id
from(
select
    case when substring(terminal_type,0,1)='0' then 'pc'
    when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
    when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
    when substring(terminal_type,0,1)='2' then '快应用'
    when substring(terminal_type,0,1)='3' then 'android'
    when substring(terminal_type,0,1)='4' then 'ios'
    when substring(terminal_type,0,1)='6' then '今日头条小程序'
    when substring(terminal_type,0,1)='7' then '百度小程序'
    when substring(terminal_type,0,1)='8' then '微信小程序' else null end as source_mode,

    case when site_type='ishare' then '主站' when site_type='office' then '办公' when site_type='edu' then '教育'
    when site_type='archi' then '建筑' when site_type='supperVip' then '超级会员' when site_type='supperContract' then '超级合同'
    when site_type='supperPPT' then '超级PPT' when site_type='tyContract' then '合同通' when site_type='iLawService' then '爱问法律顾问'
    when site_type='loveConteact' then '爱合同' when site_type='tyContract02' then '合同通02'
    when site_type='htzj' then '合同之家' else site_type end channel_source,

    case when land_url regexp('.*utm_source.*') then substring(split(land_url,'utm_source=')[1],0,case when INSTR(split(land_url,'utm_source=')[1],'&') = 0 then (length(split(land_url,'utm_source=')[1])) else (INSTR(split(land_url,'utm_source=')[1],'&') - 1) end) else null end as utm_source,
    visit_id,
    event_id,
    land_url
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and event_id='NE001'
and (case when page_url regexp('.*utm_source.*') then substring(split(page_url,'utm_source=')[1],0,case when INSTR(split(page_url,'utm_source=')[1],'&') = 0 then (length(split(page_url,'utm_source=')[1])) else (INSTR(split(page_url,'utm_source=')[1],'&') - 1) end) else null end)='360onebox'
and (land_url like '%/f/%' or land_url like '%/c/%' or land_url like '%/node/s/%')
) jump
group by source_mode, channel_source, utm_source, visit_id, event_id, land_url having count(*)=1
) jump_event
group by source_mode, channel_source
) b on session_event.source_mode=b.source_mode
and session_event.channel_source=b.channel_source

left join(
select
channel_source,
source_mode,
utm_source,
sum(vip_pay_succ_orderNum) vip_pay_succ_orderNum,
sum(vip_pay_succ_price) vip_pay_succ_price,
sum(vip_pay_succ_perNum) vip_pay_succ_perNum,
sum(file_pay_succ_orderNum) file_pay_succ_orderNum,
sum(file_pay_succ_price) file_pay_succ_price,
sum(file_pay_succ_perNum) file_pay_succ_perNum
from(
select
    case when channel_source=0 then '办公' when channel_source=4 then '主站' when channel_source=1 then '教育'
    when channel_source=2 then '建筑' when channel_source=5 then '超级合同' when channel_source=6 then '超级PPT'
    when channel_source=7 then '合同通' when channel_source=8 then '爱问法律顾问' else channel_source end channel_source,

    case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' when '101' then '马甲站01' else null end as source_mode,
    utm_source,
    land_url,
    -- vip支付成功订单数：订单表，商品类型为vip，订单状态为成功的订单数
    count(case when goods_type=2 then id else null end) vip_pay_succ_orderNum,
    -- vip支付成功金额：订单表，商品类型为vip，订单状态为成功的金额
    sum(case when goods_type=2 then pay_price/100 else 0 end) vip_pay_succ_price,
    -- vip支付成功人数：订单表，商品类型为vip，订单状态为成功的人数
    count(distinct(case when goods_type=2 then buyer_user_id else null end)) vip_pay_succ_perNum,
    -- 资料支付成功订单数：订单表，商品类型为资料，订单状态为成功的订单数
    count(case when goods_type=1 then id else null end) file_pay_succ_orderNum,
    -- 资料支付成功金额：订单表，商品类型为资料，订单状态为成功的金额
    sum(case when goods_type=1 then pay_price/100 else 0 end) file_pay_succ_price,
    -- 资料支付成功人数：订单表，商品类型为资料，订单状态为成功的人数
    count(distinct(case when goods_type=1 then buyer_user_id else null end)) file_pay_succ_perNum
from dw_fact.dw_fact_ishare_t_order_info_facts
where mth=substr('${date_day}',0,6)
and substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status=2
and utm_source='360onebox'
and (land_url like '%/f/%' or land_url like '%/c/%' or land_url like '%/node/s/%')
group by channel_source, source_mode, utm_source, land_url
) aa
group by aa.channel_source, aa.source_mode, aa.utm_source
) order_info on session_event.source_mode=order_info.source_mode
and session_event.channel_source=order_info.channel_source
and session_event.utm_source=order_info.utm_source

where session_event.source_mode is not null
and session_event.channel_source is not null
and (session_event.utm_source is not null and session_event.utm_source <> '')