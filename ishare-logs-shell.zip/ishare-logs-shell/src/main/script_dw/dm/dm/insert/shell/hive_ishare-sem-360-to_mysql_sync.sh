#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3


echo "导入sem-360-day plan报表数据sh开始"
sh /usr/local/datax/job/baiduSem/ishare_360_sem_sync_day.sh ${date_day} ${end_date}
echo "导入sem-360-day plan报表数据sh结束"


echo "导入sem-360-day 详细报表数据sh开始"
sh /usr/local/datax/job/mysqlTable/result/ishare_sem_360_metric.sh
echo "导入sem-360-day 详细报表数据sh结束"

week_day=`date +%w`
week_day=$(($week_day+0))
echo $week_day
month_day=`date +%d`
month_day=$(($month_day+0))
echo $month_day
if [ $week_day == 1 ]
then
   echo "导入sem-360-day plan报表周报数据sh开始"
   sh /usr/local/datax/job/baiduSem/ishare_360_sem_sync_week.sh
   echo "导入sem-360-day plan报表周报数据sh结束"
fi
if [ $month_day == 1 ]
then
    echo "导入sem-360-day plan报表月报数据sh开始"
      sh /usr/local/datax/job/baiduSem/ishare_360_sem_sync_month.sh
      echo "导入sem-360-day plan报表月报数据sh结束"
fi

