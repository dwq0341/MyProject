insert overwrite table dm_dm.dm_dm_ishare_register_user_keep_day partition(dt='${stat_date_now}')
select
substr(a.create_time,0,8) register_date,                  --注册时间
k.site_type,                                              --终端类型
k.domain,                                                 --站点类型
k.1th_traffic_source,                                     --一级流量来源
k.2th_traffic_source,                                     --二级流量来源
count(distinct a.id) today_num,                           --当天活跃人数
count(distinct b.user_id) one_day_later_num,              --1天后留存数
count(distinct c.user_id) two_day_later_num,              --2天后留存数
count(distinct d.user_id) three_day_later_num,            --3天后留存数
count(distinct e.user_id) four_day_later_num,             --4天后留存数
count(distinct f.user_id) five_day_later_num,             --5天后留存数
count(distinct g.user_id) six_day_later_num,              --6天后留存数.
count(distinct h.user_id) seven_day_later_num,            --7天后留存数
count(distinct i.user_id) fourteen_day_later_num,         --14天后留存数
count(distinct j.user_id) thirty_later_num                --30天后留存数
from dw_dim.dw_dim_ishare_user_info a
  left join (select user_id,max(site_type) site_type,max(domain) domain,max(1th_traffic_source) 1th_traffic_source,max(2th_traffic_source) 2th_traffic_source from dw_fact.dw_fact_ishare_session_info
  where dt = '${stat_date_now}' and user_id is not null and user_id <> '' group by user_id) k on a.id = k.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),1) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) b on a.id= b.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),2) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) c on a.id= c.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),3) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) d on a.id= d.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),4) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) e on a.id= e.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),5) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) f on a.id= f.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),6) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) g on a.id= g.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),7) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) h on a.id= h.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),14) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) i on a.id = i.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),30) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) j on a.id = j.user_id
where substr(a.create_time,0,8) = '${stat_date_now}' group by k.site_type,k.domain,k.1th_traffic_source,k.2th_traffic_source,substr(a.create_time,0,8);