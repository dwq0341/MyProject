#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行spark job to mysql -> ishare_commerce_day 商业化运营日报统计表数据导入 sh开始标志"
sh /usr/local/datax/job/mysqlTable/result/sparkJob/ishare_commerce_day.sh ${date_day} ${end_date}
echo "执行spark job to mysql -> ishare_commerce_day 商业化运营日报统计表数据导入 sh结束标志"