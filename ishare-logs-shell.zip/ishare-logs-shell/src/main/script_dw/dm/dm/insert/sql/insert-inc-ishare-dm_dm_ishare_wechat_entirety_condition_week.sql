set hive.vectorized.execution.enabled = false;
set hive.groupby.skewindata=false;
set hive.execution.engine=mr;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_wechat_entirety_condition_week partition(dt)
--微信整体概况-周报表
select
concat(DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd'),'-',from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${end_date}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-MM-dd'),'yyyyMMdd')) stat_period,   --时间周期
e.terminal_type,                                                                                                        --终端类型
count(case when e.event_id = 'NE001' then e.visit_id else null end) as wechat_pv,                                       --流量pv
count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) wechat_uv,         --流量uv
count(distinct(case when e.event_id = 'NE001' and e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_status_users,   --登录状态用户数
count(distinct(o.buyer_user_id)) buy_succ_num,    --购买成功人数
sum(case when e.event_id='SE033' then o.pay_price else 0 end) sales,    --订单成功金额
(sum(o.pay_price)/count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end))) * 1000  kilo_uv,  --千UV价值:(销售额/uv)* 1000
count(distinct(case when e.event_id='SE001' and e.login_result = '1' then e.visit_id else null end)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) visit_login_rate,  --访客登录率
count(distinct(o.buyer_user_id)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) visit_buy_transform,    --访客购买转化
count(distinct(o.buyer_user_id)) / count(distinct(case when e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_user_buy_transform,   --登录用户购买转化
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
concat(DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd'),'-',from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${end_date}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-MM-dd'),'yyyyMMdd')) dt
from(
select
    user_id,
    event_id,
    visit_id,
    get_json_object(var,'$.orderID') order_id,
    get_json_object(var,'$.source') source,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type='1' and browser='微信' then 'M端-微信浏览器'
    when terminal_type='8-1' then '微信小程序_爱问办公模板'
    when terminal_type='8-2' then '微信小程序_爱问文件管理'
    when terminal_type='8-3' then '微信小程序_爱问模板'
    when terminal_type='8-4' then '微信小程序_爱问福利社' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt >= DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd')
and dt < DATE_FORMAT(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyyMMdd')
) e

left join(
select
id,
buyer_user_id,
order_status,
goods_type,
pay_price
from(
select
id,
buyer_user_id,
order_status,
goods_type,
pay_price/100 pay_price
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) >= DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyy-MM-dd')
and substr(order_time,0,10) < DATE_FORMAT(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyy-MM-dd')
and order_status=2
--and goods_type in ('1','2','4','8','12','13')
) a
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on a.goods_type=g.goods_types
where g.goods_types is not null
) o on e.order_id=o.id
where e.terminal_type is not null
group by e.terminal_type

--小程序全部
union all
select
concat(DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd'),'-',from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${end_date}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-MM-dd'),'yyyyMMdd')) stat_period,     --时间周期
e.terminal_type,                                                                                                        --终端类型
count(case when e.event_id = 'NE001' then e.visit_id else null end) as wechat_pv,                                       --流量pv
count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) wechat_uv,         --流量uv
count(distinct(case when e.event_id = 'NE001' and e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_status_users,   --登录状态用户数
count(distinct(o.buyer_user_id)) buy_succ_num,                          --购买成功人数
sum(case when e.event_id='SE033' then o.pay_price else 0 end) sales,    --订单成功金额
(sum(o.pay_price)/count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end))) * 1000  kilo_uv,  --千UV价值:(销售额/uv)* 1000
count(distinct(case when e.event_id='SE001' and e.login_result = '1' then e.visit_id else null end)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) visit_login_rate,  --访客登录率
count(distinct(o.buyer_user_id)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) visit_buy_transform,    --访客购买转化
count(distinct(o.buyer_user_id)) / count(distinct(case when e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_user_buy_transform,   --登录用户购买转化
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
concat(DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd'),'-',from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${end_date}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-MM-dd'),'yyyyMMdd')) dt
from(
select
    user_id,
    event_id,
    visit_id,
    get_json_object(var,'$.orderID') order_id,
    get_json_object(var,'$.source') source,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type like '%8%' then '小程序-全部' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt >= DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd')
and dt < DATE_FORMAT(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyyMMdd')
) e

left join(
select
id,
buyer_user_id,
order_status,
goods_type,
pay_price
from(
select
id,
buyer_user_id,
order_status,
goods_type,
pay_price/100 pay_price
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) >= DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyy-MM-dd')
and substr(order_time,0,10) < DATE_FORMAT(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyy-MM-dd')
and order_status=2
--and goods_type in ('1','2','4','8','12','13')
) a
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on a.goods_type=g.goods_types
where g.goods_types is not null
) o on e.order_id=o.id
where e.terminal_type is not null
group by e.terminal_type

--全部
union all
select
concat(DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd'),'-',from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${end_date}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-MM-dd'),'yyyyMMdd')) stat_period,     --时间周期
e.terminal_type,                                                                                                        --终端类型
count(case when e.event_id = 'NE001' then e.visit_id else null end) as wechat_pv,                                       --流量pv
count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) wechat_uv,         --流量uv
count(distinct(case when e.event_id = 'NE001' and e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_status_users,   --登录状态用户数
count(distinct(o.buyer_user_id)) buy_succ_num,    --购买成功人数
sum(case when e.event_id='SE033' then o.pay_price else 0 end) sales,    --订单成功金额
(sum(o.pay_price)/count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end))) * 1000  kilo_uv,  --千UV价值:(销售额/uv)* 1000
count(distinct(case when e.event_id='SE001' and e.login_result = '1' then e.visit_id else null end)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) visit_login_rate,  --访客登录率
count(distinct(o.buyer_user_id)) / count(distinct(case when (e.visit_id <> '' and e.event_id = 'NE001') then e.visit_id else null end)) visit_buy_transform,    --访客购买转化
count(distinct(o.buyer_user_id)) / count(distinct(case when e.user_id <> '' and e.user_id is not null then e.user_id else null end)) login_user_buy_transform,   --登录用户购买转化
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
concat(DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd'),'-',from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('${end_date}','yyyyMMdd'),'yyyy-MM-dd'),1),'yyyy-MM-dd'),'yyyyMMdd')) dt
from(
select
    user_id,
    event_id,
    visit_id,
    get_json_object(var,'$.orderID') order_id,
    get_json_object(var,'$.source') source,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type like '%8%' or (terminal_type='1' and browser='微信') then '全部' else null end terminal_type
from dw_fact.dw_fact_ishare_session_event
where dt >= DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyyMMdd')
and dt < DATE_FORMAT(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyyMMdd')
) e

left join(
select
id,
buyer_user_id,
order_status,
goods_type,
pay_price
from(
select
id,
buyer_user_id,
order_status,
goods_type,
pay_price/100 pay_price
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) >= DATE_FORMAT(DATE_SUB(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'), 7),'yyyy-MM-dd')
and substr(order_time,0,10) < DATE_FORMAT(from_unixtime(unix_timestamp('${end_date}', 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyy-MM-dd')
and order_status=2
--and goods_type in ('1','2','4','8','12','13')
) a
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on a.goods_type=g.goods_types
where g.goods_types is not null
) o on e.order_id=o.id
where e.terminal_type is not null
group by e.terminal_type