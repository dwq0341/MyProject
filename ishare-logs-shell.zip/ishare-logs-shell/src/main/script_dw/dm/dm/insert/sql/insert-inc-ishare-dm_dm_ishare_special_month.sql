set hive.groupby.skewindata=false;
set hive.optimize.skewjoin=true;
set hive.auto.convert.join=true;
set hive.exec.reducers.bytes.per.reducer=200000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_special_month partition(dt)
select
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') stat_period,
    aa.topic_name,
    bb.special_file_cnt,
    aa.special_pv,
    aa.special_uv,
    aa.special_file_click_pv,
    aa.special_file_click_uv,
    aa.special_file_click_rate,
    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time, --更新时间
    from_unixtime(unix_timestamp('${date_day}', 'yyyyMMdd'), 'yyyyMM') dt
from(
select
    --专题名称
    b.topic_name,
    --专题页pv
    count(case when b.id is not null and a.event_id='NE030' and a.pageID='TP' then a.visit_id else null end) special_pv,
    --专题页uv
    count(distinct(case when b.id is not null and a.event_id='NE030' and a.pageID='TP' then a.visit_id else null end)) special_uv,
    --专题页资料点击pv
    count(case when a.event_id='SE040' and a.ztID is not null and b.id is not null then a.visit_id else null end) special_file_click_pv,
    --专题页资料点击uv
    count(distinct(case when a.event_id='SE040' and a.ztID is not null and b.id is not null then a.visit_id else null end)) special_file_click_uv,
    --专题页资料点击率: 专题资料点击uv/专题页uv
    count(distinct(case when a.event_id='SE040' and a.ztID is not null and b.id is not null then a.visit_id else null end)) / count(distinct(case when b.id is not null and a.event_id='NE030' and a.pageID='TP' then a.visit_id else null end)) special_file_click_rate
from(
select
    session_id,
    event_id,
    visit_id,
    get_json_object(var,'$.pageID') pageID,
    case when event_id='SE040' then get_json_object(var,'$.ztID')
    when event_id='NE030' and get_json_object(var,'$.pageID')='TP' then get_url(page_url) else page_url end ztID
from ods_ods.ods_ods_ishare_log
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) a

left join(
select
    id,
    topic_name
from dw_fact.dw_fact_ishare_tb_special_topic_info
) b on a.ztID=b.id

where a.ztID is not null
and a.ztID <> ''
and b.id is not null
group by b.topic_name
) aa


--专题数量
left join(
select
    b.topic_name,
    count(distinct(case when a.ztID is not null and b.id is not null and c.special_topic_id is not null then c.content_id else null end)) special_file_cnt  --专题资料数量
from(
select
ztID
from(
select
    case when event_id='SE040' then get_json_object(var,'$.ztID')
    when event_id='NE030' and get_json_object(var,'$.pageID')='TP' then get_url(page_url) else page_url end ztID
from ods_ods.ods_ods_ishare_log
where dt < from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,0),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
and dt >= from_unixtime(unix_timestamp(trunc(add_months(CURRENT_TIMESTAMP,-1),'MM'),'yyyy-MM-dd'),'yyyyMMdd')
) log
group by ztID
) a

left join(
select
    id,
    topic_name
from dw_fact.dw_fact_ishare_tb_special_topic_info
) b on a.ztID=b.id

left join(
select
    special_topic_id,
    content_id
from dw_fact.dw_fact_ishare_tb_special_topic_content
) c on b.id = c.special_topic_id
where a.ztID is not null
and a.ztID <> ''
and b.id is not null
group by b.topic_name
) bb
on aa.topic_name=bb.topic_name