#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行ishare_platform_sem_plan_metric_day SEM渠道投放收益(baidu、360、sogou)数据导入sh开始"
sh /usr/local/datax/job/baiduSem/ishare_platform_sem_sync_day.sh ${date_day}
echo "执行ishare_platform_sem_plan_metric_day SEM渠道投放收益(baidu、360、sogou)数据导入sh结束标志"