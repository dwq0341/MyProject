#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行ishare_baidu_sem_sync_month 百度sem统计表数据导入 sh"
sh /usr/local/datax/job/baiduSem/ishare_baidu_sem_sync_month.sh
echo "执行ishare_baidu_sem_sync_month 百度sem统计数据导入sh结束标志"