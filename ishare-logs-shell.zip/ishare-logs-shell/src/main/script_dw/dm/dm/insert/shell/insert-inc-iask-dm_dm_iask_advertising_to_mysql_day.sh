#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "insert-inc-iask-dm_dm_iask_advertising_to_mysql_day 渠道转化报表 数据导入 sh开始标志"
sh /usr/local/datax/job/mysqlTable/result/ishare_advertising_sync_day.sh ${date_day} ${end_date}
echo "insert-inc-iask-dm_dm_iask_advertising_to_mysql_day 渠道转化报表 数据导入 sh结束标志"