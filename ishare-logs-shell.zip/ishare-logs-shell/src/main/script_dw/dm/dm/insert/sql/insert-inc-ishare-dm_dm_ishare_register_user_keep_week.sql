insert overwrite table dm_dm.dm_dm_ishare_register_user_keep_week partition(dt='${stat_date_now}')
select
substr(a.create_time,0,8) register_date,	                 --注册时间
k.site_type,                                                 --终端类型
k.domain,                                                    --站点类型
k.1th_traffic_source,                                        --一级流量来源
k.2th_traffic_source,                                        --二级流量来源
count(distinct a.id) today_num,                              --当天注册人数
count(distinct b.user_id) one_week_later_num,                --1周后留存数
count(distinct c.user_id) two_week_later_num,                --2周后留存数
count(distinct d.user_id) three_week_later_num,              --3周后留存数
count(distinct e.user_id) four_week_later_num,               --4周后留存数
count(distinct f.user_id) five_week_later_num,               --5周后留存数
count(distinct g.user_id) six_week_later_num,                --6周后留存数
count(distinct h.user_id) seven_week_later_num               --7周后留存数
from dw_dim.dw_dim_ishare_user_info a
left join (select user_id,max(site_type) site_type,max(domain) domain,max(1th_traffic_source) 1th_traffic_source,max(2th_traffic_source) 2th_traffic_source from dw_fact.dw_fact_ishare_session_info
where dt = '${stat_date_now}' and user_id is not null and user_id <> '' group by user_id) k on a.id = k.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),7) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),14) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) b on a.id = b.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),14) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),21) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) c on a.id = c.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),21) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),28) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) d on a.id = d.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),28) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),35) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) e on a.id = e.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),35) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),42) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) f on a.id = f.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),42) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),49) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) g on a.id = g.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt >= from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),49) ,'yyyy-MM-dd'),'yyyyMMdd') and dt < from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),56) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) h on a.id = h.user_id
where substr(a.create_time,0,8) = '${stat_date_now}' group by k.site_type,k.domain,k.1th_traffic_source,k.2th_traffic_source,substr(a.create_time,0,8);
