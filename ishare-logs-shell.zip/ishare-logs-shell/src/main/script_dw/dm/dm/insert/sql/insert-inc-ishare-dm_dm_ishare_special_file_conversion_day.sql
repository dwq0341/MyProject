--show functions;
--drop function default.get_url;
--CREATE FUNCTION default.get_url AS 'com.ishare.ParseUrl' USING JAR 'hdfs://bj-wlj-namenode01-172-38-1-194:8020/user/hive/udf/hiveUdf_two-1.0.jar';
--show functions;
set hive.exec.reducers.bytes.per.reducer=1000000000;
set mapred.max.split.size=1024000000;
set mapred.min.split.size=256000000;
set mapred.min.split.size.per.node=256000000;
set mapred.min.split.size.per.rack=256000000;
set hive.groupby.skewindata=false;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_special_file_conversion_day partition(dt)
select
'${date_day}' stat_period,   --时间周期
aaa.topic_name,             --专题名称
aaa.format,                 --资料格式
aaa.third_name,             --资料三级分类名
aaa.product_type,           --资料商品类型
--专题资料uv
count(distinct(case when aaa.event_id='SE002' and aaa.topic_info_id is not null then aaa.visit_id else null end)) special_file_uv,
-- 专题资料跳出率
count(distinct aaa.v_visit_id) / count(distinct(case when aaa.event_id='SE002' and aaa.topic_info_id is not null then aaa.visit_id else null end)) file_jump_rate,
-- 专题资料立即下载按钮点击pv
count(case when aaa.event_id='SE003' and aaa.topic_info_id is not null then aaa.visit_id else null end) special_file_down_pv,
--专题资料立即下载按钮点击uv
count(distinct(case when aaa.event_id='SE003' and aaa.topic_info_id is not null then aaa.visit_id else null end)) special_file_down_uv,
-- 专题资料下载率:专题资料立即下载按钮点击uv/专题资料uv
count(distinct(case when aaa.event_id='SE003' and aaa.topic_info_id is not null then aaa.visit_id else null end)) / count(distinct(case when aaa.topic_info_id is not null then aaa.visit_id else null end)) special_file_down_rate,
--专题资料购买成功金额
sum(case when aaa.session_id is not null and aaa.topic_info_id is not null and aaa.order_id is not null and aaa.order_info_id is not null and aaa.goods_id is not null then aaa.pay_price else 0 end) special_file_buy_money,
--专题资料购买成功人数
count(distinct(case when aaa.session_id is not null and aaa.topic_info_id is not null and aaa.order_id is not null and aaa.order_info_id is not null and aaa.goods_id is not null then aaa.buyer_user_id else null end)) special_file_buy_succ_person,
--专题资料购买率: 专题资料购买成功人数/专题资料uv
count(distinct(case when aaa.session_id is not null and aaa.topic_info_id is not null and aaa.order_id is not null and aaa.order_info_id is not null and aaa.goods_id is not null then aaa.buyer_user_id else null end)) / count(distinct(case when aaa.event_id='SE002' and aaa.topic_info_id is not null then aaa.visit_id else null end)) special_file_buy_rate,
--更新时间
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
--分区字段
'${date_day}' dt
from(
select
a.event_id,
a.visit_id,
a_one.order_id,
a_one.session_id,
a.ztID,
a.num,
c.topic_info_id,
c.topic_name,
b.format,
b.third_name,
b.product_type,
d.order_info_id,
d.goods_id,
d.pay_price,
d.buyer_user_id,
v.visit_id v_visit_id
from(
select
    event_id,
    visit_id,
    session_id,
    get_json_object(var,'$.fileID') fileID,
    case when pre_page_url like '%/s/%' then get_url(pre_page_url) else pre_page_url end ztID,
    row_number() over(partition by session_id,get_json_object(var,'$.fileID') order by nginx_date) num
from ods_ods.ods_ods_ishare_log
where dt='${date_day}'
and (event_id='SE002' or event_id='SE003')
) a

left join(
select
    session_id,
    get_json_object(var,'$.orderID') order_id
from ods_ods.ods_ods_ishare_log
where dt='${date_day}'
and event_id = 'SE033'
) a_one on a.session_id=a_one.session_id

left join(
select
    id,
    format,
    third_name,
    product_type
from dw_dim.dw_dim_ishare_file_info_dimension
) b on a.fileID=b.id

--专题表
left join(
select
    distinct
    id topic_info_id,
    topic_name
from dw_fact.dw_fact_ishare_tb_special_topic_info
) c on a.ztID=c.topic_info_id

left join(
select
    id order_info_id,
    goods_id,
    buyer_user_id,
    pay_price/100 pay_price
from dw_fact.dw_fact_ishare_t_order_info
where order_status=2
and goods_type=1
and substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) d on a_one.order_id=d.order_info_id
and a.fileID=d.goods_id

--跳出率
left join(
select
    a.visit_id,
    a.event_id,
    a.file_id
from(
select
    visit_id,
    event_id,
    file_id,
    ztID,
    session_event
from(
select
    visit_id,
    event_id,
    nginx_date,
    get_json_object(var,'$.fileID') file_id,
    case when event_id='SE002' and pre_page_url like '%/s/%' then get_url(pre_page_url) else pre_page_url end ztID,
    row_number() over(partition by session_id order by nginx_date desc, event_id asc) session_event
from ods_ods.ods_ods_ishare_log
where dt='${date_day}'
) log
where log.event_id='SE002'
and log.session_event=1
and log.ztID is not null
and log.ztID <> ''
) a
left join(
select
    id,
    topic_name
from dw_fact.dw_fact_ishare_tb_special_topic_info
) b on a.ztID=b.id
where b.id is not null
) v on a.fileID=v.file_id
) aaa
where aaa.ztID is not null
and aaa.ztID <> ''
and aaa.num=1
and aaa.topic_info_id is not null
and aaa.third_name is not null
and aaa.product_type is not null
and aaa.format is not null
group by
aaa.topic_name,
aaa.format,
aaa.third_name,
aaa.product_type