set hive.execution.engine=mr;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_website_search_keyword_day partition(dt)
select
'${date_day}' stat_period,
terminal_type,
site_type_var,
key_words,
count(key_words) num,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from dw_fact.dw_fact_ishare_log_events
where dt='${date_day}'
and event_id='SE016' and terminal_type in('0','1','3','4')
and site_type_var in('ishare','iLawService','office','supperContract','tyContract')
and (key_words is not null and key_words <> '')
group by terminal_type, site_type_var, key_words
order by num desc