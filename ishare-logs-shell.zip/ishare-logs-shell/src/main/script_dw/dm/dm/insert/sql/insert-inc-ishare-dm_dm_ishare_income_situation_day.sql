set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_income_situation_day partition(dt)
--收入概况报表
select
'${date_day}' stat_period,
a.channel_source,
a.source_mode,
--总uv
coalesce(c.uv, 0) total_uv,
--跳出率: 每次会话只访问一个页面即离开的次数/总的访问次数
coalesce(b.session_id_num/c.session_uv, 0) jump_rate,
--总收入
a.total_price,
--支付成功订单数
a.pay_succ_order_num,
-- 支付成功人数
a.pay_succ_user_num,
--购买转化率: 支付成功人数/总UV
coalesce(a.pay_succ_user_num/c.uv, 0) buy_transf_rate,
--客单价: 总收入/支付成功人数
coalesce(round(a.total_price/a.pay_succ_user_num, 2), 0) guest_unit_price,
--千uv: 总收入/总uv * 1000
coalesce(a.total_price/c.uv * 1000, 0) transf_price_kuser,
--复购人数
coalesce(old_order.after_purchase_person_num, 0) after_purchase_person_num,
--复购率: 以往下过单且当天购买成功人数/当天购买成功人数
coalesce(old_order.after_purchase_person_num / a.pay_succ_user_num, 0) after_purchase_rate,
--退款成功订单数
a.refund_succ_order_num,
--退款成功金额
a.refund_succ_price,
--退款率
coalesce(a.refund_succ_order_num/a.pay_succ_order_num, 0) refund_rate,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
    channel_source,
    source_mode,
    --总收入
    sum(case when order_status=2 and goods_type in ('1','2','4','8','12','13','14') then pay_price else 0 end) total_price,
    --支付成功订单数
    count(case when order_status=2 and goods_type in ('1','2','4','8','12','13','14') then id else null end) pay_succ_order_num,
    --支付成功人数
    count(distinct (case when order_status=2 and goods_type in ('1','2','4','8','12','13','14') then buyer_user_id else null end)) pay_succ_user_num,
    --退款成功订单数
    count(case when order_status in (8,10) then id else null end) refund_succ_order_num,
    -- 退款成功金额
    sum(case when order_status in (8,10) then pay_price else 0 end) refund_succ_price
from(
select
case when channel_source=0 then '办公' when channel_source=4 then '主站' when channel_source=1 then '教育'
when channel_source=2 then '建筑' when channel_source=5 then '超级合同' when channel_source=6 then '超级PPT'
when channel_source=7 then '合同通' when channel_source=8 then '爱问法律顾问' when channel_source=9 then '合同之家' else channel_source end channel_source,

case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' else '' end as source_mode,
order_status,
goods_type,
pay_price/100 pay_price,
buyer_user_id,
id
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) b
where (b.channel_source is not null and b.channel_source <> '')
and (b.source_mode <> '' and b.source_mode is not null)
group by
b.channel_source,
b.source_mode
) a

--跳出率
left join(
select
terminal_type,
site_type_var,
count(distinct session_id) session_id_num
from(
select
    session_id,
    event_id,
    page_url,
    terminal_type,
    site_type_var,
    count(distinct page_url) jump_page_url
from(
select
    session_id,
    event_id,
    page_url,
    case when substring(terminal_type,0,1)='0' then 'pc'
    when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
    when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
    when substring(terminal_type,0,1)='2' then '快应用'
    when substring(terminal_type,0,1)='3' then 'android'
    when substring(terminal_type,0,1)='4' then 'ios'
    when substring(terminal_type,0,1)='6' then '今日头条小程序'
    when substring(terminal_type,0,1)='7' then '百度小程序'
    when substring(terminal_type,0,1)='8' then '微信小程序' else '' end as terminal_type,

    case when site_type_var='ishare' then '主站' when site_type_var='office' then '办公' when site_type_var='edu' then '教育'
    when site_type_var='archi' then '建筑' when site_type_var='supperVip' then '超级会员' when site_type_var='supperContract' then '超级合同'
    when site_type_var='supperPPT' then '超级PPT' when site_type_var='tyContract' then '合同通' when site_type_var='iLawService' then '爱问法律顾问'
    when site_type_var='loveConteact' then '爱合同' when site_type_var='tyContract02' then '合同通02'
    when site_type_var='htzj' then '合同之家' else site_type_var end site_type_var
from dw_fact.dw_fact_ishare_log_event_ne001
where dt='${date_day}'
and (session_id is not null and session_id <> '')
) aa
where aa.terminal_type <> ''
and (site_type_var is not null and site_type_var <> '')
group by session_id,event_id,page_url,terminal_type,site_type_var having count(distinct page_url)=1
) jump
group by terminal_type, site_type_var
) b on a.channel_source=b.site_type_var and a.source_mode=b.terminal_type

-- 复购人数:以往下过单且当天购买成功人数
left join(
select
    count(distinct(bb.buyer_user_id)) after_purchase_person_num,
    aa.channel_source,
    aa.source_mode
from(
select
    distinct
    buyer_user_id,
    case when channel_source=0 then '办公' when channel_source=4 then '主站' when channel_source=1 then '教育'
    when channel_source=2 then '建筑' when channel_source=5 then '超级合同' when channel_source=6 then '超级PPT'
    when channel_source=7 then '合同通' when channel_source=8 then '爱问法律顾问' when channel_source=9 then '合同之家' else channel_source end channel_source,

    case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' else '' end as source_mode
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status=2
and goods_type in ('1','2','4','8','12','13','14')
) aa
left join(
select
buyer_user_id,
channel_source,
source_mode
from(
select
    buyer_user_id,
    case when channel_source=0 then '办公' when channel_source=4 then '主站' when channel_source=1 then '教育'
    when channel_source=2 then '建筑' when channel_source=5 then '超级合同' when channel_source=6 then '超级PPT'
    when channel_source=7 then '合同通' when channel_source=8 then '爱问法律顾问' when channel_source=9 then '合同之家' else channel_source end channel_source,

    case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' else '' end as source_mode,
    row_number() over (partition by source_mode, channel_source, buyer_user_id) num
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) < from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_status=2
and goods_type in ('1','2','4','8','12','13','14')
and (buyer_user_id <> '' and buyer_user_id is not null)
) sort
where sort.num > 1
and (channel_source is not null and channel_source <> '')
) bb on aa.buyer_user_id=bb.buyer_user_id
and aa.channel_source=bb.channel_source
and aa.source_mode=bb.source_mode
where (bb.buyer_user_id is not null and bb.buyer_user_id <> '')
group by aa.channel_source, aa.source_mode
) old_order on a.channel_source=old_order.channel_source
and a.source_mode=old_order.source_mode

left join(
select
    --总uv
    count(distinct aaa.visit_id) uv,
    --总访问次数
    count(distinct aaa.session_id) session_uv,
    aaa.source_mode,
    aaa.channel_source
from(
select
visit_id,
session_id,
case when substring(terminal_type,0,1)='0' then 'pc'
when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
when substring(terminal_type,0,1)='2' then '快应用'
when substring(terminal_type,0,1)='3' then 'android'
when substring(terminal_type,0,1)='4' then 'ios'
when substring(terminal_type,0,1)='6' then '今日头条小程序'
when substring(terminal_type,0,1)='7' then '百度小程序'
when substring(terminal_type,0,1)='8' then '微信小程序' else '' end as source_mode,

case when site_type_var='ishare' then '主站' when site_type_var='office' then '办公' when site_type_var='edu' then '教育'
when site_type_var='archi' then '建筑' when site_type_var='supperVip' then '超级会员' when site_type_var='supperContract' then '超级合同'
when site_type_var='supperPPT' then '超级PPT' when site_type_var='tyContract' then '合同通' when site_type_var='iLawService' then '爱问法律顾问'
when site_type_var='loveConteact' then '爱合同' when site_type_var='tyContract02' then '合同通02'
when site_type_var='htzj' then '合同之家' else site_type_var end channel_source
from dw_fact.dw_fact_ishare_log_event_ne001
where dt='${date_day}'
) aaa
where (aaa.source_mode is not null and aaa.source_mode <> '')
and (aaa.channel_source is not null and aaa.channel_source <> '')
group by aaa.source_mode, aaa.channel_source
) c on a.source_mode = c.source_mode and a.channel_source=c.channel_source
