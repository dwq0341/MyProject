set hive.vectorized.execution.enabled = false;
set hive.groupby.skewindata=false;
set hive.execution.engine=mr;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_path_analysis_day partition(dt)
select
    '${date_day}' stat_period,                          --时间周期
    d.terminal_type,                                    --终端类型
    count(d.detail_event_id) detail_page_pv,            --资料详情页pv
    count(distinct d.detail_visit_id) detail_page_uv,   --资料详情页uv
    count(distinct(case when d.sale_type='1' then d.detail_visit_id else null end)) free_file_uv,   --免费资料uv
    count(distinct(case when d.sale_type='4' then d.detail_visit_id else null end)) vip_file_uv,    --vip特权资料uv
    count(distinct(case when d.sale_type='5' then d.detail_visit_id else null end)) pay_file_uv,    --付费资料uv
    count(distinct(case when d.sale_type='3' then d.detail_visit_id else null end)) online_file_uv, --在线资料uv

    count(distinct(case when d.sale_type='1' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) free_file_rate,    --免费资料uv占比: 免费资料uv/详情页uv
    count(distinct(case when d.sale_type='4' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) vip_file_rate,     --VIP特权资料uv占比: VIP特权资料uv/详情页uv
    count(distinct(case when d.sale_type='5' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) pay_file_rate,     --付费资料uv占比: 付费资料uv/详情页uv
    count(distinct(case when d.sale_type='3' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) online_finle_rate, --在线资料uv占比: 在线资料uv/详情页uv

    count(case when d.event_id = 'SE035' then d.visit_id else null end) as below_button_pv,              --下方立即下载按钮pv
    count(distinct(case when d.event_id = 'SE035' then d.visit_id else null end)) as below_button_uv,    --下方立即下载按钮uv
    count(distinct(case when d.event_id = 'SE035' then d.visit_id else null end)) / count(distinct d.detail_visit_id) below_button_rate,   -- 下方下载按钮点击率: UV/详情页UV

    count(case when d.event_id = 'SE003' then d.visit_id else null end) as right_button_pv,              -- 右下角立即下载按钮pv
    count(distinct(case when d.event_id = 'SE003' then d.visit_id else null end)) as right_button_uv,    -- 右下角立即下载按钮uv
    count(distinct(case when d.event_id = 'SE003' then d.visit_id else null end)) / count(distinct d.detail_visit_id) right_button_rate,   -- 右下角按钮点击率: UV/详情页UV

    count(case when d.module_id_var='login' and d.events_id='NE006' then d.events_visit_id else null end) as login_show_pv,             --登录页展示pv,
    count(distinct(case when d.module_id_var='login' and d.events_id='NE006' then d.events_visit_id else null end)) as login_show_uv,   --登录页展示uv
    count(distinct(case when d.module_id_var='login' and d.events_id='NE006' then d.events_visit_id else null end)) / count(distinct d.detail_visit_id) login_show_rate,   --登录页展示率:UV/详情页UV

    count(case when d.event_id='NE001' and d.user_id is not null and d.user_id != '' then d.user_id else null end) as login_status_pv,           --登录状态用户pv
    count(distinct(case when d.event_id='NE001' and d.user_id is not null and d.user_id != '' then d.user_id else null end)) as login_status_uv, --登录状态用户uv
    count(distinct(case when d.event_id='NE001' and d.user_id is not null and d.user_id != '' then d.user_id else null end)) / count(distinct d.detail_visit_id) login_status_rate,   --登录状态用户占比

    count(case when d.event_id='SE001' and d.login_result='1' then d.visit_id else null end) login_succ_pv,            --登录成功pv
    count(distinct(case when d.event_id='SE001' and d.login_result='1' then d.visit_id else null end)) login_succ_uv,  --登录成功uv
    count(distinct(case when d.event_id='SE001' and d.login_result='1' then d.visit_id else null end)) / count(distinct d.detail_visit_id) login_succ_rate,    --登录成功率: UV/详情页UV

    count(case when d.events_id='NE006' and d.module_id_var='vipPayCon' then 1 else null end) vip_buy_page_pv,                             --vip购买页pv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='vipPayCon' then d.events_visit_id else null end)) vip_buy_page_uv,   --vip购买页uv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='vipPayCon' then d.events_visit_id else null end)) / count(distinct d.detail_visit_id) vip_buy_page_rate,   --vip购买页面到达率: uv/详情页uv

    count(case when d.event_id='SE010' then 1 else null end) vip_buy_page_button_pv,                        --vip购买页立即支付按钮pv
    count(distinct(case when d.event_id='SE010' then d.visit_id else null end)) vip_buy_page_button_uv,     --vip购买页立即支付按钮uv
    count(distinct(case when d.event_id='SE010' then d.visit_id else null end)) / count(distinct(case when d.event_id='NE006' and d.module_id_var='vipPayCon' then d.visit_id else null end)) vip_buy_page_button_rate,  -- vip购买页支付按钮点击率:UV/vip购买页uv

    count(case when d.events_id='NE006' and d.module_id_var='filePayCon' then 1 else null end) pay_file_buy_page_pv,                                --付费资料购买页pv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='filePayCon' then d.events_visit_id else null end)) pay_file_buy_page_uv,      --付费资料购买页uv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='filePayCon' then d.events_visit_id else null end)) / count(distinct d.detail_visit_id) pay_file_buy_page_rate,  --付费资料购买页面达到率: uv/详情页uv

    count(case when d.event_id='SE008' then 1 else null end) pay_file_buy_button_pv,                      --付费资料立即支付按钮pv
    count(distinct(case when d.event_id='SE008' then d.visit_id else null end)) pay_file_buy_button_uv,   --付费资料立即支付按钮uv
    count(distinct(case when d.event_id='SE008' then d.visit_id else null end)) / count(distinct(case when d.event_id='NE006' and d.module_id_var='filePayCon' then d.visit_id else null end)) pay_file_buy_button_rate,  --付费资料支付按钮点击率: uv/付费资料购买页uv

    count(case when d.goods_type=2 then d.id else null end) vip_order_generate_pv,                        --vip订单生成pv
    count(distinct(case when d.goods_type=2 then d.buyer_user_id else null end)) vip_order_generate_uv,   --vip订单生成uv
    count(distinct(case when d.goods_type=2 then d.buyer_user_id else null end)) / count(case when d.event_id='SE010' then d.visit_id else null end) vip_order_generate_rate,   --vip订单生成率: uv/VIP购买页立即支付按钮uv

    count(case when d.goods_type=1 then d.id else null end) pay_file_order_generate_pv,                         --付费资料订单生成pv
    count(distinct(case when d.goods_type=1 then d.buyer_user_id else null end)) pay_file_order_generate_uv,    --付费资料订单生成uv
    count(distinct(case when d.goods_type=1 then d.buyer_user_id else null end)) / count(distinct(case when d.event_id='SE008' then d.visit_id else null end)) pay_file_order_generate_rate,   --付费资料订单生成率: uv/付费资料立即支付按钮uv

    count(case when d.goods_type=2 and d.order_status=2 then d.id else null end) vip_pay_succ_pv,                        --vip支付成功pv
    count(distinct(case when d.goods_type=2 and d.order_status=2 then d.buyer_user_id else null end)) vip_pay_succ_uv,   --vip支付成功uv
    count(distinct(case when d.goods_type=2 and d.order_status=2 then d.buyer_user_id else null end)) / count(distinct(case when d.goods_type=2 then d.buyer_user_id else null end)) vip_pay_succ_rate,   --vip支付成功率:uv/vip订单生成uv

    count(case when d.goods_type=1 and d.order_status=2 then d.id else null end) pay_file_succ_pv,                        --付费资料支付成功pv
    count(distinct(case when d.goods_type=1 and d.order_status=2 then d.buyer_user_id else null end)) pay_file_succ_uv,   --付费资料支付成功uv
    count(distinct(case when d.goods_type=1 and d.order_status=2 then d.buyer_user_id else null end)) / count(distinct(case when d.goods_type=1 then d.buyer_user_id else null end)) pay_file_succ_rate,  --付费资料支付成功率:uv/付费资料订单生成uv

    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
    '${date_day}' dt
from(
select
    a.event_id detail_event_id,
    a.visit_id detail_visit_id,
    a.sale_type,
    a.uuid a_uuid,
    b.id,
    b.goods_type,
    b.order_status,
    b.buyer_user_id,
    dim.uuid,
    dim.event_id,
    dim.visit_id,
    dim.user_id,
    dim.page_id,
    dim.login_result,
    dim.terminal_type,
	events.module_id_var,
	events.event_id events_id,
	events.visit_id events_visit_id
from(
select
    -- 登录页展示/登录状态用户
    uuid,
    event_id,
    visit_id,
    user_id,
    page_id,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type = '0' and site_type='ishare' then 'PC-主站'
    when terminal_type = '1' and browser not like '%微信%' then 'M-剔除微信环境'
    when terminal_type = '1' and browser like '%微信%' then 'M-微信浏览器'
    when terminal_type = '7' then '百度小程序'
    when terminal_type = '2' then '快应用'
    when terminal_type = '3' or terminal_type = '4' then 'APP' else null end terminal_type
from ods_ods.ods_ods_ishare_log
where dt='${date_day}'
) dim

left join(
--资料详情页 / 资料类型uv模块
select
    uuid,
    event_id,
    visit_id,
    sale_type
from dw_fact.dw_fact_ishare_log_event_se002
where dt='${date_day}'
) a on dim.uuid=a.uuid

--NE006事件,在这张表取解析好的module_id_var
left join(
select
uuid,
event_id,
visit_id,
module_id_var
from dw_fact.dw_fact_ishare_log_events
where dt='${date_day}'
) events on dim.uuid=events.uuid

--vip订单生成/付费资料订单生成/vip支付成功/vip支付成功/付费资料支付成功
left join(
select
uuid,
id,
goods_type,
order_status,
buyer_user_id
from dw_fact.dw_fact_ishare_t_order_info_facts
where substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) b on dim.uuid=b.uuid
) d
where d.terminal_type is not null
group by d.terminal_type


union all
select
    '${date_day}' stat_period,                           --时间周期
    d.terminal_type,                                     --终端类型
    count(d.detail_event_id) detail_page_pv,             --资料详情页pv
    count(distinct d.detail_visit_id) detail_page_uv,    --资料详情页uv
    count(distinct(case when d.sale_type='1' then d.detail_visit_id else null end)) free_file_uv,       --免费资料uv
    count(distinct(case when d.sale_type='4' then d.detail_visit_id else null end)) vip_file_uv,        --vip特权资料uv
    count(distinct(case when d.sale_type='5' then d.detail_visit_id else null end)) pay_file_uv,        --付费资料uv
    count(distinct(case when d.sale_type='3' then d.detail_visit_id else null end)) online_file_uv,     --在线资料uv

    count(distinct(case when d.sale_type='1' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) free_file_rate,    --免费资料uv占比: 免费资料uv/详情页uv
    count(distinct(case when d.sale_type='4' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) vip_file_rate,     --VIP特权资料uv占比: VIP特权资料uv/详情页uv
    count(distinct(case when d.sale_type='5' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) pay_file_rate,     --付费资料uv占比: 付费资料uv/详情页uv
    count(distinct(case when d.sale_type='3' then d.detail_visit_id else null end)) / count(distinct d.detail_visit_id) online_finle_rate, --在线资料uv占比: 在线资料uv/详情页uv

    count(case when d.event_id = 'SE035' then d.visit_id else null end) as below_button_pv,                 --下方立即下载按钮pv
    count(distinct(case when d.event_id = 'SE035' then d.visit_id else null end)) as below_button_uv,       --下方立即下载按钮uv
    count(distinct(case when d.event_id = 'SE035' then d.visit_id else null end)) / count(distinct d.detail_visit_id) below_button_rate,    -- 下方下载按钮点击率: UV/详情页UV

    count(case when d.event_id = 'SE003' then d.visit_id else null end) as right_button_pv,                 -- 右下角立即下载按钮pv
    count(distinct(case when d.event_id = 'SE003' then d.visit_id else null end)) as right_button_uv,       -- 右下角立即下载按钮uv
    count(distinct(case when d.event_id = 'SE003' then d.visit_id else null end)) / count(distinct d.detail_visit_id) right_button_rate,    -- 右下角按钮点击率: UV/详情页UV

    count(case when d.module_id_var='login' and d.events_id='NE006' then d.events_visit_id else null end) as login_show_pv,                 --登录页展示pv,
    count(distinct(case when d.module_id_var='login' and d.events_id='NE006' then d.events_visit_id else null end)) as login_show_uv,       --登录页展示uv
    count(distinct(case when d.module_id_var='login' and d.events_id='NE006' then d.events_visit_id else null end)) / count(distinct d.detail_visit_id) login_show_rate,   --登录页展示率:UV/详情页UV

    count(case when d.event_id='NE001' and d.user_id is not null and d.user_id != '' then d.user_id else null end) as login_status_pv,           --登录状态用户pv
    count(distinct(case when d.event_id='NE001' and d.user_id is not null and d.user_id != '' then d.user_id else null end)) as login_status_uv, --登录状态用户uv
    count(distinct(case when d.event_id='NE001' and d.user_id is not null and d.user_id != '' then d.user_id else null end)) / count(distinct d.detail_visit_id) login_status_rate,   --登录状态用户占比

    count(case when d.event_id='SE001' and d.login_result='1' then d.visit_id else null end) login_succ_pv,            --登录成功pv
    count(distinct(case when d.event_id='SE001' and d.login_result='1' then d.visit_id else null end)) login_succ_uv,  --登录成功uv
    count(distinct(case when d.event_id='SE001' and d.login_result='1' then d.visit_id else null end)) / count(distinct d.detail_visit_id) login_succ_rate,    --登录成功率: UV/详情页UV

    count(case when d.events_id='NE006' and d.module_id_var='vipPayCon' then 1 else null end) vip_buy_page_pv,                              --vip购买页pv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='vipPayCon' then d.events_visit_id else null end)) vip_buy_page_uv,    --vip购买页uv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='vipPayCon' then d.events_visit_id else null end)) / count(distinct d.detail_visit_id) vip_buy_page_rate,   --vip购买页面到达率: uv/详情页uv

    count(case when d.event_id='SE010' then 1 else null end) vip_buy_page_button_pv,                        --vip购买页立即支付按钮pv
    count(distinct(case when d.event_id='SE010' then d.visit_id else null end)) vip_buy_page_button_uv,     --vip购买页立即支付按钮uv
    count(distinct(case when d.event_id='SE010' then d.visit_id else null end)) / count(distinct(case when d.event_id='NE006' and d.module_id_var='vipPayCon' then d.visit_id else null end)) vip_buy_page_button_rate,  -- vip购买页支付按钮点击率:UV/vip购买页uv

    count(case when d.events_id='NE006' and d.module_id_var='filePayCon' then 1 else null end) pay_file_buy_page_pv,                             --付费资料购买页pv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='filePayCon' then d.events_visit_id else null end)) pay_file_buy_page_uv,   --付费资料购买页uv
    count(distinct(case when d.events_id='NE006' and d.module_id_var='filePayCon' then d.events_visit_id else null end)) / count(distinct d.detail_visit_id) pay_file_buy_page_rate,  --付费资料购买页面达到率: uv/详情页uv

    count(case when d.event_id='SE008' then 1 else null end) pay_file_buy_button_pv,                      --付费资料立即支付按钮pv
    count(distinct(case when d.event_id='SE008' then d.visit_id else null end)) pay_file_buy_button_uv,   --付费资料立即支付按钮uv
    count(distinct(case when d.event_id='SE008' then d.visit_id else null end)) / count(distinct(case when d.event_id='NE006' and d.module_id_var='filePayCon' then d.visit_id else null end)) pay_file_buy_button_rate,  --付费资料支付按钮点击率: uv/付费资料购买页uv

    count(case when d.goods_type=2 then d.id else null end) vip_order_generate_pv,                        --vip订单生成pv
    count(distinct(case when d.goods_type=2 then d.buyer_user_id else null end)) vip_order_generate_uv,   --vip订单生成uv
    count(distinct(case when d.goods_type=2 then d.buyer_user_id else null end)) / count(case when d.event_id='SE010' then d.visit_id else null end) vip_order_generate_rate,   --vip订单生成率: uv/VIP购买页立即支付按钮uv

    count(case when d.goods_type=1 then d.id else null end) pay_file_order_generate_pv,                         --付费资料订单生成pv
    count(distinct(case when d.goods_type=1 then d.buyer_user_id else null end)) pay_file_order_generate_uv,    --付费资料订单生成uv
    count(distinct(case when d.goods_type=1 then d.buyer_user_id else null end)) / count(distinct(case when d.event_id='SE008' then d.visit_id else null end)) pay_file_order_generate_rate,   --付费资料订单生成率: uv/付费资料立即支付按钮uv

    count(case when d.goods_type=2 and d.order_status=2 then d.id else null end) vip_pay_succ_pv,                        --vip支付成功pv
    count(distinct(case when d.goods_type=2 and d.order_status=2 then d.buyer_user_id else null end)) vip_pay_succ_uv,   --vip支付成功uv
    count(distinct(case when d.goods_type=2 and d.order_status=2 then d.buyer_user_id else null end)) / count(distinct(case when d.goods_type=2 then d.buyer_user_id else null end)) vip_pay_succ_rate,   --vip支付成功率:uv/vip订单生成uv

    count(case when d.goods_type=1 and d.order_status=2 then d.id else null end) pay_file_succ_pv,                        --付费资料支付成功pv
    count(distinct(case when d.goods_type=1 and d.order_status=2 then d.buyer_user_id else null end)) pay_file_succ_uv,   --付费资料支付成功uv
    count(distinct(case when d.goods_type=1 and d.order_status=2 then d.buyer_user_id else null end)) / count(distinct(case when d.goods_type=1 then d.buyer_user_id else null end)) pay_file_succ_rate,  --付费资料支付成功率:uv/付费资料订单生成uv

    cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
    '${date_day}' dt
from(
select
    a.event_id detail_event_id,
    a.visit_id detail_visit_id,
    a.sale_type,
    a.uuid a_uuid,
    b.id,
    b.goods_type,
    b.order_status,
    b.buyer_user_id,
    dim.uuid,
    dim.event_id,
    dim.visit_id,
    dim.user_id,
    dim.page_id,
    dim.login_result,
    dim.terminal_type,
	events.module_id_var,
	events.event_id events_id,
	events.visit_id events_visit_id
from(
select
    -- 登录页展示/登录状态用户
    uuid,
    event_id,
    visit_id,
    user_id,
    page_id,
    get_json_object(var,'$.loginResult') login_result,
    case when terminal_type = '1' then 'M-总' else null end terminal_type
from ods_ods.ods_ods_ishare_log
where dt='${date_day}'
) dim

left join(
--资料详情页 / 资料类型uv模块
select
    uuid,
    event_id,
    visit_id,
    sale_type
from dw_fact.dw_fact_ishare_log_event_se002
where dt='${date_day}'
) a on dim.uuid=a.uuid

--NE006事件,在这张表取解析好的module_id_var
left join(
select
uuid,
event_id,
visit_id,
module_id_var
from dw_fact.dw_fact_ishare_log_events
where dt='${date_day}'
) events on dim.uuid=events.uuid

--vip订单生成/付费资料订单生成/vip支付成功/vip支付成功/付费资料支付成功
left join(
select
uuid,
id,
goods_type,
order_status,
buyer_user_id
from dw_fact.dw_fact_ishare_t_order_info_facts
where substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) b on dim.uuid=b.uuid
) d
where d.terminal_type is not null
group by d.terminal_type