set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_law_conversion_path_day partition(dt)
select
'${date_day}' stat_period,
session_event.terminal_type,
session_event.visit_uv,
session_event.category_page_uv,
session_event.detail_page_pv,
session_event.detail_page_uv,
-- 详情页到达率: 详情页UV/访客数UV
session_event.detail_page_uv/session_event.visit_uv detail_page_arrive_rate,
session_event.consulting_button_uv,
-- 立即咨询按钮点击率: 立即咨询按钮点击UV/详情页UV
coalesce(session_event.consulting_button_uv/session_event.detail_page_uv, 0) consulting_button_rate,
session_event.order_page_pv,
session_event.order_page_uv,
session_event.submit_order_click_pv,
session_event.submit_order_click_uv,
-- 提交订单按钮点击率: 提交订单点击UV/下单页UV
coalesce(session_event.submit_order_click_uv/session_event.order_page_uv, 0) order_button_rate,
session_event.login_dialog_pv,
session_event.login_dialog_uv,
-- 登录框展示率:登录框展示UV/访客数UV
session_event.login_dialog_uv/session_event.visit_uv login_dialog_rate,
session_event.login_succ_per_num,
-- 登录成功率: 登录成功人数/登录框展示UV
coalesce(session_event.login_succ_per_num/session_event.login_dialog_uv, 0) login_succ_rate,
session_event.order_generate_uv,
coalesce(order_info.pay_succ_num, 0) pay_succ_num,
coalesce(order_info.pay_succ_uv, 0) pay_succ_uv,
-- 支付成功率: 支付成功UV/订单生成UV
coalesce(order_info.pay_succ_uv/session_event.order_generate_uv, 0) pay_succ_rate,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time,
'${date_day}' dt
from(
select
terminal_type,
-- 访客数UV
count(case when event_id='NE001' then visit_id else null end) visit_uv,
-- 分类页UV
count(case when event_id='NE030' and page_id_var='SL' then visit_id else null end) category_page_uv,
-- 详情页PV
count(case when event_id='SE044' then visit_id else null end) detail_page_pv,
-- 详情页UV
count(distinct(case when event_id='SE044' then visit_id else null end)) detail_page_uv,
-- 立即咨询按钮点击UV
count(distinct(case when event_id='NE031' and dom_id_var='buynow' then visit_id else null end)) consulting_button_uv,
-- 下单页PV
count(case when event_id='NE006' and module_id_var='orderPage' then visit_id else null end) order_page_pv,
-- 下单页UV
count(distinct(case when event_id='NE006' and module_id_var='orderPage' then visit_id else null end)) order_page_uv,
-- 提交订单点击PV
count(case when event_id='SE046' then visit_id else null end) submit_order_click_pv,
-- 提交订单点击UV
count(distinct(case when event_id='SE046' then visit_id else null end)) submit_order_click_uv,
-- 登录框展示PV
count(case when event_id='NE006' and module_id_var='login' then visit_id else null end) login_dialog_pv,
-- 登录框展示UV
count(distinct(case when event_id='NE006' and module_id_var='login' then visit_id else null end)) login_dialog_uv,
-- 登录成功人数
count(distinct(case when event_id='SE001' and get_json_object(var,'$.loginResult') = 1 then user_id else null end)) login_succ_per_num,
-- 订单生成UV
count(distinct(case when event_id='SE033' then visit_id else null end)) order_generate_uv
from(
select
-- 终端类型
case when substring(terminal_type,0,1)='0' then 'pc'
when substring(terminal_type,0,1)='1' and browser='微信' then '微信浏览器'
when substring(terminal_type,0,1)='1' and browser not like '%微信%' then 'm'
when substring(terminal_type,0,1)='2' then '快应用'
when substring(terminal_type,0,1)='3' then 'android'
when substring(terminal_type,0,1)='4' then 'ios'
when substring(terminal_type,0,1)='6' then '今日头条小程序'
when substring(terminal_type,0,1)='7' then '百度小程序'
when substring(terminal_type,0,1)='8' then '微信小程序' else '' end as terminal_type,
event_id,
visit_id,
dom_id_var,
module_id_var,
user_id,
page_id_var,
var
from dw_fact.dw_fact_ishare_session_event
where dt='${date_day}'
and site_type='iLawService'
) a
where terminal_type <> ''
group by terminal_type
) session_event

left join(
select
-- 终端类型
case source_mode when '0' then 'pc' when '1' then 'm' when '2' then 'android' when '3' then 'ios' when '4' then '快应用' when '5' then '百度小程序' when '6' then '微信浏览器' when '7' then '微信小程序' else '' end as source_mode,
-- 支付成功笔数
count(id) pay_succ_num,
-- 支付成功uv
count(distinct buyer_user_id) pay_succ_uv
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and goods_type=13
and order_status=2
and channel_source=8
group by source_mode
) order_info on session_event.terminal_type=order_info.source_mode