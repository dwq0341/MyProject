--是否会员
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag)
select
id,
is_vip ,
'is_vip' tag
from dw_dim.dw_dim_ishare_users;

--注册渠道
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'create_source')
select
id,
case when create_time is not null then traffic_source else '0' end
from dw_dim.dw_dim_ishare_users;

--最近访问渠道
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'last_visit_source')
select
user_id,
traffic_source tag_value
from (
select
y.user_id,
x.traffic_source,
row_number() over(partition by y.user_id order by x.session_start_time desc) sort_num
from dw_Fact.dw_fact_ishare_session_info x
left join (select user_id,session_id from dw_fact.dw_fact_ishare_session_info_user_mapping where dt = '${date_day}') y
on x.session_id = y.session_id
where x.dt = '${date_day}' and x.user_id is not null and x.user_id <> '') a
where sort_num = 1
union all
select
id,
tag_value
from dm_dm.dm_dm_ishare_user_feature_single b
left join (
select
user_id
from dw_fact.dw_fact_ishare_session_info_user_mapping
where dt = '${date_day}'
group by user_id
) c on b.id = c.user_id
where c.user_id is null and tag = 'last_visit_source';


--最近购买渠道
with last_pay_source as(
select
user_id,
case when land_url not regexp('.*utm_source.*') and (pre_page_url is null or pre_page_url = '') then '直接访问'
when land_url not regexp('.*utm_source.*') and pre_page_url is not null and (pre_page_url like '%so.com%' or pre_page_url like '%baidu.com%' or pre_page_url like '%sogou.com%' or pre_page_url like '%google.com%' or pre_page_url like '%sm.cn%') then '自然搜索'
when land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*') then '渠道投放'
else '其他' end as traffic_source,
nginx_date
from dw_fact.dw_fact_ishare_session_event a
left join(
select
id
from(
select
id,
goods_type
from dw_fact.dw_fact_ishare_t_order_info
where substr(order_time,0,10) = from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and mth = substr('${date_day}',0,6)
and order_status = '2'
--and goods_type in ('1','2','4','8','12','13')
) a
left join dw_dim.dw_dim_ishare_goods_type_table g on a.goods_type=g.goods_types
where g.goods_types is not null
) b on get_json_object(a.var,'$.orderID') = b.id
where dt = '${date_day}' and event_id = 'SE033'
and a.user_id is not null and a.user_id <> ''
and b.id is not null
)

insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'last_pay_source')
select
user_id,
traffic_source from (
select
user_id,
traffic_source,
nginx_date,
row_number() over(partition by user_id order by nginx_date desc) sort_num
from last_pay_source) a where sort_num = 1
union all
select
id,
tag_value
from dm_dm.dm_dm_ishare_user_feature_single a
left join
(
select
user_id
from
last_pay_source group by user_id) b on a.id = b.user_id
where b.user_id is null and a.tag = 'last_pay_source';

--新老用户
with user_register_status as(
select
code,
'new_user' tag_value
from dw_fact.dw_fact_ishare_tb_login_user
where substr(create_time,0,10) >= date_sub(to_date(from_unixtime(UNIX_TIMESTAMP('${date_day}','yyyyMMdd'))),15)
and mth >= substr(replace(date_sub(to_date(from_unixtime(UNIX_TIMESTAMP('${date_day}','yyyyMMdd'))),15),'-',''),0,6)
group by code)

insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'user_fresh')
select
code,
tag_value from user_register_status
union all
select
id,
'old_user' tag_value
from (select id from dw_dim.dw_dim_ishare_users group by id) a
left join user_register_status b on a.id = b.code
where b.code is null;

--会员名称
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'vip_info')
select
user_id,
concat_ws(',',collect_set(concat(vip_id,':',vip_name))) tag_value
from
(select
user_id,
id,
max(vip_id) vip_id,
max(vip_name) vip_name
from dw_fact.dw_fact_ishare_user_member
where user_member_type = 'VIP'
and end_date >= from_unixtime(unix_timestamp() ,'yyyy-MM-dd HH:mm:ss')
and status = '2'
group by user_id,id) a
group by user_id;