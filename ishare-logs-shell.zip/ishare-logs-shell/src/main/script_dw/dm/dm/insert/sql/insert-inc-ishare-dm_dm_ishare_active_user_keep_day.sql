insert overwrite table dm_dm.dm_dm_ishare_active_user_keep_day partition(dt='${stat_date_now}')
select
a.dt counttime,                                             --统计时间
site_type,                                                  --终端类型
domain,                                                     --站点类型
1th_traffic_source,                                         --一级流量来源
2th_traffic_source,                                         --二级流量来源
count(distinct a.user_id) today_num,                        --当天活跃人数
count(distinct b.user_id) one_day_later_num,                --1天后留存数
count(distinct c.user_id) two_day_later_num,                --2天后留存数
count(distinct d.user_id) three_day_later_num,              --3天后留存数
count(distinct e.user_id) four_day_later_num,               --4天后留存数
count(distinct f.user_id) five_day_later_num,               --5天后留存数
count(distinct g.user_id) six_day_later_num,                --6天后留存数
count(distinct h.user_id) seven_day_later_num,              --7天后留存数
count(distinct i.user_id) fourteen_day_later_num,           --14天后留存数
count(distinct j.user_id) thirty_later_num                  --30天后留存数
from dw_fact.dw_fact_ishare_session_info a
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),1) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) b on a.user_id = b.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),2) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) c on a.user_id = c.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),3) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) d on a.user_id = d.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),4) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) e on a.user_id = e.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),5) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) f on a.user_id = f.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),6) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) g on a.user_id = g.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),7) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) h on a.user_id = h.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),14) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) i on a.user_id = i.user_id
left join (select user_id from dw_fact.dw_fact_ishare_session_info
where dt = from_unixtime(unix_timestamp(date_add(from_unixtime(unix_timestamp('${stat_date_now}','yyyyMMdd'),'yyyy-MM-dd'),30) ,'yyyy-MM-dd'),'yyyyMMdd') and user_id is not null and user_id <> '' group by user_id) j on a.user_id = j.user_id
where a.dt = '${stat_date_now}' group by site_type,domain,1th_traffic_source,2th_traffic_source,dt;
