#!/bin/bash

source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

echo "执行ishare_t_user_login_new 用户登录日报统计(新版)表数据导入 sh开始标志"
sh /usr/local/datax/job/mysqlTable/result/t_user_login_new_sync_day.sh ${date_day}  ${end_date}
echo "ishare_t_user_login_new 用户登录日报统计(新版)表数据导入 sh结束标志"