--最近访问时间
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'last_visit_time')
select
d.user_id,
max(a.session_start_time) tag_value
from dw_fact.dw_fact_ishare_session_info a
left join (select user_id,session_id from dw_fact.dw_fact_ishare_session_info_user_mapping where dt = '${date_day}') d
on a.session_id = d.session_id
where dt = '${date_day}' and a.user_id is not null and a.user_id <> ''
group by d.user_id
union all
select
id,
tag_value
from dm_dm.dm_dm_ishare_user_feature_single b
left join (
select
user_id
from dw_fact.dw_fact_ishare_session_info_user_mapping
where dt = '${date_day}'
group by user_id
) c on b.id = c.user_id
where c.user_id is null and tag = 'last_visit_time';

--注册时间
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'create_time')
select
id,
case when min(create_time) is not null then min(create_time) else '0' end aS tag_value
from dw_dim.dw_dim_ishare_users
group by id;