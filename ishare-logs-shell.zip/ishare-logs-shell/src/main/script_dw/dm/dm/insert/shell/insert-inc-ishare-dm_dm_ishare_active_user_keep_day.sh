#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3
echo ${date_day}
start_date=$(date -d "${date_day}-30days" +%Y%m%d)
echo $start_date
end_date=${date_day}
echo $end_date

while [ "$start_date" -le "$end_date" ];
    do
      stat_date=`date -d "$start_date" +%Y%m%d`
      echo '开始执行 '$stat_date' 的数据'
      beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  --hivevar stat_date_now=${stat_date} -f ../sql/insert-inc-ishare-dm_dm_ishare_active_user_keep_day.sql
      echo '==============================================================================='$stat_date' 数据执行结束==============================================================================='
      start_date=$(date -d "$start_date+1days" +%Y%m%d)
    done

