show functions;
drop function default.cast_to_json;
CREATE FUNCTION default.cast_to_json AS 'com.iask.CastToJson' USING JAR 'hdfs://bj-wlj-namenode01-172-38-1-194:8020/user/hive/udf/hive-udf.jar';
show functions;
insert overwrite table dm_dm.dm_dm_ishare_user_feature_json
select
id,
cast_to_json(concat_ws('|',collect_set(concat(tag,'=',tag_value))),'\\|') tag_info
from dm_dm.dm_dm_ishare_user_feature_single
group by id;