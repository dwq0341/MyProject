insert overwrite table dm_dm.dm_dm_ishare_income_day
select
'${date_day}' stat_period,
a.order_total_income,
a.pay_file_income,
a.vip_file_income,
a.legal_service_income,
a.pc_income,
a.m_income,
a.wechat_browser_income,
a.wechat_min_applet_income,
a.baidu_min_applet_income,
a.app_income,
a.master_income,
a.vertical_stand_income,
a.office_income,
a.super_contract_income,
a.contract_income,
a.legal_adviser_income,
b.baidu_alliance_income,
b.ad_search_income,
b.ad_baidu_min_applet_income,
b.ad_baidu_composition_income,
b.other_income,
--微信小鹅通收入
0 wechat_small_goose,
--微信广告收入
0 wechat_ad_income,
--广告总收入
b.ad_total_income,
--总收入:广告总收入+订单总收入
(b.ad_total_income+a.order_total_income) total_income,
--总收入目标
c.total_income_target,
--广告收入目标
c.ad_income_target,
--增值服务收入目标
c.accretion_income_target,
--完成率: 总收入/总收入目标
(b.ad_total_income+a.order_total_income) / c.total_income_target accomplish_rage,
cast(from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') as string) update_time
from (
select
--订单总收入
sum(pay_price) order_total_income,
-- 付费资料收入
sum(case when goods_type = 14 then pay_price else 0 end) pay_file_income,
-- vip资料收入
sum(case when goods_type = 2 then pay_price else 0 end) vip_file_income,
-- 法律服务收入
sum(case when goods_type = 13 then pay_price else 0 end) legal_service_income,

-- pc端收入
sum(case when source_mode='0' then pay_price else 0 end ) pc_income,
--M端(除微信H5)收入
sum(case when source_mode='1' then pay_price else 0 end ) m_income,
--微信浏览器收入
sum(case when source_mode='6' then pay_price else 0 end ) wechat_browser_income,
--微信小程序收入
sum(case when source_mode='7' then pay_price else 0 end ) wechat_min_applet_income,
-- 百度小程序收入
sum(case when source_mode='5' then pay_price else 0 end ) baidu_min_applet_income,
-- APP端收入
sum(case when source_mode in ('2','3') then pay_price else 0 end) app_income,

--主站收入
sum(case when channel_source = 4 then pay_price else 0 end) master_income,
--垂站收入
sum(case when channel_source <> 4 then pay_price else 0 end) vertical_stand_income,
-- 办公频道收入,
sum(case when channel_source = 0 then pay_price else 0 end) office_income,
-- 超级合同收入
sum(case when channel_source = 5 then pay_price else 0 end) super_contract_income,
-- 合同通收入
sum(case when channel_source = 7 then pay_price else 0 end) contract_income,
-- 法律顾问收入
sum(case when channel_source = 8 then pay_price else 0 end) legal_adviser_income
from(
select
pay_price/100 pay_price,
goods_type,
source_mode,
channel_source
from dw_fact.dw_fact_ishare_t_order_info order_info
--商品类型条件维度表
left join dw_dim.dw_dim_ishare_goods_type_table g on order_info.goods_type=g.goods_types
where substr(order_info.order_time,0,10)=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
and order_info.order_status = 2
and g.goods_types is not null
) info
) a

--广告收入
left join(
select
coalesce(aa.baidu_alliance_income, 0) baidu_alliance_income,
coalesce(bb.ad_search_income, 0) ad_search_income,
coalesce(bb.ad_baidu_min_applet_income, 0) ad_baidu_min_applet_income,
coalesce(bb.ad_baidu_composition_income, 0) ad_baidu_composition_income,
aa.other_income,
--广告总收入
coalesce(aa.baidu_alliance_income,0) + coalesce(bb.ad_search_income,0) + coalesce(bb.ad_baidu_min_applet_income,0) + coalesce(bb.ad_baidu_composition_income,0) + coalesce(aa.other_income,0) ad_total_income
from(
select
--百度联盟收入
sum(ssp_ad_income) baidu_alliance_income,
--其它收入=广告运营收入-百度联盟收入
sum(ad_operations_income) - sum(ssp_ad_income) other_income
from dw_fact.dw_fact_iask_t_date_iask_total
where dayno=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) aa
left join(
select
--众搜收入
sum(case when terminal='众搜' then income else 0 end) ad_search_income,
--百度小程序收入
sum(case when terminal='百度小程序' then income else 0 end) ad_baidu_min_applet_income,
--百度作文收入
sum(case when terminal='百度作文' then income else 0 end) ad_baidu_composition_income
from dw_fact.dw_fact_ishare_t_ishare_income_other
where dayno=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyyy-mm-dd')
) bb on 1=1
) b on 1=1

--收入目标
left join(
select
--总收入目标
sum(case when source='总目标' then target else 0 end) total_income_target,
--广告收入目标
sum(case when source='百度联盟' then target else 0 end) ad_income_target,
--增值服务收入目标
sum(case when source='商业化' then target else 0 end) accretion_income_target
from dw_fact.dw_fact_ishare_t_target_finished
where month=from_unixtime(unix_timestamp('${date_day}','yyyymmdd'),'yyymm')
and project='ishare'
) c on 1=1

union all
select
stat_period,
order_total_income,
pay_file_income,
vip_file_income,
legal_service_income,
pc_income,
m_income,
wechat_browser_income,
wechat_min_applet_income,
baidu_min_applet_income,
app_income,
master_income,
vertical_stand_income,
office_income,
super_contract_income,
contract_income,
legal_adviser_income,
baidu_alliance_income,
ad_search_income,
ad_baidu_min_applet_income,
ad_baidu_composition_income,
other_income,
wechat_small_goose,
wechat_ad_income,
ad_total_income,
total_income,
total_income_target,
ad_income_target,
accretion_income_target,
accomplish_rage,
update_time
from dm_dm.dm_dm_ishare_income_day
where stat_period <> '${date_day}';