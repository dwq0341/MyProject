#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD} --hivevar date_day=${date_day}  -f ../sql/insert-inc-ishare-dm_dm_ishare_file_production_day.sql