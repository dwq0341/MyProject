#!/bin/bash
source ../../../../common/env/hive_env.sh
source ../../../../common/tools/date_tool.sh
#获取起始和结束日期
getStartAndEndDate $1 $2 $3

source ../../../../common/env/hive_env.sh
echo "执行insert-inc-ishare-dm_dm_ishare_channel_transfor sql导入 sh开始标志"
beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD} --hivevar date_day=${date_day}  -f ../sql/insert-inc-ishare-dm_dm_ishare_channel_transfor_to_mysql.sql
echo "执行insert-inc-ishare-dm_dm_ishare_channel_transfor sql导入 sh结束标志"

echo "执行insert-inc-ishare-dm_dm_ishare_channel_transfor表导入 sh开始标志"
sh /usr/local/datax/job/mysqlTable/result/ishare_channel_transfor_to_mysql.sh ${date_day}
echo "执行insert-inc-ishare-dm_dm_ishare_channel_transfor表导入 sh结束标志"