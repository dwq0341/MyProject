#!/usr/bin/env bash
source ../../../common/env/hive_env.sh
excute_mth=$1

  beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  --hivevar stat_mth_now=${excute_mth} -f ../sql/init-full-ishare-dw_dw_ishare_file_down_detail.sql
