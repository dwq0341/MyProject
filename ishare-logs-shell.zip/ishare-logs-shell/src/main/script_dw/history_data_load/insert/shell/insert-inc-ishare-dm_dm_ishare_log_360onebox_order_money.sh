#!/usr/bin/env bash
    source ../../../common/env/hive_env.sh
    start_date=$1
    end_date=$2

    while [ "$start_date" -le "$end_date" ];
    do
      stat_date=`date -d "$start_date" +%Y%m%d`
      echo '开始执行 '$stat_date' 的数据'
      beeline -u jdbc:hive2://${HIVE_SERVER} -n ${HADOOP_USER_NAME} -p ${HADOOP_USER_PWD}  --hivevar stat_date_now=${stat_date} -f ../sql/insert-inc-ishare-dm_dm_ishare_log_360onebox_order_money.sql
      echo '==============================================================================='$stat_date' 数据执行结束==============================================================================='
      start_date=$(date -d "$start_date+1days" +%Y%m%d)
    done

