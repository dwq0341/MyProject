#!/usr/bin/env bash
    source ../../../common/env/hive_env.sh
    start_date=$1
    end_date=$2

    while [ "$start_date" -le "$end_date" ];
    do
      stat_date=`date -d "$start_date" +%Y%m%d`
      echo '开始执行 '$stat_date' 的数据'
      sh /usr/local/datax/job/mysqlTable/result/ishare_sem_metric.sh ${stat_date}
      echo '==============================================================================='$stat_date' 数据执行结束==============================================================================='
      start_date=$(date -d "$start_date+1days" +%Y%m%d)
    done