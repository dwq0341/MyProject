insert overwrite table dw_fact.dw_fact_ishare_session_info partition(dt='${stat_date_now}')
select
session_id,
terminal_type,
site_type,
domain,
device_id,
visit_id,
user_id,
login_status,
browser,
browser_ver,
pre_page_domain land_pre_page_domain,
land_pre_page_url,
land_url,
exit_url,
session_start_time,
session_end_time,
session_duration,
traffic_source,
utm_source,
utm_medium,
utm_campaign,
utm_content,
utm_term,
search_engine,
is_single_pv_session,
visit_deep,
visit_page_count,
order_id
from
(
select
session_id,
visit_id,
max(user_id) over(partition by a.session_id) user_id,
land_url,
exit_url,
device_id,
domain,
browser,
browser_ver,
pre_page_domain,
case when site_type is not null then site_type when split(a.page_id,'-')[1] = 'M' then '主站' when split(a.page_id,'-')[1] = 'O' then '办公频道'
else null end as site_type,
terminal_type,                                                                      --站点类型
max(login_status) over(partition by a.session_id) login_status,
case when land_url not regexp('.*utm_source.*') and (pre_page_url is null or pre_page_url = '') then '直接访问'
when land_url not regexp('.*utm_source.*') and pre_page_url is not null and (pre_page_url like '%so.com%' or pre_page_url like '%baidu.com%' or pre_page_url like '%sogou.com%' or pre_page_url like '%google.com%' or pre_page_url like '%sm.cn%') then '自然搜索'
when land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*') then '渠道投放'
else '其他' end as traffic_source,
case when (count(case when a.event_id = 'NE001' then a.event_id else null end) over(partition by a.session_id)) > 1 then 'N' else 'Y' end as is_single_pv_session,           --是否单PV会话
count((case when event_id = 'NE001' then page_url else null end)) over(partition by a.session_id,a.page_url) visit_deep,
count((case when event_id = 'NE001' then 1 else null end)) over(partition by a.session_id) visit_page_count,           --访问页数
session_start_time session_start_time,    --每一个session开始时间
session_end_time session_end_time,      --每一个session结束时间
session_duration session_duration,      --每一个session持续的时间
ROW_NUMBER() over(partition by a.session_id order by a.nginx_date) sort_num,
max(case when event_id = 'SE033' then get_json_object(var,'$.orderID') else null end) over(partition by a.session_id) order_id,
case when  parse_url(pre_page_url,'HOST') like '%baidu.com%' then 'baidu'
when parse_url(pre_page_url,'HOST') like '%so.com%' then '360'
when parse_url(pre_page_url,'HOST') like '%google.com%' then 'google'
when parse_url(pre_page_url,'HOST') like '%sogou.com%' then 'sougou'
when parse_url(pre_page_url,'HOST') like '%sm.cn%' then 'sm' else '其他' end as search_engine,
parse_url(land_url,'QUERY','utm_source') utm_source,
parse_url(land_url,'QUERY','utm_medium') utm_medium,
parse_url(land_url,'QUERY','utm_content') utm_content,
parse_url(land_url,'QUERY','utm_campaign') utm_campaign,
parse_url(land_url,'QUERY','utm_term') utm_term,
land_pre_page_url,
dt
from dw_fact.dw_fact_ishare_session_event a
where dt = '${stat_date_now}') b where sort_num = 1;