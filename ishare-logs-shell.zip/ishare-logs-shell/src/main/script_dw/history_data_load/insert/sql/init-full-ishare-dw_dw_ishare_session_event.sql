insert overwrite table dw_fact.dw_fact_ishare_session_event partition(dt='${stat_date_now}')
select
a.session_id,               --会话id
a.event_id,                 --事件id
a.event_name,               --事件名称
a.event_type,               --事件类型
from_unixtime(cast((cast(a.event_time as bigint))/1000 as bigint)) event_time,                   --事件时间
from_unixtime(unix_timestamp(a.nginx_date,'yyyyMMddHHmmss'),'yyyy-MM-dd HH:mm:ss') nginx_date,   --服务器上传时间
a.terminal_type,            --终端类型
a.login_status,             --登录状态
a.visit_id,                 --访客ID
a.user_id,                  --用户ID
a.ip,                       --ip地址
a.page_id,                  --当前页面编号
a.page_name,                --当前页面的名称
a.page_url,                 --当前页面URL
FIRST_VALUE(a.page_url) over(partition by a.session_id order by a.nginx_date) land_url,             --落地页url
FIRST_VALUE(a.page_url) over(partition by a.session_id order by a.nginx_date desc) exit_url,        --退出页url
concat_ws('://',parse_url(a.page_url, 'PROTOCOL'),parse_url(a.page_url, 'HOST')) domain ,           --域名
a.dom_id,                   --当前触发DOM的编号
a.dom_name,                 --当前触发DOM的名称
c.session_position,
c.session_event_duration,
min(from_unixtime(unix_timestamp(a.nginx_date,'yyyyMMddHHmmss'),'yyyy-MM-dd HH:mm:ss')) over(partition by a.session_id) session_start_time,    --每一个session开始时间
max(from_unixtime(unix_timestamp(a.nginx_date,'yyyyMMddHHmmss'),'yyyy-MM-dd HH:mm:ss')) over(partition by a.session_id) session_end_time,      --每一个session结束时间
(max((unix_timestamp(a.nginx_date,'yyyyMMddHHmmss'))) over(partition by a.session_id)) - (min((unix_timestamp(a.nginx_date,'yyyyMMddHHmmss'))) over(partition by a.session_id)) session_duration,      --每一个session持续的时间
count((case when a.event_id = 'NE001' then a.page_id else null end)) over(partition by a.session_id,a.event_id) distinct_pv_count,                                   --访问深度
case when (count(case when a.event_id = 'NE001' then a.event_id else null end) over(partition by a.session_id)) > 1 then 'N' else 'Y' end as is_single_pv_session,   --是否单PV会话
count((case when a.event_id = 'NE001' then a.page_id else null end)) over(partition by a.session_id) session_pv_count,                                               --访问页数
a.var,                                                                                                                                                               --业务json数据
a.pre_page_url,
a.browser_ver,
FIRST_VALUE(a.pre_page_url) over(partition by a.session_id order by a.nginx_date) land_pre_page_url,
a.cip
from
ods_ods.ods_ods_ishare_log a
left join
(select b.nginx_date,b.session_id,max(b.session_event_duration) session_event_duration,max(b.session_position) session_position from
(
select
session_id,
unix_timestamp(nginx_date,'yyyyMMddHHmmss') nginx_date,
row_number() over(partition by session_id order by nginx_date) session_position,
cast (lead(unix_timestamp(nginx_date,'yyyyMMddHHmmss'),1) over(partition by session_id order by nginx_date) as bigint) - cast(unix_timestamp(nginx_date,'yyyyMMddHHmmss') as bigint) session_event_duration
from
ods_ods.ods_ods_ishare_log
where dt='${stat_date_now}' and session_id <> '' and event_id <> 'SE002' and session_id <> '--' and session_id is not null) b group by b.session_id,b.nginx_date) c on a.session_id = c.session_id and unix_timestamp(a.nginx_date,'yyyyMMddHHmmss') = c.nginx_date
where a.dt='${stat_date_now}' and a.session_id <> '' and a.session_id is not null and a.session_id <> '--';