--最近购买渠道
with last_pay_source as(
select
user_id,
case when land_url not regexp('.*utm_source.*') and (pre_page_url is null or pre_page_url = '') then '直接访问'
when land_url not regexp('.*utm_source.*') and pre_page_url is not null and (pre_page_url like '%so.com%' or pre_page_url like '%baidu.com%' or pre_page_url like '%sogou.com%' or pre_page_url like '%google.com%' or pre_page_url like '%sm.cn%') then '自然搜索'
when land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*') then '渠道投放'
else '其他' end as traffic_source,
nginx_date
from dw_fact.dw_fact_ishare_session_event a
left join
(
select
id
from
dw_fact.dw_fact_ishare_t_order_info where substr(order_time,0,10) = from_unixtime(unix_timestamp('${stat_date_now}','yyyymmdd'),'yyyy-mm-dd') and mth = substr('${stat_date_now}',0,6) and order_status = '2' and goods_type in ('1','2','4','8','12','13')) b
on get_json_object(a.var,'$.orderID') = b.id
where dt = '${stat_date_now}' and event_id = 'SE033'
and a.user_id is not null and a.user_id <> ''
and b.id is not null
)
insert overwrite table dm_dm.dm_dm_ishare_user_feature_single partition(tag = 'last_pay_source')
select
user_id,
traffic_source from (
select
user_id,
traffic_source,
nginx_date,
row_number() over(partition by user_id order by nginx_date desc) sort_num
from last_pay_source) a where sort_num = 1
union all
select
id,
tag_value
from dm_dm.dm_dm_ishare_user_feature_single a
left join
(
select
user_id
from
last_pay_source group by user_id) b on a.id = b.user_id
where b.user_id is null and a.tag = 'last_pay_source';