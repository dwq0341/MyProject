set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set mapreduce.map.memory.mb=4096;
insert overwrite table dw_fact.dw_fact_ishare_file_down_detail partition(mth)
select
a.file_id file_id,
a.file_name file_name,
a.first_file_category_id,
a.sec_file_category_id,
a.third_file_category_id,
a.first_file_category_name,
a.sec_file_category_name,
a.third_file_category_name,
a.file_pay_type,
a.file_format,
a.terminal_type,
concat_ws('://',parse_url(a.page_url, 'PROTOCOL'),parse_url(a.page_url, 'HOST')) domain ,
a.file_coo_type visit_type,
case when concat_ws('://',parse_url(a.page_url, 'PROTOCOL'),parse_url(a.page_url, 'HOST')) regexp('.*ishare.iask.sina.com.cn.*') then '主站' when concat_ws('://',parse_url(a.page_url, 'PROTOCOL'),parse_url(a.page_url, 'HOST')) regexp('.*office.iask.com.*') then '办公频道' else null end as channel_type,
a.file_uploader_id,
b.usertypeid uploader_user_type,
a.user_id down_user_id,
a.event_time down_time,
a.down_type,
a.pre_page_url referer,
substr(a.dt,0,6) mth
from dw_fact.dw_fact_ishare_log_events a
left join (select id,usertypeid from ods_ods.ods_ods_ishare_users) b on a.file_uploader_id = b.id
where substr(a.dt,0,6)='${stat_mth_now_event}' and a.session_id <> '' and a.session_id is not null
and a.event_id = 'SE003';