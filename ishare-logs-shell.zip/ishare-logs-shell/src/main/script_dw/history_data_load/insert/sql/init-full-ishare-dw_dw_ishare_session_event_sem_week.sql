set mapreduce.map.memory.mb=4096;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
insert overwrite table dw_fact.dw_fact_ishare_session_event_sem_week partition(week)
select
concat_ws('|',cast(year(nginx_date) as string),cast(weekofyear(nginx_date) as string)) count_time,                                                             -- 统计时间
parse_url(land_url,'QUERY','utm_source') utm_source,                                                                                                           -- 来源渠道
parse_url(land_url,'QUERY','utm_medium') utm_medium,                                                                                                           -- 来源计划
parse_url(land_url,'QUERY','utm_campaign') utm_campaign,                                                                                                       -- 来源单元
parse_url(land_url,'QUERY','utm_term') utm_term,                                                                                                               -- 来源关键词
count(distinct visit_id) user_count,                                                                                                                           -- 用户量
sum(case when event_id = 'NE001' then 1 else 0 end ) as page_view,                                                                                             -- 页面浏览量
sum(case when event_id = 'SE002' then 1 else 0 end ) as detail_page_view,                                                                                      -- 详情页浏览量
count(distinct (case when event_id = 'SE003' then visit_id else null end)) as detail_page_download_immediately_count,                                          -- 详情页立即下载按钮点击人数
count(distinct (case when event_id = 'SE001' and get_json_object(var,'$.loginResult') = 1 then visit_id else null end )) as hand_login_succed_count,           -- 手动登录成功人数
count(distinct (case when event_id = 'SE010' then visit_id else null end )) as vip_pay_immediately_count,                                                      -- vip立即支付点击按钮人数
count(distinct (case when event_id = 'SE011' and get_json_object(var,'$.payResult') = 1 then visit_id else null end)) as vip_pay_count,                        -- vip支付充值人数
sum(case when event_id = 'SE011' then get_json_object(var,'$.orderPayPrice') else 0 end) as vip_pay_amount,                                                    -- vip充值金额
count(case when event_id = 'SE008' then visit_id else null end ) as cash_pay_immediately_count,                                                                -- 现金立即购买点击人数
count(case when event_id = 'SE009' and get_json_object(var,'$.payResult') = 1 then visit_id else null end ) as cash_pay_count,                                 -- 现金购买人数
sum(case when event_id = 'SE009' then get_json_object(var,'$.orderPayPrice') else 0 end) as cash_pay_amount,                                                   -- 现金购买金额
count(case when event_id = 'SE012' then visit_id else null end) as download_privilege_pay_immediately_count,                                                   -- 下载特权立即支付点击按钮人数
count(case when event_id = 'SE013' and get_json_object(var,'$.payResult') = 1 then visit_id else null end) as download_privilege_pay_count,                    -- 下载特权购买人数
sum(case when event_id = 'SE013' then get_json_object(var,'$.orderPayPrice') else 0 end) as download_privilege_pay_amount,                                     -- 下载特权购买金额
count(case when event_id = 'NE001' then 1 else null end)/count(distinct visit_id) as avg_browse_page_number,                                                   -- 人均浏览页数
count(distinct (case when is_single_pv_session = 'Y' then session_id else null end))/count(distinct session_id) as jump_out_rate,                              -- 跳出率
sum(session_duration)/count(distinct session_id) as avg_duration_visit, 	                                                                                       -- 平均访问时长
concat_ws('|',cast(year(nginx_date) as string),cast(weekofyear(nginx_date) as string)) week
from
dw_fact.dw_fact_ishare_session_event
where
land_url regexp('.*utm_source.*') and land_url regexp('.*utm_medium.*') and land_url regexp('.*utm_campaign.*') and land_url regexp('.*utm_term.*')
and dt >= from_unixtime(unix_timestamp(date_sub(CONCAT_WS('-',substr('${stat_date_now}',0,4),substr('${stat_date_now}',5,2),substr('${stat_date_now}',7,2)),pmod(datediff(CONCAT_WS('-',substr('${stat_date_now}',0,4),substr('${stat_date_now}',5,2),substr('${stat_date_now}',7,2)),'1900-01-08'),7)),'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd')
and dt <= from_unixtime(unix_timestamp(date_add(date_sub(CONCAT_WS('-',substr('${stat_date_now}',0,4),substr('${stat_date_now}',5,2),substr('${stat_date_now}',7,2)),pmod(datediff(CONCAT_WS('-',substr('${stat_date_now}',0,4),substr('${stat_date_now}',5,2),substr('${stat_date_now}',7,2)),'1900-01-08'),7)+1),7),'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd')
group by
parse_url(land_url,'QUERY','utm_source'),
parse_url(land_url,'QUERY','utm_medium'),
parse_url(land_url,'QUERY','utm_campaign'),
parse_url(land_url,'QUERY','utm_term'),
concat_ws('|',cast(year(nginx_date) as string),cast(weekofyear(nginx_date) as string));