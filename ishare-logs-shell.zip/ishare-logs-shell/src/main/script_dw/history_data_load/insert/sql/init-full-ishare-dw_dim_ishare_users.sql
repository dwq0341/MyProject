set mapred.reduce.tasks = 200;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.groupby.skewindata = true;
set hive.optimize.skewjoin=true;
insert overwrite table dw_dim.dw_dim_ishare_users partition (is_vip,user_type_id)
select
c.id,
c.birthday,
c.gender,
c.tel,
c.vip_id,
c.vip_name,
a.create_time,
b.session_id,
b.terminal_type,
b.traffic_source,
b.utm_source,
b.utm_medium,
b.utm_campaign,
b.utm_content,
b.utm_term,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
c.is_vip,
COALESCE(c.user_type_id,4) user_type_id
from
--以dw_fact.dw_fact_ishare_tb_login_user为主表入手，主要拿到用户的注册日期，用于关联后面的埋点表
(
select
code,
min(substr(create_time,0,10)) create_time
from dw_fact.dw_fact_ishare_tb_login_user
where replace(substr(create_time,0,10),'-','') = '${stat_date_now}' and mth = substr('${stat_date_now}',0,6)
group by code
) a
--根据注册日期拿到埋点里面记录的会话id、终端类型、以及注册SEM渠道来源
left join
(
select * from (
select
user_id,
session_id,
traffic_source,
terminal_type,
utm_source,
utm_medium,
utm_campaign,
utm_content,
utm_term,
session_start_time,
row_number() over(partition by user_id order by session_start_time) sort_num
from dw_Fact.dw_fact_ishare_session_info where dt = '${stat_date_now}') e where e.sort_num = 1
) b on a.code = b.user_id and a.create_time = substr(b.session_start_time,0,10)
--获取用户vip状态信息
left join
(
select id,max(birth_day) birthday,max(gender) gender,max(tel) tel,null vip_id,null vip_name,'N' is_vip,max(user_type_id) user_type_id from
dw_fact.dw_fact_ishare_users_new GROUP  by id) c on a.code = c.id
where c.id is not null
union all
--前面更新，后半段保留原始数据
select
u.id,
u.birthday,
u.gender,
u.tel,
u.vip_id,
u.vip_name,
u.create_time,
u.session_id,
u.terminal_type,
u.traffic_source,
u.utm_source,
u.utm_medium,
u.utm_campaign,
u.utm_content,
u.utm_term,
from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss') update_time,
u.is_vip,
COALESCE(u.user_type_id,4) user_type_id
from dw_dim.dw_dim_ishare_users  u
left join
(select
code
from dw_fact.dw_fact_ishare_tb_login_user
where replace(substr(create_time,0,10),'-','') = '${stat_date_now}' and mth = substr('${stat_date_now}',0,6)
group by code) t on u.id = t.code where t.code is null distribute by is_vip,user_type_id;