set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dw_dw.dw_dw_ishare_file_info partition(dt)
select
p.id file_id,
p.title file_name,
cl.classid first_class_id,
cl.father_id sec_class_id,
cl.grandfather_id third_class_id,
cl.name first_class_name,
cl.father_name sec_class_name,
cl.grandfather_name third_class_name,
case when (p.permin = 1 and p.volume = 0 and p.vipFreeFlag <> 1 and p.vipFreeFlag <> 2) then '免费' when (p.permin = 1 and p.volume >= 1 and p.vipFreeFlag <> 1 and p.vipFreeFlag <> 2) then '下载券'
when (p.permin = 3 and p.vipFreeFlag <> 1 and p.vipFreeFlag <> 2) then '现金' when (p.isDownload = 'n' and p.vipFreeFlag <> 1 and p.vipFreeFlag <> 2) then '仅在线'
when (p.vipFreeFlag =1 or p.vipFreeFlag=2) then 'vip' else null end as file_pay_type,
p.format file_format,
p.uid uploader_user_id,
u.usertypeid uploader_user_type,
u.realname uploader_name,
p.filesourcechannel uploader_channel,
p.createtime create_time,
uptimesdate update_time,
p.isexcellent file_quality,
p.pricebak org_price,
p.price lastest_price,
p.volumebak org_volume,
p.volume latest_volume,
sns.starscore score_num,
sns.collectnum collect_num,
'' complaint_num,
sns.downnum down_num,
sns.readnum pv_num,
p.dt dt
from ods_ods.ods_ods_ishare_file_info_public p
left join
(
select c.classid,c.name,c.father_id,c.father_name,d.grandfather_id,d.grandfather_name,d.father_id granderfater_id from
(
select
a.classid,a.name,b.classid father_id,b.name father_name,b.father grandfather_id
from ods_ods.ods_ods_ishare_file_class a
left join (select classid,name,father from ods_ods.ods_ods_ishare_file_class where level = '2') b on a.father = b.classid) c
left join (select classid grandfather_id,name grandfather_name,father father_id from ods_ods.ods_ods_ishare_file_class where level = '1') d ) cl on p.classid = cl.classid
left join ods_ods.ods_ods_ishare_users u on p.uid = u.id
left join ods_ods.ods_ods_ishare_file_sns sns on p.id = sns.fileid
where p.dt ='${stat_date_now}';