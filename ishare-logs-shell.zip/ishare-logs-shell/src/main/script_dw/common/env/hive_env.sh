#!/bin/bash
# ********************************************************************************
# 程序名称:    hive_env
# 功能描述:    设定hive的环境参数
# 输入参数:
#
# 输入资源:
# 输出资源:
#
# 中间资源:
# 创建人员:    siqing.chen
# 创建日期:    2019-11-06
# 版本说明:
# 修改人员:
# 修改日期:
# 修改原因:
# 版本说明:
#
# ********************************************************************************
# ********************************************************************************
#公共参数

#export HADOOP_USER_NAME=read
#export HADOOP_USER_PWD=iask123456
#HIVEPOOL=(172.38.200.15)

export HADOOP_USER_NAME=data-read
export HADOOP_USER_PWD=Data-read@2020
#export HADOOP_USER_PWD=Data-read@20200609

HIVEPOOL=(172.38.1.194 172.38.1.195 172.38.1.196)
#HIVEPOOL=(192.168.1.152 192.168.1.150 192.168.1.151)

HIVENUM=${#HIVEPOOL[*]}
HIVE_SERVER=${HIVEPOOL[$((RANDOM%HIVENUM))]}:10000
HIVE_SERVER_JDBC_URL="jdbc:hive2://${HIVE_SERVER}"
