#!/bin/bash

#设置sem账户映射关系
sem_account="when-\'baidu15\'-then-\'爱问科技15\'"