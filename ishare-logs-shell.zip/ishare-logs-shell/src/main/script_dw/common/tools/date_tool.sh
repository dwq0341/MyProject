#!/bin/bash


#获取增量抽取的起始日期和结束日期
#编写人:csq
function getStartAndEndDate()
{

    if [ $# -eq 0 ];
      then
        echo 'no parms'
        start_date=`date -d "1 day ago" +'%Y%m%d'`
        end_date=`date "+%Y%m%d"`
        date_day=`date -d "1 day ago" +'%Y%m%d'`

      elif [ $# -eq 1 ];
        then
          echo 'one parms'
          start_date=`date -d "1 day ago" +'%Y%m%d'`
          end_date=$1
          date_day=`date -d "1 day ago" +'%Y%m%d'`

      elif [ $# -eq 2 ];
        then
        if [ "$1" = "" and  "$2" = "" ]; then
            start_date=`date -d "1 day ago" +'%Y%m%d'`
            end_date=`date "+%Y%m%d"`
            date_day=`date -d "1 day ago" +'%Y%m%d'`

        else
            start_date=$1
            end_date=$2
            date_day=$3

        fi

      else
        start_date=$1
        end_date=$2
        date_day=$3

    fi
    echo "job_start_date:$1  job_end_date:$2 job_date_day:$3   start_date=${start_date}  end_date:${end_date} date_day:${date_day} "
}